import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import ProtectedRoute from "@/components/ProtectedRoute";
import { lazy, Suspense } from "react";
import Dashboard from "./pages/Dashboard";
import FormateurDashboard from "./pages/FormateurDashboard";
import Auth from "./pages/Auth";
import RoleSelect from "./pages/RoleSelect";
import NotFound from "./pages/NotFound";
import AdminDashboard from "./pages/AdminDashboard";
import { useAvatarPreload } from "@/hooks/useAvatarPreload";
import AppLayout from "@/components/layout/AppLayout";
import {
  MesCours,
  Classement,
  Messages,
  NotificationsPage,
  Parametres,
  FormateurCours,
  FormateurCoursNouveau,
  FormateurApprenants
} from "./pages/AdditionalPages";

const LoadingApprenant = lazy(() => import("@/components/loading/LoadingApprenant"));
const LoadingFormateur = lazy(() => import("@/components/loading/LoadingFormateur"));
const AvatarTest = lazy(() => import("./pages/AvatarTest"));

const queryClient = new QueryClient();

const App = () => {
  useAvatarPreload();
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route
                path="/"
                element={
                  <ProtectedRoute requireLoading>
                    <AppLayout>
                      <Dashboard />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />
              <Route path="/auth" element={<Auth />} />
              <Route
                path="/role-select"
                element={
                  <ProtectedRoute>
                    <RoleSelect />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/loading-apprenant"
                element={
                  <ProtectedRoute>
                    <Suspense fallback={null}><LoadingApprenant /></Suspense>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/loading-formateur"
                element={
                  <ProtectedRoute>
                    <Suspense fallback={null}><LoadingFormateur /></Suspense>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/onboarding"
                element={
                  <ProtectedRoute requireLoading>
                    <div className="min-h-screen flex items-center justify-center bg-background text-foreground text-2xl">Onboarding (à venir)</div>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/formateur/dashboard"
                element={
                  <ProtectedRoute requiredRole="formateur" requireLoading>
                    <AppLayout>
                      <FormateurDashboard />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/formateur/statistiques"
                element={
                  <ProtectedRoute requiredRole="formateur" requireLoading>
                    <AppLayout>
                      <FormateurDashboard />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />
              {/* Apprenant Subroutes */}
              <Route
                path="/cours"
                element={
                  <ProtectedRoute requireLoading>
                    <AppLayout>
                      <MesCours />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/classement"
                element={
                  <ProtectedRoute requireLoading>
                    <AppLayout>
                      <Classement />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/messages"
                element={
                  <ProtectedRoute requireLoading>
                    <AppLayout>
                      <Messages />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/notifications"
                element={
                  <ProtectedRoute requireLoading>
                    <AppLayout>
                      <NotificationsPage />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/parametres"
                element={
                  <ProtectedRoute requireLoading>
                    <AppLayout>
                      <Parametres />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin"
                element={
                  <ProtectedRoute requireLoading>
                    <AppLayout>
                      <AdminDashboard />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />

              {/* Formateur Subroutes */}
              <Route
                path="/formateur/cours"
                element={
                  <ProtectedRoute requiredRole="formateur" requireLoading>
                    <AppLayout>
                      <FormateurCours />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/formateur/cours/nouveau"
                element={
                  <ProtectedRoute requiredRole="formateur" requireLoading>
                    <AppLayout>
                      <FormateurCoursNouveau />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/formateur/apprenants"
                element={
                  <ProtectedRoute requiredRole="formateur" requireLoading>
                    <AppLayout>
                      <FormateurApprenants />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/formateur/messages"
                element={
                  <ProtectedRoute requiredRole="formateur" requireLoading>
                    <AppLayout>
                      <Messages />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/formateur/parametres"
                element={
                  <ProtectedRoute requiredRole="formateur" requireLoading>
                    <AppLayout>
                      <Parametres />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/formateur/notifications"
                element={
                  <ProtectedRoute requiredRole="formateur" requireLoading>
                    <AppLayout>
                      <NotificationsPage />
                    </AppLayout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/avatar-test"
                element={
                  <Suspense fallback={null}>
                    <AvatarTest />
                  </Suspense>
                }
              />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
};

export default App;
