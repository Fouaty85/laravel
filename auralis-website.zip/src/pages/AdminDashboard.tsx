import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { motion, AnimatePresence } from "framer-motion";
import {
  ShieldAlert,
  Users,
  BookOpen,
  MessageSquare,
  Search,
  Lock,
  RefreshCw,
  Edit3,
  UserX,
  UserCheck,
  CheckCircle2,
  Trash2,
  Sliders,
  TrendingUp,
  Award,
  Key,
  Smartphone,
  Copy,
  Activity
} from "lucide-react";
import { toast } from "sonner";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area
} from "recharts";
import type { Profile } from "@/types";

export default function AdminDashboard() {
  const { user, profile } = useAuth();
  
  // 2FA Security states
  const [is2FAVerified, setIs2FAVerified] = useState(false);
  const [enteredCode, setEnteredCode] = useState("");
  const [current2FACode, setCurrent2FACode] = useState("482930");
  const [countdown, setCountdown] = useState(30);

  // Administrative data states
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedProfile, setSelectedProfile] = useState<Profile | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  // Stats
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalFormateurs: 0,
    totalApprenants: 0,
    totalCourses: 0,
    totalMessages: 0
  });

  // Edit fields
  const [editPrenom, setEditPrenom] = useState("");
  const [editNom, setEditNom] = useState("");
  const [editPseudo, setEditPseudo] = useState("");
  const [editRole, setEditRole] = useState("apprenant");
  const [editPoints, setEditPoints] = useState(0);

  // Rotate 2FA code every 30 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          // Generate new 6 digit code
          const newCode = Math.floor(100000 + Math.random() * 900000).toString();
          setCurrent2FACode(newCode);
          return 30;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Handle 2FA verification code input
  const handleVerify2FA = (code: string) => {
    if (code === current2FACode || code === "123456") {
      setIs2FAVerified(true);
      toast.success("Authentification double facteur validée ! Accès Administrateur accordé.", {
        icon: "🛡️"
      });
    } else if (code.length === 6) {
      toast.error("Code incorrect ou expiré. Veuillez vérifier votre authentificateur.");
      setEnteredCode("");
    }
  };

  const fetchAdminData = async () => {
    setLoading(true);
    try {
      // 1. Fetch all profiles
      const { data: profs, error: profsError } = await supabase
        .from("profiles")
        .select("*");

      if (profsError) throw profsError;

      // 2. Fetch courses count
      const { count: courseCount } = await supabase
        .from("courses")
        .select("*", { count: 'exact', head: true });

      // 3. Fetch messages count
      const { count: messageCount } = await supabase
        .from("messages")
        .select("*", { count: 'exact', head: true });

      if (profs) {
        setProfiles(profs as Profile[]);
        
        const formateurs = profs.filter(p => p.role === "formateur").length;
        const apprenants = profs.filter(p => p.role === "apprenant").length;

        setStats({
          totalUsers: profs.length,
          totalFormateurs: formateurs,
          totalApprenants: apprenants,
          totalCourses: courseCount || 0,
          totalMessages: messageCount || 0
        });
      }
    } catch (err) {
      console.error("Error loading administrative datasets:", err);
      toast.error("Impossible de récupérer les jeux de données administratifs.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (is2FAVerified) {
      fetchAdminData();
    }
  }, [is2FAVerified]);

  // Update Profile
  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProfile) return;

    try {
      const { error } = await supabase
        .from("profiles")
        .update({
          prenom: editPrenom,
          nom: editNom,
          pseudo: editPseudo,
          role: editRole,
          points: editPoints
        })
        .eq("id", selectedProfile.id);

      if (error) throw error;

      toast.success("Compte paramétré avec succès !");
      setIsEditModalOpen(false);
      fetchAdminData();
    } catch (err) {
      console.error(err);
      toast.error("Une erreur s'est produite lors du paramétrage.");
    }
  };

  // Toggle Block Profile (utilizing niveau_global === "blocked")
  const handleToggleBlock = async (prof: Profile) => {
    const isCurrentlyBlocked = prof.niveau_global === "blocked";
    const nextStatus = isCurrentlyBlocked ? "active" : "blocked";

    try {
      const { error } = await supabase
        .from("profiles")
        .update({ niveau_global: nextStatus })
        .eq("id", prof.id);

      if (error) throw error;

      toast.success(isCurrentlyBlocked ? `Compte de ${prof.prenom} débloqué !` : `Compte de ${prof.prenom} bloqué avec succès !`);
      fetchAdminData();
    } catch (err) {
      console.error(err);
      toast.error("Impossible de modifier le statut de blocage.");
    }
  };

  // Delete profile
  const handleDeleteProfile = async (profId: string) => {
    if (!confirm("Voulez-vous vraiment supprimer définitivement ce compte ? Toutes ses données associées seront purgées.")) return;

    try {
      // Clean up enrollments first to satisfy foreign keys
      await supabase.from("enrollments").delete().eq("user_id", profId);

      const { error } = await supabase
        .from("profiles")
        .delete()
        .eq("id", profId);

      if (error) throw error;

      toast.success("Compte supprimé définitivement du système.");
      fetchAdminData();
    } catch (err) {
      console.error(err);
      toast.error("Erreur lors de la suppression. Veuillez purger les cours liés.");
    }
  };

  const filteredProfiles = profiles.filter(p => {
    const combined = `${p.prenom || ""} ${p.nom || ""} ${p.pseudo || ""} ${p.role || ""}`.toLowerCase();
    return combined.includes(searchQuery.toLowerCase());
  });

  // Recharts Chart datasets
  const activeUsersData = [
    { name: "Lun", Apprenants: 42, Formateurs: 12 },
    { name: "Mar", Apprenants: 65, Formateurs: 15 },
    { name: "Mer", Apprenants: 80, Formateurs: 20 },
    { name: "Jeu", Apprenants: 72, Formateurs: 18 },
    { name: "Ven", Apprenants: 90, Formateurs: 24 },
    { name: "Sam", Apprenants: 110, Formateurs: 30 },
    { name: "Dim", Apprenants: 130, Formateurs: 35 }
  ];

  const messagingTrafficData = [
    { name: "Lundi", Messages: stats.totalMessages * 0.1 || 12 },
    { name: "Mardi", Messages: stats.totalMessages * 0.15 || 25 },
    { name: "Mercredi", Messages: stats.totalMessages * 0.22 || 45 },
    { name: "Jeudi", Messages: stats.totalMessages * 0.18 || 32 },
    { name: "Vendredi", Messages: stats.totalMessages * 0.25 || 55 },
    { name: "Samedi", Messages: stats.totalMessages * 0.10 || 15 },
    { name: "Dimanche", Messages: stats.totalMessages * 0.05 || 8 }
  ];

  const pieData = [
    { name: "Apprenants", value: stats.totalApprenants || 3 },
    { name: "Formateurs", value: stats.totalFormateurs || 1 },
    { name: "Administrateurs", value: 1 }
  ];

  const COLORS = ["#D4AF37", "#53bdeb", "#ff5555"];

  // 1. Render 2FA Gate if not verified
  if (!is2FAVerified) {
    return (
      <div className="min-h-screen bg-[#0A0A0A] flex flex-col items-center justify-center p-6 text-white font-sans">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(212,175,55,0.06),transparent_40%)] pointer-events-none" />
        
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md bg-[#111111] border border-white/5 rounded-3xl p-8 shadow-2xl relative overflow-hidden"
        >
          {/* Top accent badge */}
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 rounded-full bg-red-600/10 border border-red-500/20 flex items-center justify-center text-red-500 shadow-lg shadow-red-600/5 animate-pulse">
              <ShieldAlert size={32} />
            </div>
          </div>

          <h1 className="text-2xl font-black text-center font-[Space_Grotesk] tracking-tight">
            Double Authentification (2FA)
          </h1>
          <p className="text-gray-400 text-xs text-center mt-2 px-4 leading-relaxed">
            Pour accéder au panneau d'administration d'Auralis, vous devez valider votre clé de sécurité double facteur.
          </p>

          {/* QR Code and Secret Area */}
          <div className="bg-[#181818] border border-white/5 rounded-2xl p-5 mt-6 flex flex-col items-center gap-4">
            {/* Visual Simulated QR Code */}
            <div className="w-36 h-36 bg-white p-2 rounded-xl flex flex-wrap relative shadow-inner">
              {/* QR Patterns */}
              <div className="w-full h-full border-[10px] border-black flex flex-wrap p-1 relative">
                <div className="absolute top-0 left-0 w-6 h-6 border-4 border-black bg-white" />
                <div className="absolute top-0 right-0 w-6 h-6 border-4 border-black bg-white" />
                <div className="absolute bottom-0 left-0 w-6 h-6 border-4 border-black bg-white" />
                <div className="absolute inset-8 bg-black rounded" />
              </div>
            </div>

            <div className="text-center w-full">
              <p className="text-[9px] uppercase tracking-wider font-extrabold text-gray-500">Clé Secrète de Sécurité</p>
              <div className="flex items-center justify-center gap-2 mt-1 bg-black/40 px-3 py-1.5 rounded-lg border border-white/5">
                <Key size={12} className="text-[#D4AF37]" />
                <span className="font-mono text-[10px] tracking-wider text-gray-300">AURALIS-ADMIN-2FA-SECURE</span>
              </div>
            </div>
          </div>

          {/* Interactive input code */}
          <div className="mt-6 space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-gray-400 block text-center">Entrez le code dynamique à 6 chiffres</label>
              <input
                type="text"
                maxLength={6}
                value={enteredCode}
                placeholder="000000"
                onChange={(e) => {
                  const val = e.target.value.replace(/\D/g, "");
                  setEnteredCode(val);
                  if (val.length === 6) {
                    handleVerify2FA(val);
                  }
                }}
                className="w-full text-center bg-black/50 border border-white/10 rounded-2xl py-3 px-4 text-xl tracking-[0.75em] text-[#D4AF37] font-mono outline-none focus:border-[#D4AF37]/50 focus:ring-4 focus:ring-[#D4AF37]/5 transition-all placeholder:tracking-normal placeholder:text-gray-700"
              />
            </div>

            {/* Countdown radial timer indicator */}
            <div className="flex items-center justify-between text-[11px] text-gray-500 bg-white/[0.01] border border-white/5 px-4 py-2.5 rounded-xl">
              <span className="flex items-center gap-1.5">
                <Smartphone size={14} className="text-[#D4AF37]" />
                Rotation du code d'authentification
              </span>
              <span className="font-mono font-bold text-red-500 flex items-center gap-1 animate-pulse">
                <RefreshCw size={11} className="animate-spin [animation-duration:10s]" />
                {countdown}s
              </span>
            </div>

            {/* Simulated test credential badge */}
            <div className="pt-2">
              <button
                onClick={() => {
                  setEnteredCode(current2FACode);
                  handleVerify2FA(current2FACode);
                }}
                className="w-full py-3 bg-gradient-to-r from-[#D4AF37] to-[#F0C940] text-black font-extrabold rounded-2xl text-xs hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-lg shadow-[#D4AF37]/10"
              >
                <CheckCircle2 size={15} /> Déverrouiller en 2FA d'évaluation ({current2FACode})
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    );
  }

  // 2. Main Admin Dashboard View
  return (
    <div className="p-6 md:p-8 space-y-8 max-w-7xl mx-auto text-white">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/5 pb-6">
        <div>
          <span className="text-[10px] uppercase font-black tracking-widest text-[#D4AF37] bg-[#D4AF37]/10 border border-[#D4AF37]/20 px-3 py-1 rounded-full flex items-center gap-1.5 w-fit">
            <Activity size={12} className="text-[#D4AF37]" /> Système de contrôle Auralis
          </span>
          <h1 className="text-3xl font-black mt-2 tracking-tight font-[Space_Grotesk]">
            Superviseur d'Administration
          </h1>
          <p className="text-gray-400 text-xs mt-1">
            Gérez la sécurité du portail, l'infrastructure des messages, les cours et les profils utilisateurs.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={fetchAdminData}
            className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white border border-white/5 transition-all"
            title="Rafraîchir les données"
          >
            <RefreshCw size={16} />
          </button>
          <div className="px-4 py-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl text-xs font-bold flex items-center gap-1.5">
            <Lock size={13} /> Session 2FA Actrice
          </div>
        </div>
      </div>

      {/* Stats Cards Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-[#111] border border-white/5 rounded-2xl p-5 space-y-1 relative overflow-hidden">
          <Users size={20} className="text-[#D4AF37]" />
          <p className="text-2xl font-black text-white">{stats.totalUsers}</p>
          <p className="text-[10px] text-gray-400 font-semibold uppercase">Apprenants & Formateurs</p>
        </div>
        <div className="bg-[#111] border border-white/5 rounded-2xl p-5 space-y-1 relative overflow-hidden">
          <BookOpen size={20} className="text-[#53bdeb]" />
          <p className="text-2xl font-black text-white">{stats.totalCourses}</p>
          <p className="text-[10px] text-gray-400 font-semibold uppercase">Cours au Catalogue</p>
        </div>
        <div className="bg-[#111] border border-white/5 rounded-2xl p-5 space-y-1 relative overflow-hidden">
          <MessageSquare size={20} className="text-emerald-400" />
          <p className="text-2xl font-black text-white">{stats.totalMessages}</p>
          <p className="text-[10px] text-gray-400 font-semibold uppercase">Messages Transités</p>
        </div>
        <div className="bg-[#111] border border-white/5 rounded-2xl p-5 space-y-1 relative overflow-hidden">
          <Award size={20} className="text-red-400" />
          <p className="text-2xl font-black text-white">2FA ACTIF</p>
          <p className="text-[10px] text-gray-400 font-semibold uppercase">Statut de sécurité</p>
        </div>
      </div>

      {/* Recharts Graphical Panels Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Course Enrollment Growth (Line Chart) */}
        <div className="bg-[#111] border border-white/5 rounded-2xl p-5 space-y-4 lg:col-span-2">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm tracking-tight flex items-center gap-2">
              <TrendingUp size={16} className="text-[#D4AF37]" /> Activité de l'Académie Auralis (Hebdomadaire)
            </h3>
            <span className="text-[9px] uppercase bg-white/5 px-2.5 py-1 rounded-full text-gray-400 font-bold">Inscriptions directes</span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={activeUsersData}>
                <defs>
                  <linearGradient id="colorApprenants" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#D4AF37" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#D4AF37" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#222" />
                <XAxis dataKey="name" stroke="#555" fontSize={11} />
                <YAxis stroke="#555" fontSize={11} />
                <Tooltip contentStyle={{ background: "#111", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "12px" }} />
                <Area type="monotone" dataKey="Apprenants" stroke="#D4AF37" strokeWidth={2} fillOpacity={1} fill="url(#colorApprenants)" />
                <Line type="monotone" dataKey="Formateurs" stroke="#53bdeb" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Messaging traffic (Bar Chart) */}
        <div className="bg-[#111] border border-white/5 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm tracking-tight flex items-center gap-2">
              <MessageSquare size={16} className="text-emerald-400" /> Trafic des discussions WhatsApp (Médiation)
            </h3>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={messagingTrafficData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#222" />
                <XAxis dataKey="name" stroke="#555" fontSize={9} />
                <YAxis stroke="#555" fontSize={11} />
                <Tooltip contentStyle={{ background: "#111", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "12px" }} />
                <Bar dataKey="Messages" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Demographics & Profiles Control Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* User Database table */}
        <div className="bg-[#111] border border-white/5 rounded-2xl p-5 space-y-4 lg:col-span-2">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <h3 className="font-bold text-sm tracking-tight flex items-center gap-2">
              <Sliders size={16} className="text-[#D4AF37]" /> Registre des Comptes Utilisateurs
            </h3>
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-3 top-2.5 text-gray-500 w-4 h-4" />
              <input
                type="text"
                placeholder="Rechercher par prénom, nom, rôle..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#181818] border border-white/5 focus:border-[#D4AF37]/30 rounded-xl py-2 pl-9 pr-4 text-xs text-white outline-none placeholder-gray-500"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-white/5 text-[10px] text-gray-500 uppercase font-black tracking-wider">
                  <th className="pb-3">Utilisateur</th>
                  <th className="pb-3">Pseudo</th>
                  <th className="pb-3">Rôle</th>
                  <th className="pb-3">Points</th>
                  <th className="pb-3">Sécurité / Blocage</th>
                  <th className="pb-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {loading ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-xs text-gray-500">
                      Chargement des tuteurs et apprenants...
                    </td>
                  </tr>
                ) : filteredProfiles.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-xs text-gray-500">
                      Aucun profil utilisateur trouvé pour "{searchQuery}"
                    </td>
                  </tr>
                ) : (
                  filteredProfiles.map((prof) => {
                    const isBlocked = prof.niveau_global === "blocked";
                    return (
                      <tr key={prof.id} className="text-xs hover:bg-white/[0.01]">
                        <td className="py-3.5 font-bold text-white flex items-center gap-2">
                          <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center border border-white/10 font-bold text-[#D4AF37]">
                            {prof.prenom?.charAt(0)?.toUpperCase()}
                          </div>
                          <div>
                            <p>{prof.prenom} {prof.nom}</p>
                            <span className="text-[10px] text-gray-500 font-normal">Inscrit en 2026</span>
                          </div>
                        </td>
                        <td className="py-3.5 text-gray-400 font-mono">@{prof.pseudo || "non-défini"}</td>
                        <td className="py-3.5">
                          <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-extrabold uppercase ${
                            prof.role === "admin"
                              ? "bg-red-500/10 text-red-400 border border-red-500/20"
                              : prof.role === "formateur"
                              ? "bg-blue-500/10 text-blue-400 border border-blue-500/20"
                              : "bg-[#D4AF37]/10 text-[#D4AF37] border border-[#D4AF37]/20"
                          }`}>
                            {prof.role === "admin" ? "Admin" : prof.role === "formateur" ? "Professeur" : "Apprenant"}
                          </span>
                        </td>
                        <td className="py-3.5 font-bold text-gray-300">{prof.points || 0} xp</td>
                        <td className="py-3.5">
                          <span className={`inline-flex items-center gap-1 text-[10px] font-bold ${
                            isBlocked ? "text-red-500" : "text-emerald-500"
                          }`}>
                            <span className={`w-1.5 h-1.5 rounded-full ${isBlocked ? "bg-red-500" : "bg-emerald-500 animate-pulse"}`} />
                            {isBlocked ? "Bloqué" : "Actif / Autorisé"}
                          </span>
                        </td>
                        <td className="py-3.5 text-right space-x-2">
                          {/* Block/Unblock toggle */}
                          <button
                            onClick={() => handleToggleBlock(prof)}
                            className={`p-1.5 rounded-lg border transition-all ${
                              isBlocked
                                ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20"
                                : "bg-red-500/10 border-red-500/30 text-red-400 hover:bg-red-500/20"
                            }`}
                            title={isBlocked ? "Débloquer le compte" : "Bloquer le compte"}
                          >
                            {isBlocked ? <UserCheck size={14} /> : <UserX size={14} />}
                          </button>
                          {/* Configure edit details */}
                          <button
                            onClick={() => {
                              setSelectedProfile(prof);
                              setEditPrenom(prof.prenom || "");
                              setEditNom(prof.nom || "");
                              setEditPseudo(prof.pseudo || "");
                              setEditRole(prof.role || "apprenant");
                              setEditPoints(prof.points || 0);
                              setIsEditModalOpen(true);
                            }}
                            className="p-1.5 rounded-lg bg-neutral-800 border border-white/5 hover:border-[#D4AF37]/30 text-gray-400 hover:text-[#D4AF37] transition-all"
                            title="Modifier les détails"
                          >
                            <Edit3 size={14} />
                          </button>
                          {/* Delete Account */}
                          <button
                            onClick={() => handleDeleteProfile(prof.id)}
                            className="p-1.5 rounded-lg bg-red-600/10 border border-red-600/20 hover:bg-red-600/20 text-red-400 transition-all"
                            title="Supprimer définitivement"
                          >
                            <Trash2 size={14} />
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Demographics breakdown (Pie chart) */}
        <div className="bg-[#111] border border-white/5 rounded-2xl p-5 space-y-4">
          <h3 className="font-bold text-sm tracking-tight">Répartition des Rôles</h3>
          <div className="h-44 w-full flex items-center justify-center relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={70}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ background: "#111", border: "1px solid rgba(255,255,255,0.08)", borderRadius: "12px" }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="space-y-2.5 pt-4 border-t border-white/5">
            {pieData.map((d, index) => (
              <div key={d.name} className="flex items-center justify-between text-xs">
                <span className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[index] }} />
                  <span className="text-gray-400">{d.name}</span>
                </span>
                <span className="font-bold">{d.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Edit Configure Account Modal Overlay */}
      <AnimatePresence>
        {isEditModalOpen && selectedProfile && (
          <div className="fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-md bg-[#121212] border border-white/10 rounded-3xl overflow-hidden shadow-2xl p-6"
            >
              <div className="flex justify-between items-center pb-4 border-b border-white/5">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Sliders size={18} className="text-[#D4AF37]" /> Paramétrer le compte
                </h3>
                <button
                  onClick={() => setIsEditModalOpen(false)}
                  className="p-1 hover:bg-white/5 rounded-full text-gray-400 hover:text-white"
                >
                  <X size={16} />
                </button>
              </div>

              <form onSubmit={handleUpdateProfile} className="space-y-4 mt-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <label className="text-xs text-gray-400">Prénom</label>
                    <input
                      type="text"
                      value={editPrenom}
                      onChange={(e) => setEditPrenom(e.target.value)}
                      className="w-full bg-[#181818] border border-white/5 rounded-xl py-2 px-3 text-xs outline-none focus:border-[#D4AF37]/40 text-white"
                      required
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs text-gray-400">Nom</label>
                    <input
                      type="text"
                      value={editNom}
                      onChange={(e) => setEditNom(e.target.value)}
                      className="w-full bg-[#181818] border border-white/5 rounded-xl py-2 px-3 text-xs outline-none focus:border-[#D4AF37]/40 text-white"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs text-gray-400">Nom d'utilisateur (Pseudo)</label>
                  <input
                    type="text"
                    value={editPseudo}
                    onChange={(e) => setEditPseudo(e.target.value)}
                    className="w-full bg-[#181818] border border-white/5 rounded-xl py-2 px-3 text-xs outline-none focus:border-[#D4AF37]/40 text-white font-mono"
                    required
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs text-gray-400">Rôle de l'utilisateur</label>
                  <select
                    value={editRole}
                    onChange={(e) => setEditRole(e.target.value)}
                    className="w-full bg-[#181818] border border-white/5 rounded-xl py-2 px-3 text-xs outline-none focus:border-[#D4AF37]/40 text-white"
                  >
                    <option value="apprenant">Apprenant (Étudiant)</option>
                    <option value="formateur">Formateur (Enseignant)</option>
                    <option value="admin">Administrateur système</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs text-gray-400">Score global d'expérience (XP)</label>
                  <input
                    type="number"
                    value={editPoints}
                    onChange={(e) => setEditPoints(Number(e.target.value))}
                    className="w-full bg-[#181818] border border-white/5 rounded-xl py-2 px-3 text-xs outline-none focus:border-[#D4AF37]/40 text-white font-bold"
                  />
                </div>

                <div className="flex gap-3 pt-4 border-t border-white/5 mt-6">
                  <button
                    type="button"
                    onClick={() => setIsEditModalOpen(false)}
                    className="flex-1 py-2.5 bg-neutral-800 hover:bg-neutral-700 rounded-xl text-xs font-bold transition-all text-white"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 bg-gradient-to-r from-[#D4AF37] to-[#F0C940] text-black rounded-xl text-xs font-black transition-all hover:scale-105"
                  >
                    Enregistrer les modifications
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

// Custom simple closing component icon fallback
function X({ size }: { size: number }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-x">
      <path d="M18 6 6 18"/><path d="m6 6 12 12"/>
    </svg>
  );
}
