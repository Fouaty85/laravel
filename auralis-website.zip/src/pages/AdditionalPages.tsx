import { useState, useEffect, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { motion, AnimatePresence } from "framer-motion";
import {
  BookOpen,
  Trophy,
  MessageSquare,
  Bell,
  PlusCircle,
  Play,
  Sparkles,
  Send,
  Check,
  ChevronRight,
  Flame,
  Search,
  BookMarked,
  Users,
  Mic,
  MicOff,
  Smile,
  Phone,
  Video,
  VideoOff,
  MoreVertical,
  Paperclip,
  CheckCheck,
  Volume2,
  VolumeX,
  Pause,
  X,
  ChevronLeft,
  User,
  Youtube,
  Bot
} from "lucide-react";
import { toast } from "sonner";
import type { Profile, Course, Enrollment, Message } from "@/types";
import {
  calculateLevelFromXP,
  getRoleTitle,
  formatFullLevelLabel,
  calculateComprehensionLevel,
  awardXP,
} from "@/lib/gamification";
import { askAuralisAIAboutCourse, type YouTubeCourseContext } from "@/lib/auralisAI";
import { auralisLogo } from "@/lib/assets";

export const AURALIS_CONTACT: Profile = {
  id: "auralis-ai-avatar",
  prenom: "Auralis",
  nom: "IA Pédagogique",
  pseudo: "Auralis_IA",
  role: "admin",
  avatar_url: auralisLogo,
  niveau_global: "Niveau 500 - IA Pédagogique Universelle",
  niveau_comprehension: "100% - Tutorat & Recherche",
  points: 99999,
  is_onboarded: true,
  created_at: "2026-01-01T00:00:00.000Z",
  derniere_connexion: new Date().toISOString(),
  streak_jours: 365,
};

type EnrollmentWithCourse = Enrollment & { courses: Course | null };

interface LocalMessage {
  id: string;
  sender_id: string | undefined;
  sender_name: string;
  content: string;
  created_at: string;
}

interface LocalNotification {
  id: string;
  title: string;
  message: string;
  date: string;
  unread: boolean;
}

// ============================================================================
// 1. MES COURS (Learner / Apprenant Course Browser & Enrollments)
// ============================================================================
export function MesCours() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [enrolled, setEnrolled] = useState<EnrollmentWithCourse[]>([]);
  const [allCourses, setAllCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("Tous");

  // YouTube states
  const [youtubeVideos, setYoutubeVideos] = useState<unknown[]>([]);
  const [loadingYouTube, setLoadingYouTube] = useState(false);
  const [selectedVideoId, setSelectedVideoId] = useState<string | null>(null);
  const [selectedVideoTitle, setSelectedVideoTitle] = useState<string>("");

  const categories = ["Tous", "Développement", "Langues", "IA & Tech", "Business", "Design"];

  const fetchCourses = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      // 1. Fetch current enrollments
      const { data: enrollData } = await supabase
        .from("enrollments")
        .select("*, courses(*)")
        .eq("user_id", user.id);

      // 2. Fetch all available courses
      const { data: courseData } = await supabase
        .from("courses")
        .select("*");

      if (enrollData) {
        setEnrolled(enrollData as EnrollmentWithCourse[]);
      }
      if (courseData) {
        setAllCourses(courseData as Course[]);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    fetchCourses();
  }, [fetchCourses]);

  const handleEnroll = async (courseId: string) => {
    if (!user) return;
    try {
      const { error } = await supabase
        .from("enrollments")
        .insert([{ user_id: user.id, course_id: courseId, progression: 0 }]);

      if (error) throw error;

      await awardXP({
        userId: user.id,
        amount: 30,
        actionName: "Inscription à un nouveau cours",
        userRole: "apprenant",
      });

      toast.success("Inscription réussie ! +30 XP attribués !");
      fetchCourses();
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : String(err);
      toast.error("Erreur lors de l'inscription: " + errorMsg);
    }
  };

  // Filter Active Enrolled Courses
  const filteredEnrolled = enrolled.filter((enroll) => {
    const course = enroll.courses;
    if (!course) return false;

    const matchesSearch =
      course.titre.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.langue?.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory =
      selectedCategory === "Tous" ||
      course.langue?.toLowerCase().includes(selectedCategory.toLowerCase()) ||
      course.titre.toLowerCase().includes(selectedCategory.toLowerCase());

    return matchesSearch && matchesCategory;
  });

  // Filter Catalog Courses
  const filteredAllCourses = allCourses.filter((c) => {
    const matchesSearch =
      c.titre.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.langue?.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory =
      selectedCategory === "Tous" ||
      c.langue?.toLowerCase().includes(selectedCategory.toLowerCase()) ||
      c.titre.toLowerCase().includes(selectedCategory.toLowerCase());

    return matchesSearch && matchesCategory;
  });

  // Trigger YouTube Search if no local course matches and query is typed
  useEffect(() => {
    if (!searchQuery.trim()) {
      setYoutubeVideos([]);
      return;
    }

    const hasLocalMatch = allCourses.some((c) =>
      c.titre.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.description?.toLowerCase().includes(searchQuery.toLowerCase())
    );

    if (hasLocalMatch) {
      setYoutubeVideos([]);
      return;
    }

    const delayDebounce = setTimeout(async () => {
      setLoadingYouTube(true);
      try {
        const apiKey = import.meta.env.VITE_YOUTUBE_API_KEY || "AIzaSyB_5UewwOsxhrrRi2ejRfBuh8t-e2j6lBg";
        const url = `https://www.googleapis.com/youtube/v3/search?part=snippet&q=${encodeURIComponent(
          searchQuery + " cours tutoriel complet"
        )}&type=video&maxResults=6&key=${apiKey}`;
        const res = await fetch(url);
        const data = await res.json();
        if (data && data.items) {
          setYoutubeVideos(data.items);
        } else {
          setYoutubeVideos([]);
        }
      } catch (err) {
        console.error("Error fetching YouTube videos:", err);
        setYoutubeVideos([]);
      } finally {
        setLoadingYouTube(false);
      }
    }, 600);

    return () => clearTimeout(delayDebounce);
  }, [searchQuery, allCourses]);

  const scrollToCatalog = () => {
    const catalogElem = document.getElementById("catalog-section");
    if (catalogElem) {
      catalogElem.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-7xl mx-auto text-white">
      {/* Header section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight font-[Space_Grotesk]">
            Espace d'Apprentissage & Mes Cours
          </h1>
          <p className="text-gray-400 text-sm mt-1">
            Suivez votre progression en temps réel et explorez nos parcours académiques.
          </p>
        </div>

        {/* Global Search Bar */}
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3 top-2.5 text-[#D4AF37]" size={16} />
          <input
            type="text"
            placeholder="Filtrer mes cours par titre, catégorie..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#141414] border border-white/10 focus:border-[#D4AF37] rounded-xl py-2 pl-9 pr-8 text-xs text-white placeholder-gray-500 outline-none transition-all shadow-inner"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              className="absolute right-2.5 top-2.5 text-gray-500 hover:text-white"
            >
              <X size={14} />
            </button>
          )}
        </div>
      </div>

      {/* Category Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 custom-scrollbar">
        <span className="text-xs font-semibold text-gray-500 mr-2 flex-shrink-0">Catégorie:</span>
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all flex-shrink-0 border ${
              selectedCategory === cat
                ? "bg-[#D4AF37] text-black border-[#D4AF37] shadow-md shadow-[#D4AF37]/20"
                : "bg-[#141414] text-gray-400 border-white/5 hover:border-white/20 hover:text-white"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* SECTION 1: Mes Cours Suivis / Active Enrolled Courses */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold flex items-center gap-2 text-[#D4AF37]">
            <BookMarked size={20} /> Vos cours en cours
          </h2>
          <span className="text-xs font-medium text-gray-400">
            {filteredEnrolled.length} cours actif{filteredEnrolled.length > 1 ? "s" : ""}
          </span>
        </div>

        {filteredEnrolled.length === 0 ? (
          /* PROFESSIONAL EMPTY STATE COMPONENT FOR MES COURS */
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-[#121212] border border-white/5 rounded-3xl p-8 md:p-12 text-center flex flex-col items-center justify-center space-y-4 shadow-xl relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-radial from-[#D4AF37]/5 via-transparent to-transparent pointer-events-none" />
            
            <div className="w-16 h-16 rounded-full bg-[#D4AF37]/10 border border-[#D4AF37]/30 text-[#D4AF37] flex items-center justify-center shadow-lg shadow-[#D4AF37]/10">
              <BookOpen size={30} />
            </div>

            <div className="max-w-md space-y-1.5">
              <h3 className="text-lg font-bold text-white font-[Space_Grotesk]">
                {searchQuery || selectedCategory !== "Tous"
                  ? "Aucun cours ne correspond à vos filtres actuels"
                  : "Vous n'avez pas encore de cours actif"}
              </h3>
              <p className="text-xs text-gray-400 leading-relaxed">
                {searchQuery || selectedCategory !== "Tous"
                  ? "Essayez de modifier votre recherche ou réinitialisez les filtres pour afficher l'ensemble de vos inscriptions."
                  : "Inscrivez-vous dès maintenant à un cours dans notre catalogue académique pour suivre votre progression pas à pas."}
              </p>
            </div>

            <div className="pt-2 flex items-center gap-3">
              {searchQuery || selectedCategory !== "Tous" ? (
                <button
                  onClick={() => {
                    setSearchQuery("");
                    setSelectedCategory("Tous");
                  }}
                  className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-bold transition-all border border-white/10"
                >
                  Réinitialiser les filtres
                </button>
              ) : (
                <button
                  onClick={scrollToCatalog}
                  className="px-5 py-2.5 bg-gradient-to-r from-[#D4AF37] to-[#F0C940] hover:scale-105 active:scale-95 text-black rounded-xl text-xs font-bold transition-all shadow-lg shadow-[#D4AF37]/15 flex items-center gap-2"
                >
                  <Sparkles size={14} /> Explorer le catalogue de cours
                </button>
              )}
            </div>
          </motion.div>
        ) : (
          /* ACTIVE ENROLLED COURSES GRID WITH VISUAL PROGRESS TRACKING */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredEnrolled.map((enroll) => {
              const prog = Math.min(100, Math.max(0, enroll.progression ?? 0));
              const isCompleted = prog >= 100;
              const statusText = isCompleted ? "Terminé !" : prog > 0 ? "En cours" : "Non démarré";
              const completedModules = Math.round((prog / 100) * 8);

              return (
                <motion.div
                  key={enroll.id}
                  whileHover={{ scale: 1.025, y: -4 }}
                  transition={{ duration: 0.25, ease: "easeOut" }}
                  className="bg-[#141414] border border-white/5 hover:border-[#D4AF37]/40 rounded-2xl overflow-hidden p-5 flex flex-col justify-between transition-all duration-300 hover:shadow-xl hover:shadow-[#D4AF37]/10 group cursor-pointer"
                >
                  <div>
                    {/* Header badges */}
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[10px] uppercase font-bold text-[#D4AF37] px-2.5 py-1 bg-[#D4AF37]/10 border border-[#D4AF37]/20 rounded-full">
                        {enroll.courses?.langue || "Général"}
                      </span>

                      {/* Percentage Badge */}
                      <span
                        className={`text-[11px] font-extrabold px-2.5 py-0.5 rounded-full border ${
                          isCompleted
                            ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30"
                            : "bg-[#D4AF37]/15 text-[#D4AF37] border-[#D4AF37]/30"
                        }`}
                      >
                        {prog}% complet
                      </span>
                    </div>

                    <h3 className="font-bold text-lg text-white mt-3.5 group-hover:text-[#D4AF37] transition-colors line-clamp-1">
                      {enroll.courses?.titre}
                    </h3>
                    <p className="text-gray-400 text-xs mt-1.5 line-clamp-2 leading-relaxed">
                      {enroll.courses?.description}
                    </p>
                  </div>

                  {/* VISUAL PROGRESS TRACKING SECTION */}
                  <div className="mt-6 space-y-3.5 pt-3 border-t border-white/5">
                    <div className="flex items-center justify-between text-xs text-gray-400 font-medium">
                      <span className="flex items-center gap-1.5">
                        <span className={`w-2 h-2 rounded-full ${isCompleted ? "bg-emerald-400" : "bg-[#D4AF37]"}`} />
                        {statusText}
                      </span>
                      <span className="text-gray-300 font-mono text-[11px]">
                        {completedModules}/8 modules
                      </span>
                    </div>

                    {/* Progress Bar Container */}
                    <div className="relative w-full h-2 bg-neutral-900 border border-white/5 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${prog}%` }}
                        transition={{ duration: 0.8, ease: "easeOut" }}
                        className={`h-full rounded-full transition-all duration-500 ${
                          isCompleted
                            ? "bg-gradient-to-r from-emerald-500 to-teal-400 shadow-[0_0_10px_rgba(16,185,129,0.5)]"
                            : "bg-gradient-to-r from-[#D4AF37] via-[#F0C940] to-amber-300 shadow-[0_0_10px_rgba(212,175,55,0.4)]"
                        }`}
                      />
                    </div>

                    {/* Continuation CTA */}
                    <button className="w-full flex items-center justify-center gap-2 py-2.5 bg-white/5 group-hover:bg-[#D4AF37] group-hover:text-black rounded-xl text-xs font-bold text-white border border-white/10 group-hover:border-[#D4AF37] transition-all shadow-md">
                      <Play size={13} className="fill-current" />
                      {isCompleted ? "Revoir le cours" : "Continuer l'apprentissage"}
                    </button>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* SECTION 2: Catalogue des Cours / Course Directory */}
      <div id="catalog-section" className="space-y-6 pt-6 border-t border-white/10">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold flex items-center gap-2 text-white">
            <BookOpen size={20} className="text-[#D4AF37]" /> Catalogue de cours disponibles
          </h2>
          <span className="text-xs text-gray-400 font-medium">
            {filteredAllCourses.length} cours répertorié{filteredAllCourses.length > 1 ? "s" : ""}
          </span>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-2 border-[#D4AF37]/20 border-t-[#D4AF37] animate-spin rounded-full" />
          </div>
        ) : filteredAllCourses.length === 0 ? (
          /* NO DATABASE COURSE FOUND -> LOAD REAL-TIME YOUTUBE RESULTS */
          <div className="space-y-6">
            <div className="text-center py-8 bg-[#111]/40 rounded-2xl border border-white/5 px-4">
              <p className="text-gray-400 text-sm">
                Aucun cours direct "<strong>{searchQuery}</strong>" dans la base de données Auralis.
              </p>
              <p className="text-gray-500 text-xs mt-1">
                Auralis recherche des cours complets en temps réel sur YouTube pour vous...
              </p>
            </div>

            {loadingYouTube ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="bg-[#111] border border-white/5 rounded-2xl p-4 space-y-4 animate-pulse">
                    <div className="aspect-video bg-neutral-800 rounded-xl w-full" />
                    <div className="h-4 bg-neutral-800 rounded w-3/4" />
                    <div className="h-3 bg-neutral-800 rounded w-1/2" />
                  </div>
                ))}
              </div>
            ) : youtubeVideos.length === 0 ? (
              <div className="text-center py-12 text-gray-600 text-xs">
                Aucune vidéo de cours trouvée pour "{searchQuery}". Essayez un autre sujet d'apprentissage.
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-[#D4AF37] flex items-center gap-2">
                    <Youtube size={16} className="text-red-500" /> Cours d'apprentissage en direct (YouTube)
                  </h3>
                  <span className="text-[10px] text-gray-500 font-medium">Recherche instantanée et sécurisée</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {youtubeVideos.map((video) => {
                    const videoId = (video as { id?: { videoId?: string } })?.id?.videoId;
                    if (!videoId) return null;
                    const snippet = (video as { snippet: { title: string; channelTitle: string; description: string; thumbnails?: { high?: { url: string }; medium?: { url: string } } } }).snippet;
                    return (
                      <motion.div
                        key={videoId}
                        whileHover={{ scale: 1.025, y: -4 }}
                        transition={{ duration: 0.25, ease: "easeOut" }}
                        onClick={() => {
                          setSelectedVideoId(videoId);
                          setSelectedVideoTitle(snippet.title);
                        }}
                        className="bg-[#111] border border-white/5 hover:border-red-500/30 rounded-2xl overflow-hidden shadow-lg hover:shadow-xl hover:shadow-red-500/5 p-4 flex flex-col justify-between cursor-pointer group transition-all duration-300"
                      >
                        <div className="space-y-3">
                          {/* Thumbnail with hover icon */}
                          <div className="relative aspect-video rounded-xl overflow-hidden bg-neutral-900 border border-white/5">
                            <img
                              src={snippet.thumbnails?.high?.url || snippet.thumbnails?.medium?.url}
                              alt={snippet.title}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            />
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                              <div className="w-12 h-12 rounded-full bg-red-600 flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-transform duration-300">
                                <Play size={20} className="fill-white text-white translate-x-0.5" />
                              </div>
                            </div>
                            <span className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded bg-black/80 text-[9px] font-mono font-bold tracking-wider text-white">
                              YOUTUBE LIVE
                            </span>
                          </div>

                          <div>
                            <h4
                              className="font-bold text-sm text-white line-clamp-2 leading-snug group-hover:text-red-400 transition-colors"
                              dangerouslySetInnerHTML={{ __html: snippet.title }}
                            />
                            <p className="text-gray-500 text-[11px] font-semibold mt-1.5 flex items-center gap-1">
                              <span>{snippet.channelTitle}</span>
                              <span className="w-1 h-1 bg-gray-600 rounded-full" />
                              <span>Cours externe</span>
                            </p>
                            <p className="text-gray-400 text-xs mt-2 line-clamp-2 leading-relaxed">
                              {snippet.description}
                            </p>
                          </div>
                        </div>

                        <div className="mt-4 pt-3 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-2">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedVideoId(videoId);
                              setSelectedVideoTitle(snippet.title);
                            }}
                            className="w-full sm:w-auto text-[11px] font-bold text-red-500 hover:text-red-400 flex items-center justify-center gap-1 py-1 px-2.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 transition-all"
                          >
                            <Play size={12} className="fill-current" /> Visionner
                          </button>
                          
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              localStorage.setItem(
                                "auralis_active_youtube_course",
                                JSON.stringify({
                                  videoId,
                                  title: snippet.title,
                                  channelTitle: snippet.channelTitle,
                                  description: snippet.description,
                                })
                              );
                              toast.info("Redirection vers la messagerie Auralis...", {
                                description: `Posez vos questions sur "${snippet.title.slice(0, 30)}..."`
                              });
                              navigate("/messages");
                            }}
                            className="w-full sm:w-auto text-[11px] font-bold text-[#D4AF37] hover:text-amber-300 flex items-center justify-center gap-1 py-1 px-2.5 rounded-lg bg-[#D4AF37]/10 hover:bg-[#D4AF37]/20 border border-[#D4AF37]/20 transition-all"
                          >
                            <Bot size={13} /> Poser une question à Auralis
                          </button>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAllCourses.map((course) => {
              const isEnrolled = enrolled.some((e) => e.course_id === course.id);
              return (
                <motion.div
                  key={course.id}
                  whileHover={{ scale: 1.025, y: -4 }}
                  transition={{ duration: 0.25, ease: "easeOut" }}
                  className="bg-[#111] border border-white/5 hover:border-[#D4AF37]/30 rounded-2xl p-5 flex flex-col justify-between transition-all duration-300 hover:shadow-xl hover:shadow-[#D4AF37]/10 group"
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] uppercase font-bold text-[#D4AF37] px-2.5 py-1 bg-[#D4AF37]/10 rounded-full">
                        {course.langue}
                      </span>
                      <span className="text-[11px] text-gray-500 font-medium">
                        Niveau: {course.niveau_cible}
                      </span>
                    </div>
                    <h3 className="font-bold text-lg text-white mt-3 group-hover:text-[#D4AF37] transition-colors">
                      {course.titre}
                    </h3>
                    <p className="text-gray-400 text-xs mt-2 line-clamp-3 leading-relaxed">
                      {course.description}
                    </p>
                  </div>
                  <div className="mt-6">
                    {isEnrolled ? (
                      <div className="flex items-center justify-center gap-1.5 py-2.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-xl text-xs font-bold">
                        <Check size={14} /> Déjà inscrit
                      </div>
                    ) : (
                      <button
                        onClick={() => handleEnroll(course.id)}
                        className="w-full py-2.5 bg-gradient-to-r from-[#D4AF37] to-[#F0C940] hover:scale-[1.02] active:scale-[0.98] text-[#0A0A0A] rounded-xl text-xs font-bold transition-all shadow-lg shadow-[#D4AF37]/5"
                      >
                        S'inscrire au cours
                      </button>
                    )}
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* YouTube Safe Player Modal */}
      <AnimatePresence>
        {selectedVideoId && (
          <div className="fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-4xl bg-[#121212] border border-white/10 rounded-3xl overflow-hidden shadow-2xl flex flex-col"
            >
              {/* Header */}
              <div className="px-6 py-4 border-b border-white/5 flex items-center justify-between bg-black/40">
                <div className="flex items-center gap-2 min-w-0">
                  <Youtube className="text-red-500 flex-shrink-0" size={20} />
                  <h3
                    className="font-bold text-sm text-white truncate pr-4"
                    dangerouslySetInnerHTML={{ __html: selectedVideoTitle }}
                  />
                </div>
                <button
                  onClick={() => {
                    setSelectedVideoId(null);
                    setSelectedVideoTitle("");
                  }}
                  className="p-1.5 hover:bg-white/10 rounded-full text-gray-400 hover:text-white transition-colors"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Secure Embed Player - Playable 100% on Auralis platform */}
              <div className="aspect-video w-full bg-black relative">
                <iframe
                  className="w-full h-full"
                  src={`https://www.youtube-nocookie.com/embed/${selectedVideoId}?autoplay=1&rel=0&enablejsapi=1`}
                  title={selectedVideoTitle}
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  allowFullScreen
                  referrerPolicy="strict-origin-when-cross-origin"
                ></iframe>
              </div>

              {/* Actions/Footer */}
              <div className="px-6 py-4 bg-black/20 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-xs">
                <div className="flex flex-col gap-1.5 max-w-md">
                  <p className="text-gray-400 leading-snug">
                    Ce cours externe a été trouvé par Auralis pour compléter votre apprentissage.
                  </p>
                  <a
                    href={`https://www.youtube.com/watch?v=${selectedVideoId}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-red-400 hover:underline flex items-center gap-1 font-semibold text-[11px]"
                  >
                    Ouvrir sur YouTube ↗
                  </a>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      localStorage.setItem(
                        "auralis_active_youtube_course",
                        JSON.stringify({
                          videoId: selectedVideoId,
                          title: selectedVideoTitle,
                          channelTitle: "Cours YouTube recherché par Auralis",
                          description: selectedVideoTitle,
                        })
                      );
                      setSelectedVideoId(null);
                      toast.info("Redirection vers la messagerie Auralis...", {
                        description: `Discutez avec Auralis sur "${selectedVideoTitle.slice(0, 30)}..."`,
                      });
                      navigate("/messages");
                    }}
                    className="px-4 py-2 bg-[#D4AF37]/10 hover:bg-[#D4AF37]/20 border border-[#D4AF37]/30 text-[#D4AF37] rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-md shadow-[#D4AF37]/5"
                  >
                    <Bot size={16} /> Poser une question à Auralis
                  </button>

                  <button
                    onClick={() => {
                      toast.success("Cours enregistré dans vos favoris d'apprentissage !");
                      setSelectedVideoId(null);
                    }}
                    className="px-4 py-2 bg-gradient-to-r from-[#D4AF37] to-[#F0C940] hover:scale-105 active:scale-95 text-[#0A0A0A] rounded-xl font-bold transition-all shadow-md text-xs"
                  >
                    Ajouter aux favoris
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ============================================================================
// 2. CLASSEMENT (Durable leaderboard querying profile table desc)
// ============================================================================
export function Classement() {
  const { profile } = useAuth();
  const [leaders, setLeaders] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchLeaderboard = useCallback(async () => {
    try {
      const { data } = await supabase
        .from("profiles")
        .select("*")
        .order("points", { ascending: false })
        .limit(10);
      if (data) {
        setLeaders(data as Profile[]);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchLeaderboard();

    const handleLocalUpdate = () => {
      fetchLeaderboard();
    };
    window.addEventListener("profile-updated", handleLocalUpdate);

    // Subscribe to realtime changes on profiles for live leaderboard updates
    const channel = supabase
      .channel("leaderboard-realtime")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "profiles",
        },
        () => {
          fetchLeaderboard();
        }
      )
      .subscribe();

    return () => {
      window.removeEventListener("profile-updated", handleLocalUpdate);
      supabase.removeChannel(channel);
    };
  }, [fetchLeaderboard]);

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-4xl mx-auto text-white">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight font-[Space_Grotesk]">
            Classement de l'Académie
          </h1>
          <p className="text-gray-400 text-sm mt-1">
            Mesurez-vous aux meilleurs apprenants d'Auralis. Accumulez des points pour grimper !
          </p>
        </div>
        <div className="inline-flex items-center gap-2 bg-[#D4AF37]/10 border border-[#D4AF37]/30 px-3.5 py-1.5 rounded-full text-xs text-[#D4AF37] font-semibold shadow-sm self-start md:self-auto">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span className="w-2 h-2 rounded-full bg-emerald-500 -ml-4" />
          Mise à jour en temps réel
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-2 border-[#D4AF37]/20 border-t-[#D4AF37] animate-spin rounded-full" />
        </div>
      ) : (
        <div className="space-y-4">
          {/* Top 3 Cards visual podium */}
          <div className="grid grid-cols-3 gap-4 items-end pb-4 pt-2">
            {/* 2nd Place */}
            {leaders[1] && (
              <div className="bg-[#111]/80 border border-white/5 rounded-2xl p-4 flex flex-col items-center justify-center text-center h-[160px] relative">
                <div className="absolute -top-4 w-8 h-8 rounded-full bg-slate-300 text-black font-bold flex items-center justify-center text-sm shadow-md">2</div>
                <div className="w-10 h-10 rounded-full bg-slate-300/20 text-slate-300 flex items-center justify-center text-base font-bold">
                  {leaders[1].prenom?.charAt(0) || "U"}
                </div>
                <span className="font-bold text-xs mt-2 text-white truncate max-w-full">{leaders[1].prenom}</span>
                <span className="text-[10px] text-[#D4AF37] font-semibold mt-1">{leaders[1].points || 0} pts</span>
              </div>
            )}

            {/* 1st Place */}
            {leaders[0] && (
              <div className="bg-[#161616] border border-[#D4AF37]/30 rounded-2xl p-4 flex flex-col items-center justify-center text-center h-[180px] relative shadow-xl shadow-[#D4AF37]/5">
                <div className="absolute -top-5 w-10 h-10 rounded-full bg-[#D4AF37] text-black font-bold flex items-center justify-center text-base shadow-lg animate-bounce">👑</div>
                <div className="w-12 h-12 rounded-full bg-[#D4AF37]/20 text-[#D4AF37] flex items-center justify-center text-lg font-bold border border-[#D4AF37]/40">
                  {leaders[0].prenom?.charAt(0) || "U"}
                </div>
                <span className="font-bold text-sm mt-2 text-white truncate max-w-full">{leaders[0].prenom}</span>
                <span className="text-xs text-[#D4AF37] font-bold mt-1 flex items-center gap-1">
                  <Sparkles size={12} /> {leaders[0].points || 0} pts
                </span>
              </div>
            )}

            {/* 3rd Place */}
            {leaders[2] && (
              <div className="bg-[#111]/80 border border-white/5 rounded-2xl p-4 flex flex-col items-center justify-center text-center h-[140px] relative">
                <div className="absolute -top-4 w-8 h-8 rounded-full bg-amber-700 text-white font-bold flex items-center justify-center text-sm shadow-md">3</div>
                <div className="w-10 h-10 rounded-full bg-amber-700/20 text-amber-500 flex items-center justify-center text-base font-bold">
                  {leaders[2].prenom?.charAt(0) || "U"}
                </div>
                <span className="font-bold text-xs mt-2 text-white truncate max-w-full">{leaders[2].prenom}</span>
                <span className="text-[10px] text-[#D4AF37] font-semibold mt-1">{leaders[2].points || 0} pts</span>
              </div>
            )}
          </div>

          {/* Ranking List */}
          <div className="bg-[#111] border border-white/5 rounded-2xl overflow-hidden divide-y divide-white/5">
            {leaders.map((leader, idx) => {
              const isMe = leader.id === profile?.id;
              const leaderLevel = calculateLevelFromXP(leader.points || 0);
              const leaderTitle = getRoleTitle(leaderLevel, leader.role || "apprenant");
              const leaderDisplay = leader.niveau_global || `Niveau ${leaderLevel} - ${leaderTitle}`;

              return (
                <div
                  key={leader.id}
                  className={`flex items-center justify-between p-4 transition-colors ${
                    isMe ? "bg-[#D4AF37]/10" : "hover:bg-white/[0.02]"
                  }`}
                >
                  <div className="flex items-center gap-4">
                    <span className="w-6 text-center font-bold text-sm text-gray-500">
                      {idx + 1}
                    </span>
                    <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-white font-bold border border-white/10 text-sm">
                      {leader.prenom?.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <div className="font-bold text-sm flex items-center gap-2 text-white">
                        {leader.prenom} {leader.nom}
                        {isMe && <span className="text-[9px] bg-[#D4AF37] text-black px-1.5 py-0.5 rounded-md font-bold uppercase">Vous</span>}
                      </div>
                      <div className="text-[#D4AF37] font-semibold text-xs">{leaderDisplay}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-6">
                    {leader.streak_jours && leader.streak_jours > 0 ? (
                      <div className="flex items-center gap-1 text-orange-500 font-bold text-xs bg-orange-500/10 px-2 py-1 rounded-full">
                        <Flame size={12} className="fill-orange-500" /> {leader.streak_jours}j
                      </div>
                    ) : null}
                    <span className="font-bold text-[#D4AF37] text-sm">
                      {leader.points || 0} XP
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================================
// 3. MESSAGES (Discussion space - Rich WhatsApp style with Voice, Stickers, Emojis & Realtime)
// ============================================================================

// Helper components for the rich message types
const AudioPlayer = ({ durationStr }: { durationStr: string }) => {
  const duration = parseInt(durationStr) || 5;
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const togglePlay = () => {
    if (isPlaying) {
      setIsPlaying(false);
      if (timerRef.current) clearInterval(timerRef.current);
    } else {
      setIsPlaying(true);
      // Play a high-quality soft synth chime
      try {
        const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.type = "sine";
        osc.frequency.setValueAtTime(440, audioCtx.currentTime); // A4 note
        osc.frequency.exponentialRampToValueAtTime(880, audioCtx.currentTime + 0.1); // slide up
        gain.gain.setValueAtTime(0.04, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.2);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.25);
      } catch (e) {
        console.warn(e);
      }

      setProgress(0);
      const interval = 100;
      const step = (interval / 1000) / duration;
      timerRef.current = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 1) {
            setIsPlaying(false);
            if (timerRef.current) clearInterval(timerRef.current);
            return 1;
          }
          return prev + step;
        });
      }, interval);
    }
  };

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  return (
    <div className="flex items-center gap-3 py-2 px-3 bg-black/40 rounded-2xl min-w-[210px] sm:min-w-[240px] border border-white/5 shadow-inner">
      <button
        onClick={togglePlay}
        className="w-9 h-9 rounded-full bg-[#D4AF37] text-black flex items-center justify-center hover:scale-105 active:scale-95 transition-all flex-shrink-0 shadow-md"
      >
        {isPlaying ? <Pause size={14} className="fill-black" /> : <Play size={14} className="fill-black ml-0.5" />}
      </button>
      <div className="flex-1 min-w-0">
        <div className="h-1.5 bg-white/20 rounded-full overflow-hidden relative">
          <div
            className="absolute left-0 top-0 h-full bg-[#D4AF37] transition-all duration-100"
            style={{ width: `${progress * 100}%` }}
          />
        </div>
        <div className="flex justify-between items-center text-[10px] text-gray-400 mt-1.5">
          <span className="font-mono">{isPlaying ? `00:${String(Math.floor(progress * duration)).padStart(2, "0")}` : `00:${String(duration).padStart(2, "0")}`}</span>
          <span className="flex items-center gap-1 text-[#D4AF37]">
            <Mic size={10} /> Vocal
          </span>
        </div>
      </div>
    </div>
  );
};

const StickerMessage = ({ stickerKey }: { stickerKey: string }) => {
  const stickers: Record<string, { label: string; icon: string; bg: string }> = {
    gold_star: { label: "Félicitations !", icon: "⭐", bg: "from-amber-500/20 to-yellow-600/20 border-amber-500/30" },
    study_focus: { label: "Focus maximum !", icon: "🧠", bg: "from-blue-500/20 to-indigo-600/20 border-blue-500/30" },
    excellent_work: { label: "Excellent travail !", icon: "👍", bg: "from-emerald-500/20 to-teal-600/20 border-emerald-500/30" },
    auralis_wisdom: { label: "Sagesse d'Auralis !", icon: "🦉", bg: "from-purple-500/20 to-pink-600/20 border-purple-500/30" },
    trophy_winner: { label: "Victoire !", icon: "🏆", bg: "from-yellow-400/20 to-orange-500/20 border-yellow-400/30" },
  };

  const sticker = stickers[stickerKey] || { label: "Sticker", icon: "✨", bg: "from-gray-500/20 to-gray-600/20" };

  return (
    <motion.div
      initial={{ scale: 0.8, rotate: -3 }}
      animate={{ scale: 1, rotate: 0 }}
      className={`p-4 rounded-3xl bg-gradient-to-br ${sticker.bg} border flex flex-col items-center justify-center gap-2 w-[160px] shadow-lg`}
    >
      <span className="text-4xl drop-shadow-[0_0_12px_rgba(212,175,55,0.45)] select-none animate-pulse">
        {sticker.icon}
      </span>
      <span className="text-[10px] uppercase tracking-wider font-extrabold text-white text-center">
        {sticker.label}
      </span>
    </motion.div>
  );
};

export function Messages() {
  const { profile, user } = useAuth();
  const [contacts, setContacts] = useState<Profile[]>([]);
  const [loadingContacts, setLoadingContacts] = useState(true);
  const [activeContact, setActiveContact] = useState<Profile | null>(null);
  const [chatMessages, setChatMessages] = useState<Message[]>([]);
  const [loadingMessages, setLoadingMessages] = useState(false);
  
  const [inputText, setInputText] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [showStickerTray, setShowStickerTray] = useState(false);

  // Real-time typing status
  const [typingStatus, setTypingStatus] = useState<string | null>(null);

  // Calling States
  const [callingState, setCallingState] = useState<"calling" | "ringing" | "connected" | "disconnected" | "incoming" | null>(null);
  const [callType, setCallType] = useState<"audio" | "video" | null>(null);
  const [callDuration, setCallDuration] = useState(0);
  const callTimerRef = useRef<NodeJS.Timeout | null>(null);
  const ringtoneTimerRef = useRef<ReturnType<typeof setTimeout> | NodeJS.Timeout | null>(null);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // New Real-time Call signaling & Presence States
  const [isMuted, setIsMuted] = useState(false);
  const [isCameraOn, setIsCameraOn] = useState(true);
  const [peerMuted, setPeerMuted] = useState(false);
  const [peerCameraOn, setPeerCameraOn] = useState(true);
  const [incomingCallFrom, setIncomingCallFrom] = useState<Profile | null>(null);
  const [onlineUserIds, setOnlineUserIds] = useState<string[]>([]);
  const commsChannelRef = useRef<{ send: (payload: Record<string, unknown>) => void; track: (payload: Record<string, unknown>) => Promise<unknown> } | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const stateRef = useRef<{ isMuted: boolean; isCameraOn: boolean; callType: "audio" | "video" | null; callingState: "calling" | "ringing" | "connected" | "disconnected" | "incoming" | null; incomingCallFrom: Profile | null; activeContactId?: string } | null>(null);

  // Synchronize localStream state to the ref
  useEffect(() => {
    localStreamRef.current = localStream;
  }, [localStream]);

  // Synchronize current states to stateRef
  useEffect(() => {
    stateRef.current = {
      isMuted,
      isCameraOn,
      callType,
      callingState,
      incomingCallFrom,
      activeContactId: activeContact?.id
    };
  }, [isMuted, isCameraOn, callType, callingState, incomingCallFrom, activeContact]);

  // Simulated vocal recording states
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const recordingTimerRef = useRef<NodeJS.Timeout | null>(null);
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  // Curated list of high-quality emojis & custom study stickers
  const curatedEmojis = [
    "😀", "😂", "🔥", "👍", "👏", "🎉", "💡", "🧠", "🎓", "🦉", "👨‍🏫", "⭐", "❤️", "✨",
    "📚", "🚀", "🎯", "🙌", "📝", "💻", "💪", "🌟", "🤩", "🤔", "😮", "💯", "🤙", "🎈"
  ];
  
  const curatedStickers = [
    { key: "gold_star", icon: "⭐", label: "Félicitations" },
    { key: "study_focus", icon: "🧠", label: "Focus" },
    { key: "excellent_work", icon: "👍", label: "Excellent" },
    { key: "auralis_wisdom", icon: "🦉", label: "Sagesse" },
    { key: "trophy_winner", icon: "🏆", label: "Victoire" },
    { key: "bravo", icon: "👏", label: "Bravo !" },
    { key: "hard_study", icon: "📚", label: "Sérieux !" },
    { key: "rocket", icon: "🚀", label: "En avant" },
    { key: "game_on", icon: "🎯", label: "Dans le mille" },
    { key: "party_popper", icon: "🎉", label: "Fête !" },
  ];

  // Helper sound for WhatsApp message receipt
  const playWhatsAppChime = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc1 = audioCtx.createOscillator();
      const osc2 = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();

      osc1.connect(gainNode);
      osc2.connect(gainNode);
      gainNode.connect(audioCtx.destination);

      osc1.frequency.setValueAtTime(800, audioCtx.currentTime);
      osc2.frequency.setValueAtTime(1000, audioCtx.currentTime + 0.08);

      gainNode.gain.setValueAtTime(0.015, audioCtx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.25);

      osc1.start();
      osc2.start(audioCtx.currentTime + 0.08);

      osc1.stop(audioCtx.currentTime + 0.15);
      osc2.stop(audioCtx.currentTime + 0.25);
    } catch (e) {
      console.warn("Audio Context chime failed:", e);
    }
  };

  // Helper sound for Calling ringtone
  const playRingingTone = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      osc.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      
      osc.type = "sine";
      osc.frequency.setValueAtTime(440, audioCtx.currentTime);
      osc.frequency.setValueAtTime(480, audioCtx.currentTime + 0.05);

      gainNode.gain.setValueAtTime(0.015, audioCtx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 1.2);
      
      osc.start();
      osc.stop(audioCtx.currentTime + 1.2);
    } catch (e) {
      console.warn("Ringing tone error:", e);
    }
  };

  // Auto scroll to latest message
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages, loadingMessages]);

  // 1. YouTube active course state
  const [activeYouTubeCourse, setActiveYouTubeCourse] = useState<YouTubeCourseContext | null>(null);

  // Read active YouTube course from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem("auralis_active_youtube_course");
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        setActiveYouTubeCourse(parsed);
        setActiveContact(AURALIS_CONTACT);
      } catch (e) {
        console.error("Error reading stored YouTube course:", e);
      }
    }
  }, []);

  // Fetch contacts according to the user's role, always placing AURALIS_CONTACT first
  useEffect(() => {
    if (!user?.id || !profile?.role) return;

    const fetchContacts = async () => {
      setLoadingContacts(true);
      try {
        let fetched: Profile[] = [];
        if (profile.role === "apprenant") {
          // Learner: only show formateurs of courses they are enrolled in
          const { data: enrolls } = await supabase
            .from("enrollments")
            .select("course_id")
            .eq("user_id", user.id);

          const enrolledCourseIds = enrolls?.map((e) => e.course_id).filter(Boolean) || [];

          if (enrolledCourseIds.length > 0) {
            const { data: courses } = await supabase
              .from("courses")
              .select("formateur_id")
              .in("id", enrolledCourseIds);

            const formateurIds = Array.from(new Set(courses?.map((c) => c.formateur_id).filter(Boolean)));

            if (formateurIds.length > 0) {
              const { data: tutors } = await supabase
                .from("profiles")
                .select("*")
                .in("id", formateurIds);
              fetched = tutors || [];
            }
          }

          if (fetched.length === 0) {
            const { data: fallbackTutors } = await supabase
              .from("profiles")
              .select("*")
              .eq("role", "formateur")
              .limit(10);
            fetched = fallbackTutors || [];
          }
        } else {
          // Formateur: show enrolled students for their courses + messaging counterparts
          const { data: myCourses } = await supabase
            .from("courses")
            .select("id")
            .eq("formateur_id", user.id);

          const myCourseIds = myCourses?.map((c) => c.id) || [];
          let studentIds: string[] = [];
          if (myCourseIds.length > 0) {
            const { data: enrolls } = await supabase
              .from("enrollments")
              .select("user_id")
              .in("course_id", myCourseIds);

            studentIds = Array.from(new Set(enrolls?.map((e) => e.user_id).filter(Boolean))) as string[];
          }

          const { data: sentMsgs } = await supabase
            .from("messages")
            .select("receiver_id")
            .eq("sender_id", user.id);
          const { data: recvMsgs } = await supabase
            .from("messages")
            .select("sender_id")
            .eq("receiver_id", user.id);

          const chatCounterparts = [
            ...(sentMsgs?.map(m => m.receiver_id) || []),
            ...(recvMsgs?.map(m => m.sender_id) || [])
          ].filter(Boolean) as string[];

          const combinedIds = Array.from(new Set([...studentIds, ...chatCounterparts]));

          if (combinedIds.length > 0) {
            const { data: students } = await supabase
              .from("profiles")
              .select("*")
              .in("id", combinedIds);
            fetched = students || [];
          } else {
            const { data: fallbackStudents } = await supabase
              .from("profiles")
              .select("*")
              .eq("role", "apprenant")
              .limit(10);
            fetched = fallbackStudents || [];
          }
        }

        // Always place AURALIS_CONTACT first
        const allWithAuralis = [AURALIS_CONTACT, ...fetched.filter((c) => c.id !== AURALIS_CONTACT.id)];
        setContacts(allWithAuralis);

        if (!activeContact) {
          setActiveContact(AURALIS_CONTACT);
        }
      } catch (err) {
        console.error("Error fetching contacts:", err);
      } finally {
        setLoadingContacts(false);
      }
    };

    fetchContacts();
  }, [user?.id, profile?.role]);

  // Fetch messages with selected contact
  useEffect(() => {
    if (!user?.id || !activeContact?.id) {
      setChatMessages([]);
      return;
    }

    if (activeContact.id === "auralis-ai-avatar") {
      setLoadingMessages(false);
      const localKey = `auralis_chat_${user.id}`;
      const storedLocal = localStorage.getItem(localKey);
      if (storedLocal) {
        try {
          setChatMessages(JSON.parse(storedLocal));
          return;
        } catch (e) {
          console.error("Error reading Auralis local chat:", e);
        }
      }

      const initialMsg: Message = {
        id: "init-auralis-msg",
        sender_id: AURALIS_CONTACT.id,
        receiver_id: user.id,
        contenu: activeYouTubeCourse
          ? `Bonjour ${profile?.prenom || "apprenant"} ! 🎓 J'ai recherché pour toi le cours YouTube **"${activeYouTubeCourse.title}"**.\n\nQuelle question souhaites-tu me poser concernant cette vidéo ? Je suis là pour t'expliquer tous les concepts et faire évoluer tes points d'expérience (XP) !`
          : `Bonjour ${profile?.prenom || "apprenant"} ! 🌟 Je suis Auralis, ton Avatar IA et tuteur pédagogique. Pose-moi toutes tes questions sur tes cours ou sur n'importe quel sujet d'étude !`,
        is_read: true,
        created_at: new Date().toISOString(),
      };

      setChatMessages([initialMsg]);
      localStorage.setItem(localKey, JSON.stringify([initialMsg]));
      return;
    }

    const fetchMessages = async () => {
      setLoadingMessages(true);
      try {
        const { data, error } = await supabase
          .from("messages")
          .select("*")
          .or(`and(sender_id.eq.${user.id},receiver_id.eq.${activeContact.id}),and(sender_id.eq.${activeContact.id},receiver_id.eq.${user.id})`)
          .order("created_at", { ascending: true });

        if (error) throw error;
        setChatMessages(data || []);

        await supabase
          .from("messages")
          .update({ is_read: true })
          .eq("sender_id", activeContact.id)
          .eq("receiver_id", user.id);
      } catch (err) {
        console.error("Error fetching messages:", err);
      } finally {
        setLoadingMessages(false);
      }
    };

    fetchMessages();
  }, [user?.id, activeContact?.id, activeYouTubeCourse, profile?.prenom]);

  // Full-featured Real-time subscription for incoming inserts & checkmark updates
  useEffect(() => {
    if (!user?.id) return;

    const channel = supabase
      .channel("global-realtime-messages")
      .on(
        "postgres_changes",
        {
          event: "*", // Listen to INSERTs and UPDATEs for read checkmarks!
          schema: "public",
          table: "messages"
        },
        (payload) => {
          if (payload.eventType === "INSERT") {
            const newMsg = payload.new as Message;
            
            // Check if it's relevant to the current user
            if (newMsg.receiver_id === user.id || newMsg.sender_id === user.id) {
              
              // If it belongs to active chat, add to state
              if (
                activeContact &&
                ((newMsg.sender_id === activeContact.id && newMsg.receiver_id === user.id) ||
                 (newMsg.sender_id === user.id && newMsg.receiver_id === activeContact.id))
              ) {
                setChatMessages((prev) => {
                  if (prev.some((m) => m.id === newMsg.id)) return prev;
                  return [...prev, newMsg];
                });

                // Mark read in DB automatically
                if (newMsg.sender_id === activeContact.id) {
                  playWhatsAppChime();
                  supabase
                    .from("messages")
                    .update({ is_read: true })
                    .eq("id", newMsg.id)
                    .then();
                }
              } else if (newMsg.receiver_id === user.id) {
                // Received message from another contact! Show a nice WhatsApp banner notification
                playWhatsAppChime();
                const senderName = "Formateur académique";
                toast.success(`Nouveau message: ${newMsg.contenu.startsWith("[") ? "Fichier partagé" : newMsg.contenu.slice(0, 35) + "..."}`, {
                  description: "Reçu en temps réel via Auralis WhatsApp",
                  duration: 4000
                });
              }
            }
          } else if (payload.eventType === "UPDATE") {
            const updatedMsg = payload.new as Message;
            // If active message read status is updated, sync local checks
            if (
              activeContact &&
              ((updatedMsg.sender_id === user.id && updatedMsg.receiver_id === activeContact.id) ||
               (updatedMsg.sender_id === activeContact.id && updatedMsg.receiver_id === user.id))
            ) {
              setChatMessages((prev) =>
                prev.map((msg) => (msg.id === updatedMsg.id ? updatedMsg : msg))
              );
            }
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, activeContact]);

  const sendCallSignal = useCallback((action: string, extra = {}) => {
    if (!commsChannelRef.current || !user?.id) return;
    
    // Determine target recipient
    const recipientId = stateRef.current?.callingState === "incoming" && stateRef.current?.incomingCallFrom
      ? stateRef.current.incomingCallFrom.id
      : stateRef.current?.activeContactId;

    if (!recipientId) return;

    commsChannelRef.current.send({
      type: "broadcast",
      event: "call-signal",
      payload: {
        senderId: user.id,
        senderProfile: profile,
        receiverId: recipientId,
        action,
        callType: stateRef.current?.callType,
        isMuted: stateRef.current?.isMuted,
        isCameraOn: stateRef.current?.isCameraOn,
        ...extra
      }
    });
  }, [user?.id, profile]);

  // Set up real-time calling signaling & Presence status tracking via Supabase
  useEffect(() => {
    if (!user?.id) return;

    const channel = supabase.channel("auralis-realtime-comms", {
      config: {
        presence: {
          key: user.id,
        },
      },
    });

    commsChannelRef.current = channel;

    channel
      .on("presence", { event: "sync" }, () => {
        const state = channel.presenceState();
        const onlineIds = Object.keys(state);
        setOnlineUserIds(onlineIds);
      })
      .on("broadcast", { event: "call-signal" }, (e) => {
        const payload = e.payload;
        if (payload.receiverId === user.id) {
          if (payload.action === "initiate") {
            setIncomingCallFrom(payload.senderProfile);
            setCallType(payload.callType);
            setCallingState("incoming");
            playRingingTone();
          } else if (payload.action === "accept") {
            if (ringtoneTimerRef.current) {
              clearTimeout(ringtoneTimerRef.current);
              ringtoneTimerRef.current = null;
            }
            setCallingState("connected");
            setPeerMuted(payload.isMuted || false);
            setPeerCameraOn(payload.isCameraOn !== false);
            if (callTimerRef.current) clearInterval(callTimerRef.current);
            callTimerRef.current = setInterval(() => {
              setCallDuration((prev) => prev + 1);
            }, 1000);
          } else if (payload.action === "decline") {
            if (ringtoneTimerRef.current) {
              clearTimeout(ringtoneTimerRef.current);
              ringtoneTimerRef.current = null;
            }
            setCallingState(null);
            setCallType(null);
            setIncomingCallFrom(null);
            if (localStreamRef.current) {
              localStreamRef.current.getTracks().forEach((track) => track.stop());
              setLocalStream(null);
            }
            toast.info("L'appel a été refusé.");
          } else if (payload.action === "hangup") {
            setCallingState(null);
            setCallType(null);
            setIncomingCallFrom(null);
            setCallDuration(0);
            if (callTimerRef.current) {
              clearInterval(callTimerRef.current);
              callTimerRef.current = null;
            }
            if (localStreamRef.current) {
              localStreamRef.current.getTracks().forEach((track) => track.stop());
              setLocalStream(null);
            }
            toast.info("Appel raccroché.");
          } else if (payload.action === "state-change") {
            setPeerMuted(payload.isMuted);
            setPeerCameraOn(payload.isCameraOn);
          } else if (payload.action === "switch-type") {
            setCallType(payload.callType);
          }
        }
      })
      .subscribe(async (status) => {
        if (status === "SUBSCRIBED") {
          await channel.track({ online_at: new Date().toISOString() });
        }
      });

    return () => {
      supabase.removeChannel(channel);
      commsChannelRef.current = null;
    };
  }, [user?.id]);

  // Handle local microphone mute/unmute
  useEffect(() => {
    if (localStream) {
      localStream.getAudioTracks().forEach((track) => {
        track.enabled = !isMuted;
      });
    }
    sendCallSignal("state-change", { isMuted, isCameraOn });
  }, [isMuted, localStream, isCameraOn, sendCallSignal]);

  // Handle local camera on/off
  useEffect(() => {
    if (localStream) {
      localStream.getVideoTracks().forEach((track) => {
        track.enabled = isCameraOn;
      });
    }
    sendCallSignal("state-change", { isMuted, isCameraOn });
  }, [isCameraOn, localStream, isMuted, sendCallSignal]);

  // Handle Send text message
  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim() || !activeContact?.id || !user?.id) return;

    const textToSend = inputText.trim();
    setInputText("");
    setShowStickerTray(false);

    // Chatting directly with Auralis AI Avatar
    if (activeContact.id === "auralis-ai-avatar") {
      const userMsg: Message = {
        id: "user-" + Date.now(),
        sender_id: user.id,
        receiver_id: AURALIS_CONTACT.id,
        contenu: textToSend,
        is_read: true,
        created_at: new Date().toISOString(),
      };

      const updated = [...chatMessages, userMsg];
      setChatMessages(updated);
      setTypingStatus("Auralis IA prépare une réponse pédagogique...");

      setTimeout(async () => {
        try {
          const { answer } = await askAuralisAIAboutCourse({
            userId: user.id,
            userMessage: textToSend,
            courseContext: activeYouTubeCourse,
            userRole: profile?.role === "formateur" ? "formateur" : "apprenant",
          });

          setTypingStatus(null);

          const aiMsg: Message = {
            id: "ai-" + Date.now(),
            sender_id: AURALIS_CONTACT.id,
            receiver_id: user.id,
            contenu: answer,
            is_read: true,
            created_at: new Date().toISOString(),
          };

          const finalMsgs = [...updated, aiMsg];
          setChatMessages(finalMsgs);
          localStorage.setItem(`auralis_chat_${user.id}`, JSON.stringify(finalMsgs));
          playWhatsAppChime();
        } catch (err) {
          console.error("Error generating Auralis AI response:", err);
          setTypingStatus(null);
        }
      }, 1000);

      return;
    }

    try {
      const { data, error } = await supabase
        .from("messages")
        .insert({
          sender_id: user.id,
          receiver_id: activeContact.id,
          contenu: textToSend,
          is_read: false
        })
        .select()
        .single();

      if (error) throw error;
      setChatMessages((prev) => [...prev, data]);

      // Award +10 XP for platform activity
      if (user?.id) {
        awardXP({
          userId: user.id,
          amount: 10,
          actionName: "Participation active aux échanges Auralis",
          userRole: profile?.role === "formateur" ? "formateur" : "apprenant",
        });
      }

      // Trigger realistic teacher response simulation if the user is an 'apprenant'
      if (profile?.role === "apprenant") {
        setTimeout(() => {
          setTypingStatus("En train d'écrire...");
        }, 1500);

        setTimeout(async () => {
          setTypingStatus(null);
          // Auto reply encouraging message
          const responses = [
            "Excellent message ! Continue ton apprentissage assidûment sur Auralis. Je reste disponible pour toute question.",
            "Très bien reçu ! Concentre-toi bien sur les modules du cours actuel, ton score s'améliore constamment.",
            "C'est noté. N'oublie pas de valider ton évaluation hebdomadaire Auralis pour doubler tes points d'expérience !",
            "Sujet passionnant ! J'ai justement publié une nouvelle vidéo de cours qui répond exactement à cette problématique."
          ];
          const randomReply = responses[Math.floor(Math.random() * responses.length)];
          
          try {
            const { data: replyData } = await supabase
              .from("messages")
              .insert({
                sender_id: activeContact.id,
                receiver_id: user.id,
                contenu: randomReply,
                is_read: false
              })
              .select()
              .single();

            if (replyData) {
              setChatMessages((prev) => [...prev, replyData]);
              playWhatsAppChime();
            }
          } catch (rErr) {
            console.error("Error creating auto reply:", rErr);
          }
        }, 4500);
      }
    } catch (err) {
      console.error("Error sending message:", err);
      toast.error("Erreur d'envoi du message.");
    }
  };

  // Handle Send Sticker
  const handleSendSticker = async (stickerKey: string) => {
    if (!activeContact?.id || !user?.id) return;
    setShowStickerTray(false);

    try {
      const { data, error } = await supabase
        .from("messages")
        .insert({
          sender_id: user.id,
          receiver_id: activeContact.id,
          contenu: `[STICKER]:${stickerKey}`,
          is_read: false
        })
        .select()
        .single();

      if (error) throw error;
      setChatMessages((prev) => [...prev, data]);
    } catch (err) {
      console.error("Error sending sticker:", err);
      toast.error("Erreur d'envoi du sticker.");
    }
  };

  // Start simulated Voice Note recording
  const startRecording = () => {
    if (isRecording) return;
    setIsRecording(true);
    setRecordingSeconds(0);
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.frequency.setValueAtTime(600, audioCtx.currentTime);
      gain.gain.setValueAtTime(0.02, audioCtx.currentTime);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.1);
    } catch (e) {
      console.warn("AudioContext error during recording beep:", e);
    }

    recordingTimerRef.current = setInterval(() => {
      setRecordingSeconds((prev) => prev + 1);
    }, 1000);
  };

  // Stop & Send Simulated Voice Note
  const sendVoiceNote = async () => {
    if (!isRecording) return;
    setIsRecording(false);
    if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);

    const secondsRecorded = Math.max(2, recordingSeconds);
    setRecordingSeconds(0);

    if (!activeContact?.id || !user?.id) return;

    try {
      const { data, error } = await supabase
        .from("messages")
        .insert({
          sender_id: user.id,
          receiver_id: activeContact.id,
          contenu: `[AUDIO]:${secondsRecorded}`,
          is_read: false
        })
        .select()
        .single();

      if (error) throw error;
      setChatMessages((prev) => [...prev, data]);

      try {
        const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.frequency.setValueAtTime(800, audioCtx.currentTime);
        gain.gain.setValueAtTime(0.01, audioCtx.currentTime);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.1);
      } catch (e) {
        console.warn("AudioContext error during send beep:", e);
      }
    } catch (err) {
      console.error("Error sending voice note:", err);
      toast.error("Erreur d'envoi du vocal.");
    }
  };

  // Cancel simulated Voice Note
  const cancelRecording = () => {
    setIsRecording(false);
    if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
    setRecordingSeconds(0);
  };

  // Start Call System (Audio / Video) with real media capture and broadcast signaling
  const handleStartCall = async (type: "audio" | "video") => {
    if (!activeContact?.id || !user?.id) return;
    setCallType(type);
    setCallingState("calling");
    setCallDuration(0);
    setIsMuted(false);
    setIsCameraOn(type === "video");
    setPeerMuted(false);
    setPeerCameraOn(true);

    // Play ringing tone recursively
    playRingingTone();
    const ringInterval = setInterval(() => {
      playRingingTone();
    }, 1500);

    // Capture media
    let stream: MediaStream | null = null;
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        video: type === "video",
        audio: true
      });
      setLocalStream(stream);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (e) {
      console.warn("Could not capture local stream on dial:", e);
    }

    // Send broadcast initiate signal
    setTimeout(() => {
      if (commsChannelRef.current) {
        commsChannelRef.current.send({
          type: "broadcast",
          event: "call-signal",
          payload: {
            senderId: user.id,
            senderProfile: profile,
            receiverId: activeContact.id,
            action: "initiate",
            callType: type,
            isMuted: false,
            isCameraOn: type === "video"
          }
        });
      }
    }, 200);

    // Ring timeout: hang up if no response in 30s
    ringtoneTimerRef.current = setTimeout(() => {
      clearInterval(ringInterval);
      if (stateRef.current.callingState === "calling" || stateRef.current.callingState === "ringing") {
        sendCallSignal("hangup");
        handleEndCall();
        toast.info("Le destinataire ne répond pas.");
      }
    }, 30000);
  };

  // Accept incoming call
  const handleAcceptCall = async () => {
    if (!incomingCallFrom || !user?.id) return;

    setCallingState("connected");
    setCallDuration(0);
    setIsMuted(false);
    setIsCameraOn(callType === "video");
    setPeerMuted(false);
    setPeerCameraOn(true);

    // Play chime locally
    playWhatsAppChime();

    // Capture media
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: callType === "video",
        audio: true
      });
      setLocalStream(stream);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (e) {
      console.warn("Could not capture webcam stream on accept:", e);
    }

    // Send accept broadcast signal
    if (commsChannelRef.current) {
      commsChannelRef.current.send({
        type: "broadcast",
        event: "call-signal",
        payload: {
          senderId: user.id,
          senderProfile: profile,
          receiverId: incomingCallFrom.id,
          action: "accept",
          callType: callType,
          isMuted: false,
          isCameraOn: callType === "video"
        }
      });
    }

    // Start timer
    if (callTimerRef.current) clearInterval(callTimerRef.current);
    callTimerRef.current = setInterval(() => {
      setCallDuration((prev) => prev + 1);
    }, 1000);
  };

  // Decline incoming call
  const handleDeclineCall = () => {
    if (!incomingCallFrom) return;

    // Send decline broadcast signal
    if (commsChannelRef.current) {
      commsChannelRef.current.send({
        type: "broadcast",
        event: "call-signal",
        payload: {
          senderId: user.id,
          receiverId: incomingCallFrom.id,
          action: "decline"
        }
      });
    }

    setCallingState(null);
    setCallType(null);
    setIncomingCallFrom(null);
  };

  // Stop/Hang up Call and trigger cleanup & signaling
  const handleEndCall = () => {
    // Send hangup broadcast signal to peer
    sendCallSignal("hangup");

    // Clean up local states
    setCallingState(null);
    setCallType(null);
    setIncomingCallFrom(null);
    setCallDuration(0);

    if (callTimerRef.current) {
      clearInterval(callTimerRef.current);
      callTimerRef.current = null;
    }
    if (ringtoneTimerRef.current) {
      clearTimeout(ringtoneTimerRef.current);
      ringtoneTimerRef.current = null;
    }

    if (localStream) {
      localStream.getTracks().forEach((track) => track.stop());
      setLocalStream(null);
    }

    toast.success("Appel terminé");
  };

  // Keep localStream connected to video preview element
  useEffect(() => {
    if (localStream && videoRef.current && callingState === "connected") {
      videoRef.current.srcObject = localStream;
    }
  }, [localStream, callingState]);

  const getContactName = (contact: Profile) => {
    if (contact.prenom || contact.nom) {
      return `${contact.prenom || ""} ${contact.nom || ""}`.trim();
    }
    return contact.pseudo || "Tuteur";
  };

  const filteredContacts = contacts.filter((c) => {
    const fullName = `${c.prenom || ""} ${c.nom || ""} ${c.pseudo || ""}`.toLowerCase();
    return fullName.includes(searchQuery.toLowerCase());
  });

  return (
    <div className="w-full h-[calc(100vh-4rem)] flex overflow-hidden text-white bg-[#0D0D0D]">
      {/* 1. Left Contact Column (WhatsApp list style) */}
      <div
        className={`w-full md:w-[350px] border-r border-white/5 flex flex-col h-full bg-[#121212] flex-shrink-0 ${
          activeContact ? "hidden md:flex" : "flex"
        }`}
      >
        {/* User own profile header */}
        <div className="px-5 py-4 border-b border-white/5 bg-black/40 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#D4AF37]/10 border border-[#D4AF37]/20 flex items-center justify-center font-bold text-[#D4AF37] select-none text-sm">
              {profile?.prenom?.charAt(0)?.toUpperCase() || "A"}
            </div>
            <div>
              <h3 className="font-bold text-sm leading-none">
                {profile?.prenom || "Profil"} {profile?.nom || ""}
              </h3>
              <span className="text-[10px] text-emerald-500 font-medium flex items-center gap-1 mt-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" /> En ligne
              </span>
            </div>
          </div>
          <div className="text-gray-400 hover:text-[#D4AF37] transition-colors cursor-pointer">
            <MoreVertical size={18} />
          </div>
        </div>

        {/* WhatsApp search bar */}
        <div className="p-3 border-b border-white/5">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 text-gray-500 w-4 h-4" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher une discussion..."
              className="w-full bg-[#1C1C1C] text-xs placeholder-gray-500 pl-9 pr-4 py-2 rounded-xl border border-white/5 outline-none focus:border-[#D4AF37]/40 focus:bg-black/40 transition-all text-white"
            />
          </div>
        </div>

        {/* Contacts scrolling list */}
        <div className="flex-1 overflow-y-auto divide-y divide-white/5">
          {loadingContacts ? (
            <div className="flex flex-col items-center justify-center py-20 gap-3">
              <div className="w-6 h-6 rounded-full border-2 border-[#D4AF37] border-t-transparent animate-spin" />
              <p className="text-xs text-gray-500 font-medium">Chargement de la liste...</p>
            </div>
          ) : filteredContacts.length === 0 ? (
            <div className="py-16 text-center text-gray-500 flex flex-col items-center gap-2 px-6">
              <Users size={32} className="text-gray-600" />
              <p className="text-xs font-semibold">Aucun tuteur ou apprenant trouvé</p>
              <p className="text-[10px] text-gray-600">
                Inscrivez-vous à des cours pour activer la messagerie avec vos formateurs dédiés.
              </p>
            </div>
          ) : (
            filteredContacts.map((contact) => {
              const isSelected = activeContact?.id === contact.id;
              return (
                <div
                  key={contact.id}
                  onClick={() => setActiveContact(contact)}
                  className={`px-4 py-3.5 flex items-center justify-between gap-3 cursor-pointer transition-all hover:bg-white/[0.02] ${
                    isSelected ? "bg-white/[0.04] border-l-4 border-l-[#D4AF37]" : ""
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <div className="w-11 h-11 rounded-full bg-neutral-900 border border-white/5 flex items-center justify-center text-[#D4AF37] font-bold text-sm relative flex-shrink-0 select-none overflow-hidden">
                      <img
                        src={contact.avatar_url || auralisLogo}
                        alt={getContactName(contact)}
                        className="w-full h-full object-cover rounded-full"
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          (e.currentTarget as HTMLImageElement).src = auralisLogo;
                        }}
                      />
                      <span className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-[#121212] ${
                        onlineUserIds.includes(contact.id) ? "bg-emerald-500 animate-pulse" : "bg-neutral-600"
                      }`} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between">
                        <h4 className="font-semibold text-sm truncate text-white">
                          {getContactName(contact)}
                        </h4>
                        <span className="text-[9px] text-gray-500">
                          {onlineUserIds.includes(contact.id) ? "En ligne" : "Hors ligne"}
                        </span>
                      </div>
                      <p className="text-xs text-gray-400 truncate mt-0.5">
                        {contact.role === "formateur" ? "Tuteur académique 👨‍🏫" : "Apprenant 🎓"}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* 2. Right WhatsApp Chat Pane */}
      <div className={`flex-1 flex flex-col h-full bg-[#0b141a] relative ${!activeContact ? "hidden md:flex" : "flex"}`}>
        {/* Subtle Whatsapp Chat Wallpaper background layer */}
        <div className="absolute inset-0 bg-repeat bg-opacity-5 bg-[radial-gradient(#ffffff05_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" />

        {activeContact ? (
          <>
            {/* Header */}
            <div className="px-6 py-3 border-b border-white/5 bg-[#121212]/95 backdrop-blur-md flex items-center justify-between z-10 shadow-lg">
              <div className="flex items-center gap-3 min-w-0">
                <button
                  onClick={() => setActiveContact(null)}
                  className="p-1.5 -ml-2 text-gray-400 hover:text-white hover:bg-white/5 rounded-full md:hidden"
                >
                  <ChevronLeft size={20} />
                </button>
                <div className="w-10 h-10 rounded-full bg-neutral-900 border border-white/5 flex items-center justify-center text-[#D4AF37] font-bold text-sm select-none relative flex-shrink-0 overflow-hidden">
                  <img
                    src={activeContact.avatar_url || auralisLogo}
                    alt={getContactName(activeContact)}
                    className="w-full h-full object-cover rounded-full"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      (e.currentTarget as HTMLImageElement).src = auralisLogo;
                    }}
                  />
                  <span className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border border-[#121212] ${
                    onlineUserIds.includes(activeContact.id) ? "bg-emerald-500 animate-pulse" : "bg-neutral-600"
                  }`} />
                </div>
                <div className="min-w-0">
                  <h3 className="font-bold text-sm leading-none text-white truncate">
                    {getContactName(activeContact)}
                  </h3>
                  <span className={`text-[10px] font-medium block mt-1 ${
                    typingStatus 
                      ? "text-[#D4AF37] animate-pulse" 
                      : onlineUserIds.includes(activeContact.id) 
                        ? "text-emerald-400" 
                        : "text-gray-500"
                  }`}>
                    {typingStatus || (onlineUserIds.includes(activeContact.id) ? "actif en ligne" : "hors ligne")}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-4 text-gray-400">
                <button
                  onClick={() => handleStartCall("audio")}
                  className="hover:text-[#D4AF37] transition-colors p-1.5 hover:bg-white/5 rounded-lg"
                  title="Appel vocal"
                >
                  <Phone size={18} />
                </button>
                <button
                  onClick={() => handleStartCall("video")}
                  className="hover:text-[#D4AF37] transition-colors p-1.5 hover:bg-white/5 rounded-lg"
                  title="Appel vidéo"
                >
                  <Video size={18} />
                </button>
                <button className="hover:text-[#D4AF37] transition-colors p-1.5 hover:bg-white/5 rounded-lg">
                  <MoreVertical size={18} />
                </button>
              </div>
            </div>

            {/* Active YouTube Course Context Banner */}
            {activeYouTubeCourse && activeContact.id === AURALIS_CONTACT.id && (
              <div className="bg-[#D4AF37]/10 border-b border-[#D4AF37]/20 px-6 py-2.5 flex items-center justify-between text-xs text-[#D4AF37] z-10 shadow-inner">
                <div className="flex items-center gap-2 min-w-0 pr-4">
                  <Youtube size={16} className="text-red-500 flex-shrink-0" />
                  <span className="font-bold truncate">
                    Cours YouTube sous tutorat d'Auralis : "{activeYouTubeCourse.title}"
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setActiveYouTubeCourse(null);
                    localStorage.removeItem("auralis_active_youtube_course");
                    toast.info("Contexte de cours masqué.");
                  }}
                  className="text-gray-400 hover:text-white flex items-center gap-1 text-[10px] uppercase font-extrabold flex-shrink-0 py-1 px-2 rounded hover:bg-white/10 transition-colors"
                >
                  <X size={12} /> Masquer
                </button>
              </div>
            )}

            {/* Chat message list area */}
            <div className="flex-1 overflow-y-auto px-6 py-6 space-y-4 z-10 custom-scrollbar">
              {loadingMessages ? (
                <div className="h-full flex items-center justify-center">
                  <div className="w-8 h-8 rounded-full border-2 border-[#D4AF37] border-t-transparent animate-spin" />
                </div>
              ) : chatMessages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center text-gray-500 max-w-sm mx-auto gap-3 py-20">
                  <div className="w-14 h-14 rounded-full bg-white/5 flex items-center justify-center border border-white/10 text-[#D4AF37]">
                    <MessageSquare size={24} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-white text-sm">Démarrez un chat WhatsApp</h4>
                    <p className="text-xs text-gray-500 mt-1">
                      Envoyez des messages textuels, des mémos vocaux en direct ou des stickers d'encouragement !
                    </p>
                  </div>
                </div>
              ) : (
                chatMessages.map((msg) => {
                  const isMe = msg.sender_id === user?.id;
                  const isSticker = msg.contenu?.startsWith("[STICKER]:");
                  const isAudio = msg.contenu?.startsWith("[AUDIO]:");

                  return (
                    <div
                      key={msg.id}
                      className={`flex flex-col ${isMe ? "items-end" : "items-start"} animate-fade-in`}
                    >
                      <div
                        className={`max-w-[75%] rounded-2xl relative ${
                          isSticker
                            ? "bg-transparent p-0"
                            : isMe
                            ? "bg-[#005c4b] text-white rounded-tr-none border border-emerald-800/20 px-4 py-2.5 shadow-md"
                            : "bg-[#202c33] text-white rounded-tl-none border border-neutral-800/30 px-4 py-2.5 shadow-md"
                        }`}
                      >
                        {/* Render based on content types */}
                        {isSticker ? (
                          <StickerMessage stickerKey={msg.contenu.replace("[STICKER]:", "")} />
                        ) : isAudio ? (
                          <AudioPlayer durationStr={msg.contenu.replace("[AUDIO]:", "")} />
                        ) : (
                          <p className="text-xs font-normal leading-relaxed text-slate-100 select-text whitespace-pre-line">
                            {msg.contenu}
                          </p>
                        )}

                        {/* Message Metadata (checkmarks and timing) */}
                        {!isSticker && (
                          <div className="flex items-center justify-end gap-1.5 mt-1.5 text-[9px] text-gray-400 select-none">
                            <span>
                              {msg.created_at
                                ? new Date(msg.created_at).toLocaleTimeString([], {
                                    hour: "2-digit",
                                    minute: "2-digit",
                                  })
                                : ""}
                            </span>
                            {isMe && (
                              <CheckCheck
                                size={12}
                                className={msg.is_read ? "text-[#53bdeb]" : "text-gray-500"}
                              />
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
              <div ref={chatEndRef} />
            </div>

            {/* Sticker Tray */}
            <AnimatePresence>
              {showStickerTray && (
                <motion.div
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 15 }}
                  className="mx-6 p-4 bg-[#1e1e1e] border border-white/5 rounded-2xl z-20 space-y-4 shadow-2xl flex flex-col"
                >
                  <div className="flex justify-between items-center pb-2 border-b border-white/5">
                    <span className="text-xs font-bold text-[#D4AF37] tracking-wider uppercase">
                      Stickers & Emojis WhatsApp
                    </span>
                    <button
                      onClick={() => setShowStickerTray(false)}
                      className="p-1 hover:bg-white/5 rounded-full text-gray-400 hover:text-white"
                    >
                      <X size={14} />
                    </button>
                  </div>

                  {/* Emojis Grid */}
                  <div className="space-y-1.5">
                    <span className="text-[10px] uppercase text-gray-500 font-bold">Insérer Emojis</span>
                    <div className="flex flex-wrap gap-2">
                      {curatedEmojis.map((emoji) => (
                        <button
                          key={emoji}
                          onClick={() => setInputText((prev) => prev + emoji)}
                          className="w-8 h-8 rounded-xl bg-white/5 hover:bg-[#D4AF37]/15 border border-white/5 hover:border-[#D4AF37]/30 text-base flex items-center justify-center hover:scale-110 active:scale-95 transition-all"
                        >
                          {emoji}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Golden Study Stickers Grid */}
                  <div className="space-y-1.5 pt-1">
                    <span className="text-[10px] uppercase text-gray-500 font-bold">Envoyer Stickers</span>
                    <div className="grid grid-cols-5 gap-2">
                      {curatedStickers.map((sticker) => (
                        <button
                          key={sticker.key}
                          onClick={() => handleSendSticker(sticker.key)}
                          className="flex flex-col items-center justify-center p-2.5 rounded-xl bg-[#282828] hover:bg-[#D4AF37]/10 border border-white/5 hover:border-[#D4AF37]/30 group transition-all"
                        >
                          <span className="text-2xl group-hover:scale-110 transition-transform duration-200">
                            {sticker.icon}
                          </span>
                          <span className="text-[8px] text-gray-400 mt-1 font-semibold group-hover:text-white transition-colors truncate w-full text-center">
                            {sticker.label}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Input Footer Area */}
            <div className="p-4 bg-[#121212]/95 border-t border-white/5 z-20 shadow-inner">
              {isRecording ? (
                /* Vocal Recording Mode */
                <div className="flex items-center justify-between bg-black/40 border border-red-500/30 px-4 py-3 rounded-2xl animate-pulse">
                  <div className="flex items-center gap-3">
                    <div className="w-2.5 h-2.5 rounded-full bg-red-600 animate-ping" />
                    <span className="text-xs font-mono font-bold text-red-500">
                      Enregistrement Vocal en cours... (00:
                      {String(recordingSeconds).padStart(2, "0")})
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={cancelRecording}
                      className="px-3.5 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-xs text-gray-300 font-bold rounded-xl transition-all"
                    >
                      Annuler
                    </button>
                    <button
                      onClick={sendVoiceNote}
                      className="px-4 py-1.5 bg-red-600 hover:bg-red-700 text-xs text-white font-bold rounded-xl flex items-center gap-1.5 hover:scale-105 active:scale-95 transition-all shadow-lg shadow-red-600/10"
                    >
                      <Check size={14} /> Envoyer le vocal
                    </button>
                  </div>
                </div>
              ) : (
                /* Regular Chat input bar */
                <form onSubmit={handleSendMessage} className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowStickerTray(!showStickerTray)}
                    className={`p-3 rounded-xl hover:bg-white/5 transition-all flex-shrink-0 border border-transparent ${
                      showStickerTray ? "text-[#D4AF37] border-[#D4AF37]/30 bg-[#D4AF37]/5" : "text-gray-400 hover:text-white"
                    }`}
                    title="Stickers & Emojis"
                  >
                    <Smile size={18} />
                  </button>

                  <input
                    type="text"
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder="Tapez un message ou posez une question..."
                    className="flex-1 bg-[#1c1c1c] border border-white/5 focus:border-[#D4AF37]/40 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-500 outline-none focus:bg-black/30 transition-all"
                  />

                  {/* Micro record button */}
                  <button
                    type="button"
                    onClick={startRecording}
                    className="p-3 bg-[#1C1C1C] hover:bg-red-600/15 text-gray-400 hover:text-red-500 border border-white/5 rounded-xl transition-all flex-shrink-0"
                    title="Enregistrer un vocal"
                  >
                    <Mic size={18} />
                  </button>

                  <button
                    type="submit"
                    disabled={!inputText.trim()}
                    className="p-3 bg-[#D4AF37] disabled:bg-neutral-800 disabled:text-gray-500 disabled:scale-100 hover:scale-105 active:scale-95 text-black rounded-xl transition-all flex-shrink-0 font-bold shadow-md shadow-[#D4AF37]/15"
                  >
                    <Send size={15} />
                  </button>
                </form>
              )}
            </div>
          </>
        ) : (
          /* Professional Empty Chat Area Component */
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center select-none z-10 max-w-lg mx-auto space-y-6">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#D4AF37]/20 via-[#D4AF37]/5 to-transparent border border-[#D4AF37]/30 text-[#D4AF37] flex items-center justify-center shadow-xl shadow-[#D4AF37]/10"
            >
              <MessageSquare size={36} />
            </motion.div>

            <div className="space-y-2">
              <h3 className="text-xl font-bold font-[Space_Grotesk] text-white">
                Discussions & Tutorat Auralis
              </h3>
              <p className="text-xs text-gray-400 leading-relaxed">
                Communiquez en direct avec vos professeurs, formateurs et pairs académiques. Échangez des messages texte, mémos vocaux HD et documents d'étude en temps réel.
              </p>
            </div>

            {/* Quick Feature Highlights */}
            <div className="grid grid-cols-3 gap-3 w-full text-left">
              <div className="bg-white/5 border border-white/5 p-3 rounded-xl space-y-1">
                <Mic size={16} className="text-[#D4AF37]" />
                <p className="text-[11px] font-bold text-white">Notes Vocales</p>
                <p className="text-[9px] text-gray-500">Mémos vocaux intégrés</p>
              </div>
              <div className="bg-white/5 border border-white/5 p-3 rounded-xl space-y-1">
                <Video size={16} className="text-[#D4AF37]" />
                <p className="text-[11px] font-bold text-white">Appels HD</p>
                <p className="text-[9px] text-gray-500">Tutorat en direct</p>
              </div>
              <div className="bg-white/5 border border-white/5 p-3 rounded-xl space-y-1">
                <Smile size={16} className="text-[#D4AF37]" />
                <p className="text-[11px] font-bold text-white">Stickers</p>
                <p className="text-[9px] text-gray-500">Encouragements</p>
              </div>
            </div>

            {filteredContacts.length > 0 && (
              <button
                onClick={() => setActiveContact(filteredContacts[0])}
                className="px-5 py-2.5 bg-gradient-to-r from-[#D4AF37] to-[#F0C940] hover:scale-105 active:scale-95 text-black rounded-xl text-xs font-bold transition-all shadow-lg shadow-[#D4AF37]/15 flex items-center gap-2"
              >
                Démarrer une conversation ({filteredContacts.length} contact{filteredContacts.length > 1 ? "s" : ""})
              </button>
            )}
          </div>
        )}

        {/* WhatsApp Real-time Calling Overlay (Audio & Video) */}
        <AnimatePresence>
          {callingState !== null && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-[1000] bg-[#090e11]/98 backdrop-blur-md flex flex-col justify-between p-8 text-white select-none animate-fade-in"
            >
              {/* Call Top Header */}
              <div className="flex flex-col items-center gap-1.5 mt-8 text-center">
                <span className="text-[10px] tracking-wider uppercase font-extrabold text-[#D4AF37] px-3 py-1 bg-[#D4AF37]/10 rounded-full border border-[#D4AF37]/20 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37] animate-ping" />
                  Appel Réel de bout-en-bout • Auralis Comms
                </span>
                <p className="text-xs text-gray-400 font-mono mt-1">Données et voix cryptées en temps réel via Supabase</p>
              </div>

              {/* Central Caller Info with states */}
              <div className="flex flex-col items-center justify-center relative flex-1">
                {callingState === "incoming" ? (
                  /* INCOMING CALL SCREEN */
                  <div className="flex flex-col items-center">
                    <div className="relative mb-6">
                      <div className="absolute -inset-4 rounded-full bg-emerald-500/10 animate-ping [animation-duration:2.5s]" />
                      <div className="absolute -inset-8 rounded-full bg-emerald-500/5 animate-ping [animation-duration:3s]" />
                      <div className="w-24 h-24 rounded-full bg-[#181818] border-2 border-emerald-500 flex items-center justify-center text-white font-bold text-2xl relative shadow-2xl overflow-hidden">
                        <img
                          src={incomingCallFrom?.avatar_url || auralisLogo}
                          alt="Appelant"
                          className="w-full h-full object-cover rounded-full"
                          onError={(e) => {
                            (e.currentTarget as HTMLImageElement).src = auralisLogo;
                          }}
                        />
                      </div>
                    </div>
                    <h3 className="font-bold text-xl text-white">
                      {incomingCallFrom ? getContactName(incomingCallFrom) : "Tuteur Académique"}
                    </h3>
                    <p className="text-xs text-emerald-400 font-semibold mt-2 uppercase tracking-widest flex items-center gap-2">
                      <Phone size={14} className="animate-bounce" />
                      Appel {callType === "video" ? "Vidéo" : "Audio"} Entrant en temps réel...
                    </p>
                  </div>
                ) : (
                  /* OUTGOING / CONNECTED CALL SCREEN */
                  <div className="flex flex-col items-center w-full">
                    {callType === "video" && callingState === "connected" ? (
                      <div className="relative w-full max-w-lg aspect-video rounded-3xl overflow-hidden border border-white/10 bg-black shadow-2xl flex items-center justify-center">
                        {/* Peer Stream Container (Dynamic rendering) */}
                        <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-tr from-neutral-900 to-neutral-950 p-4 text-center">
                          {peerCameraOn ? (
                            <>
                              <div className="w-20 h-20 rounded-full bg-[#D4AF37]/10 border border-[#D4AF37]/30 flex items-center justify-center font-bold text-[#D4AF37] text-2xl mb-3 animate-pulse">
                                {activeContact?.prenom?.charAt(0)?.toUpperCase() || "T"}
                              </div>
                              <h4 className="font-bold text-sm text-white">
                                {activeContact ? getContactName(activeContact) : "Enseignant"}
                              </h4>
                              <p className="text-xs text-emerald-400 mt-1 flex items-center gap-1">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                                Flux vidéo distant actif
                              </p>
                            </>
                          ) : (
                            <>
                              <div className="w-20 h-20 rounded-full bg-neutral-800 border border-neutral-700 flex items-center justify-center font-bold text-neutral-500 text-2xl mb-3">
                                <VideoOff size={30} />
                              </div>
                              <h4 className="font-bold text-sm text-neutral-400">
                                {activeContact ? getContactName(activeContact) : "Enseignant"}
                              </h4>
                              <p className="text-xs text-red-500 mt-1">
                                Caméra distante désactivée
                              </p>
                            </>
                          )}

                          {/* Peer Mute Indicator */}
                          {peerMuted && (
                            <span className="absolute top-4 left-4 text-[10px] bg-red-600/80 border border-red-500/20 px-2.5 py-1 rounded-full flex items-center gap-1.5 font-bold tracking-wider uppercase">
                              <VolumeX size={12} /> Microphone coupé par le correspondant
                            </span>
                          )}
                        </div>

                        {/* PiP Local User Webcam Video! */}
                        {isCameraOn ? (
                          <video
                            ref={videoRef}
                            autoPlay
                            playsInline
                            muted
                            className="w-28 md:w-36 aspect-[3/4] rounded-2xl border-2 border-[#D4AF37]/40 shadow-2xl object-cover absolute bottom-4 right-4 z-50 bg-neutral-950 transition-all duration-300"
                          />
                        ) : (
                          <div className="w-28 md:w-36 aspect-[3/4] rounded-2xl border-2 border-neutral-700 shadow-2xl bg-neutral-900 flex flex-col items-center justify-center absolute bottom-4 right-4 z-50 transition-all duration-300">
                            <VideoOff size={16} className="text-gray-500" />
                            <span className="text-[8px] text-gray-500 mt-1">Caméra Off</span>
                          </div>
                        )}
                      </div>
                    ) : (
                      /* Audio Call / Calling / Ringing UI */
                      <div className="flex flex-col items-center">
                        <div className="relative">
                          {/* Pulse concentric rings */}
                          <div className="absolute -inset-4 rounded-full bg-[#D4AF37]/10 animate-ping [animation-duration:2.5s]" />
                          <div className="absolute -inset-8 rounded-full bg-[#D4AF37]/5 animate-ping [animation-duration:3s]" />
                          <div className="w-24 h-24 rounded-full bg-neutral-900 border-2 border-[#D4AF37]/30 flex items-center justify-center text-white font-bold text-2xl relative shadow-2xl overflow-hidden">
                            <img
                              src={activeContact?.avatar_url || auralisLogo}
                              alt="Contact"
                              className="w-full h-full object-cover rounded-full"
                              onError={(e) => {
                                (e.currentTarget as HTMLImageElement).src = auralisLogo;
                              }}
                            />
                          </div>
                        </div>
                        <h3 className="font-bold text-lg text-white mt-6">
                          {activeContact ? getContactName(activeContact) : "Formateur"}
                        </h3>
                        <p className="text-xs text-emerald-400 font-semibold mt-1.5 uppercase tracking-widest flex items-center gap-1.5">
                          {callingState === "calling" && (
                            <>
                              <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37] animate-ping" /> Connexion...
                            </>
                          )}
                          {callingState === "ringing" && (
                            <>
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> Sonnerie...
                            </>
                          )}
                          {callingState === "connected" && (
                            <>
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" /> Appel Vocal Établi
                            </>
                          )}
                        </p>

                        {/* Peer Mute Status on audio */}
                        {callingState === "connected" && peerMuted && (
                          <p className="text-[10px] text-red-400 mt-2 flex items-center gap-1 bg-red-950/30 border border-red-500/15 px-3 py-1 rounded-full">
                            <VolumeX size={12} /> Le correspondant a coupé son micro
                          </p>
                        )}
                      </div>
                    )}

                    {/* Call Timer */}
                    {callingState === "connected" && (
                      <p className="font-mono text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1 rounded-full mt-5 font-bold tracking-wider">
                        TEMPS REEL: {Math.floor(callDuration / 60).toString().padStart(2, "0")}:{(callDuration % 60).toString().padStart(2, "0")}
                      </p>
                    )}
                  </div>
                )}
              </div>

              {/* Footer Call Controls */}
              <div className="flex items-center justify-center gap-6 mb-8">
                {callingState === "incoming" ? (
                  /* INCOMING CONTROLS */
                  <>
                    <button
                      onClick={handleDeclineCall}
                      className="p-5 rounded-full bg-red-600 hover:bg-red-700 text-white transition-all hover:scale-110 active:scale-95 shadow-xl shadow-red-600/30 flex items-center justify-center"
                      title="Refuser l'appel"
                    >
                      <Phone size={26} className="rotate-[135deg]" />
                    </button>
                    <button
                      onClick={handleAcceptCall}
                      className="p-5 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white transition-all hover:scale-110 active:scale-95 shadow-xl shadow-emerald-600/30 flex items-center justify-center animate-bounce"
                      title="Accepter l'appel"
                    >
                      <Phone size={26} />
                    </button>
                  </>
                ) : (
                  /* OUTGOING / ACTIVE CONTROLS */
                  <>
                    <button
                      onClick={() => setIsMuted(!isMuted)}
                      className={`p-4 rounded-full border transition-all hover:scale-105 active:scale-95 ${
                        isMuted
                          ? "bg-red-600/20 border-red-500 text-red-500 hover:bg-red-600/30"
                          : "bg-white/5 border-white/10 text-white hover:bg-white/10"
                      }`}
                      title={isMuted ? "Activer le son" : "Couper le son"}
                    >
                      {isMuted ? <MicOff size={20} /> : <Mic size={20} />}
                    </button>
                    <button
                      onClick={handleEndCall}
                      className="p-5 rounded-full bg-red-600 hover:bg-red-700 text-white transition-all hover:scale-110 active:scale-95 shadow-xl shadow-red-600/30"
                      title="Terminer l'appel"
                    >
                      <Phone size={24} className="rotate-[135deg]" />
                    </button>
                    <button
                      onClick={() => setIsCameraOn(!isCameraOn)}
                      className={`p-4 rounded-full border transition-all hover:scale-105 active:scale-95 ${
                        !isCameraOn
                          ? "bg-red-600/20 border-red-500 text-red-500 hover:bg-red-600/30"
                          : "bg-white/5 border-white/10 text-white hover:bg-white/10"
                      }`}
                      title={isCameraOn ? "Désactiver la caméra" : "Activer la caméra"}
                    >
                      {isCameraOn ? <Video size={20} /> : <VideoOff size={20} />}
                    </button>
                  </>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

// ============================================================================
// 4. NOTIFICATIONS
// ============================================================================
export function NotificationsPage() {
  const [notifications, setNotifications] = useState<LocalNotification[]>([]);

  useEffect(() => {
    // Standard system notifications helper
    setNotifications([
      {
        id: "1",
        title: "Bienvenue à bord !",
        message: "Votre compte Auralis a été créé avec succès. Bienvenue dans l'aventure !",
        date: "Aujourd'hui",
        unread: true
      },
      {
        id: "2",
        title: "Objectif quotidien !",
        message: "Auralis vous attend pour votre test d'aujourd'hui. Ne perdez pas votre série !",
        date: "Hier",
        unread: false
      }
    ]);
  }, []);

  const markAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, unread: false })));
    toast.success("Toutes les notifications ont été marquées comme lues !");
  };

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-3xl mx-auto text-white">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight font-[Space_Grotesk]">
            Vos Notifications
          </h1>
          <p className="text-gray-400 text-sm mt-1">
            Restez informé de vos progressions, messages et nouveautés.
          </p>
        </div>
        <button
          onClick={markAllRead}
          className="text-xs text-[#D4AF37] hover:underline font-semibold"
        >
          Tout marquer comme lu
        </button>
      </div>

      <div className="space-y-4">
        {notifications.map((notif) => (
          <div
            key={notif.id}
            className={`p-5 rounded-2xl border transition-all flex gap-4 ${
              notif.unread
                ? "bg-[#D4AF37]/5 border-[#D4AF37]/20"
                : "bg-[#111] border-white/5"
            }`}
          >
            <div className="p-2.5 bg-black/30 rounded-xl text-[#D4AF37] h-fit">
              <Bell size={18} />
            </div>
            <div className="flex-1 space-y-1">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-sm text-white">{notif.title}</h3>
                <span className="text-[10px] text-gray-500 font-medium">{notif.date}</span>
              </div>
              <p className="text-gray-400 text-xs leading-relaxed">{notif.message}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================================================
// 5. PARAMÈTRES (Durable profile update editor)
// ============================================================================
export function Parametres() {
  const { profile, refreshProfile } = useAuth();
  const [prenom, setPrenom] = useState(profile?.prenom || "");
  const [nom, setNom] = useState(profile?.nom || "");
  const [pseudo, setPseudo] = useState(profile?.pseudo || "");
  const [adminNiveauGlobal, setAdminNiveauGlobal] = useState(profile?.niveau_global || "");
  const [adminNiveauComprehension, setAdminNiveauComprehension] = useState(profile?.niveau_comprehension || "");
  const [updating, setUpdating] = useState(false);

  const isAdmin = profile?.role === "admin";
  const points = profile?.points || 0;
  const currentLevelNum = calculateLevelFromXP(points);
  const currentRoleTitle = getRoleTitle(currentLevelNum, profile?.role || "apprenant");
  const computedNiveauGlobal = profile?.niveau_global || `Niveau ${currentLevelNum} - ${currentRoleTitle}`;
  const computedNiveauComprehension = profile?.niveau_comprehension || calculateComprehensionLevel(points);

  useEffect(() => {
    if (profile) {
      setPrenom(profile.prenom || "");
      setNom(profile.nom || "");
      setPseudo(profile.pseudo || "");
      setAdminNiveauGlobal(profile.niveau_global || "");
      setAdminNiveauComprehension(profile.niveau_comprehension || "");
    }
  }, [profile]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pseudo || !prenom) {
      toast.error("Le prénom et le pseudo sont obligatoires !");
      return;
    }

    setUpdating(true);
    try {
      const updateData: Record<string, unknown> = {
        prenom,
        nom,
        pseudo,
      };

      // ONLY ADMIN can override levels in database under any pretext
      if (isAdmin) {
        if (adminNiveauGlobal) updateData.niveau_global = adminNiveauGlobal;
        if (adminNiveauComprehension) updateData.niveau_comprehension = adminNiveauComprehension;
      }

      const { error } = await supabase
        .from("profiles")
        .update(updateData)
        .eq("id", profile?.id);

      if (error) throw error;

      await refreshProfile();
      toast.success("Profil mis à jour avec succès !");
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : String(err);
      toast.error("Erreur d'enregistrement: " + errorMsg);
    } finally {
      setUpdating(false);
    }
  };

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-2xl mx-auto text-white">
      <div>
        <h1 className="text-3xl font-extrabold tracking-tight font-[Space_Grotesk]">
          Paramètres du compte
        </h1>
        <p className="text-gray-400 text-sm mt-1">
          Gérez vos informations personnelles et consultez vos niveaux certifiés.
        </p>
      </div>

      <form onSubmit={handleSave} className="bg-[#111] border border-white/5 rounded-2xl p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Prénom</label>
            <input
              type="text"
              value={prenom}
              onChange={(e) => setPrenom(e.target.value)}
              className="w-full bg-[#161616] border border-white/10 focus:border-[#D4AF37]/40 rounded-xl px-4 py-2.5 text-xs text-white outline-none transition-all"
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Nom</label>
            <input
              type="text"
              value={nom}
              onChange={(e) => setNom(e.target.value)}
              className="w-full bg-[#161616] border border-white/10 focus:border-[#D4AF37]/40 rounded-xl px-4 py-2.5 text-xs text-white outline-none transition-all"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Pseudo</label>
          <input
            type="text"
            value={pseudo}
            onChange={(e) => setPseudo(e.target.value)}
            className="w-full bg-[#161616] border border-white/10 focus:border-[#D4AF37]/40 rounded-xl px-4 py-2.5 text-xs text-white outline-none transition-all"
          />
        </div>

        {/* LOCKED READ-ONLY LEVEL BADGES FOR REGULAR USERS / ADMIN EDITABLE */}
        <div className="space-y-4 pt-2 border-t border-white/10">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-[#D4AF37] uppercase tracking-wider flex items-center gap-1.5">
              <span>Niveau Global & Compréhension</span>
            </label>
            {!isAdmin && (
              <span className="text-[10px] font-semibold bg-[#D4AF37]/10 text-[#D4AF37] border border-[#D4AF37]/20 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                🔒 Calculé par l'IA & non modifiable
              </span>
            )}
          </div>

          {!isAdmin ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="bg-[#161616] border border-white/10 rounded-xl p-3.5 space-y-1">
                <p className="text-[10px] font-bold text-gray-400 uppercase">Niveau Global (XP: {points} pts)</p>
                <p className="text-sm font-bold text-[#D4AF37] font-[Space_Grotesk]">
                  {computedNiveauGlobal}
                </p>
                <p className="text-[10px] text-gray-500">
                  Niveau {currentLevelNum} / 500
                </p>
              </div>

              <div className="bg-[#161616] border border-white/10 rounded-xl p-3.5 space-y-1">
                <p className="text-[10px] font-bold text-gray-400 uppercase">Niveau de Compréhension</p>
                <p className="text-sm font-bold text-amber-300 font-[Space_Grotesk]">
                  {computedNiveauComprehension}
                </p>
                <p className="text-[10px] text-gray-500">
                  Évalué en temps réel selon vos quiz
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-3 bg-[#181818] border border-amber-500/30 p-4 rounded-xl">
              <p className="text-xs text-amber-400 font-bold">
                👑 Mode Administrateur : Vous avez le pouvoir exclusif d'éditer manuellement les niveaux
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] text-gray-400 block mb-1">Niveau Global Custom</label>
                  <input
                    type="text"
                    value={adminNiveauGlobal}
                    onChange={(e) => setAdminNiveauGlobal(e.target.value)}
                    placeholder="Ex: Niveau 400 - Professeur Certifié"
                    className="w-full bg-[#111] border border-white/10 rounded-lg px-3 py-2 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-gray-400 block mb-1">Niveau Compréhension Custom</label>
                  <input
                    type="text"
                    value={adminNiveauComprehension}
                    onChange={(e) => setAdminNiveauComprehension(e.target.value)}
                    placeholder="Ex: 98% - Compréhension Parfaite"
                    className="w-full bg-[#111] border border-white/10 rounded-lg px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>
            </div>
          )}

          {!isAdmin && (
            <p className="text-[11px] text-gray-400 italic bg-white/5 p-3 rounded-xl border border-white/5">
              💡 <strong>Règle de sécurité :</strong> Vos niveaux augmentent automatiquement en gagnant des points XP lorsque vous réalisez des quiz, suivez des cours et restez actif sur la plateforme. Seul un administrateur peut modifier directement ces paramètres.
            </p>
          )}
        </div>

        <button
          type="submit"
          disabled={updating}
          className="w-full py-3 bg-gradient-to-r from-[#D4AF37] to-[#F0C940] hover:scale-[1.01] active:scale-95 disabled:opacity-50 text-black font-bold rounded-xl text-xs transition-all shadow-md shadow-[#D4AF37]/10 flex items-center justify-center gap-2"
        >
          {updating ? (
            <div className="w-4 h-4 border-2 border-black/20 border-t-black animate-spin rounded-full" />
          ) : (
            <>Sauvegarder les modifications</>
          )}
        </button>
      </form>
    </div>
  );
}

// ============================================================================
// 6. FORMATEUR: MES COURS
// ============================================================================
export function FormateurCours() {
  const { user } = useAuth();
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCreatedCourses = async () => {
      try {
        const { data } = await supabase
          .from("courses")
          .select("*")
          .eq("createur_id", user?.id);
        if (data) {
          setCourses(data as Course[]);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    if (user) fetchCreatedCourses();
  }, [user]);

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-7xl mx-auto text-white">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight font-[Space_Grotesk]">
            Mes Formations Créées
          </h1>
          <p className="text-gray-400 text-sm mt-1">
            Gérez vos programmes, ajoutez des modules ou créez de nouveaux parcours académiques.
          </p>
        </div>
        <a
          href="/formateur/cours/nouveau"
          className="px-4 py-2.5 bg-gradient-to-r from-[#D4AF37] to-[#F0C940] hover:scale-105 active:scale-95 text-black rounded-xl text-xs font-bold transition-all shadow-md flex items-center gap-2 w-fit"
        >
          <PlusCircle size={14} /> Créer un cours
        </a>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-2 border-[#D4AF37]/20 border-t-[#D4AF37] animate-spin rounded-full" />
        </div>
      ) : courses.length === 0 ? (
        <div className="text-center py-16 bg-[#111] rounded-2xl border border-white/5 flex flex-col items-center justify-center space-y-4">
          <BookOpen size={40} className="text-gray-600" />
          <p className="text-gray-500 text-sm">Vous n'avez créé aucun cours pour le moment.</p>
          <a
            href="/formateur/cours/nouveau"
            className="text-xs text-[#D4AF37] font-semibold hover:underline"
          >
            Créer votre premier cours dès maintenant
          </a>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {courses.map((course) => (
            <motion.div
              key={course.id}
              whileHover={{ scale: 1.025, y: -4 }}
              transition={{ duration: 0.25, ease: "easeOut" }}
              className="bg-[#111] border border-white/5 hover:border-[#D4AF37]/30 rounded-2xl p-5 flex flex-col justify-between transition-all duration-300 hover:shadow-xl hover:shadow-[#D4AF37]/10 group"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase font-bold text-[#D4AF37] px-2.5 py-0.5 bg-[#D4AF37]/10 rounded-full border border-[#D4AF37]/20">
                    {course.langue}
                  </span>
                  <span className="text-[11px] text-gray-500">Niveau: {course.niveau_cible}</span>
                </div>
                <h3 className="font-bold text-lg text-white mt-3 group-hover:text-[#D4AF37] transition-colors">{course.titre}</h3>
                <p className="text-gray-400 text-xs mt-2 line-clamp-3 leading-relaxed">
                  {course.description}
                </p>
              </div>
              <div className="mt-6 flex items-center justify-between border-t border-white/5 pt-4">
                <span className="text-xs text-gray-500 font-semibold">Statut: Publié</span>
                <button className="text-xs text-[#D4AF37] hover:underline font-bold flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                  Éditer <ChevronRight size={12} />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}

// ============================================================================
// 7. FORMATEUR: CRÉER UN COURS (Add course insertion form)
// ============================================================================
export function FormateurCoursNouveau() {
  const { user } = useAuth();
  const [titre, setTitre] = useState("");
  const [description, setDescription] = useState("");
  const [langue, setLangue] = useState("Anglais");
  const [niveauCible, setNiveauCible] = useState("Débutant");
  const [inserting, setInserting] = useState(false);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!titre || !description) {
      toast.error("Veuillez remplir tous les champs obligatoires !");
      return;
    }

    setInserting(true);
    try {
      const { error } = await supabase
        .from("courses")
        .insert([{
          titre,
          description,
          langue,
          niveau_cible: niveauCible,
          createur_id: user?.id
        }]);

      if (error) throw error;

      if (user?.id) {
        await awardXP({
          userId: user.id,
          amount: 350,
          actionName: `Création de la formation "${titre}"`,
          userRole: "formateur",
        });
      }

      toast.success("Cours créé avec succès ! +350 XP attribués !");
      setTitre("");
      setDescription("");
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : String(err);
      toast.error("Erreur de création: " + errorMsg);
    } finally {
      setInserting(false);
    }
  };

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-2xl mx-auto text-white">
      <div>
        <h1 className="text-3xl font-extrabold tracking-tight font-[Space_Grotesk]">
          Créer un Nouveau Cours
        </h1>
        <p className="text-gray-400 text-sm mt-1">
          Formulez un nouveau programme pédagogique immersif.
        </p>
      </div>

      <form onSubmit={handleCreate} className="bg-[#111] border border-white/5 rounded-2xl p-6 space-y-6">
        <div className="space-y-2">
          <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Titre du cours *</label>
          <input
            type="text"
            placeholder="Ex: Maîtriser le vocabulaire des affaires"
            value={titre}
            onChange={(e) => setTitre(e.target.value)}
            className="w-full bg-[#161616] border border-white/10 focus:border-[#D4AF37]/40 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-600 outline-none transition-all"
            required
          />
        </div>

        <div className="space-y-2">
          <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Description de la formation *</label>
          <textarea
            rows={4}
            placeholder="Décrivez brièvement le programme..."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full bg-[#161616] border border-white/10 focus:border-[#D4AF37]/40 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-600 outline-none transition-all"
            required
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Langue d'apprentissage</label>
            <select
              value={langue}
              onChange={(e) => setLangue(e.target.value)}
              className="w-full bg-[#161616] border border-white/10 focus:border-[#D4AF37]/40 rounded-xl px-4 py-2.5 text-xs text-white outline-none transition-all"
            >
              <option value="Anglais">Anglais</option>
              <option value="Espagnol">Espagnol</option>
              <option value="Allemand">Allemand</option>
              <option value="Français">Français</option>
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Niveau ciblé</label>
            <select
              value={niveauCible}
              onChange={(e) => setNiveauCible(e.target.value)}
              className="w-full bg-[#161616] border border-white/10 focus:border-[#D4AF37]/40 rounded-xl px-4 py-2.5 text-xs text-white outline-none transition-all"
            >
              <option value="Débutant">Débutant (A1-A2)</option>
              <option value="Intermédiaire">Intermédiaire (B1-B2)</option>
              <option value="Avancé">Avancé (C1-C2)</option>
            </select>
          </div>
        </div>

        <button
          type="submit"
          disabled={inserting}
          className="w-full py-3 bg-gradient-to-r from-[#D4AF37] to-[#F0C940] hover:scale-[1.01] active:scale-95 disabled:opacity-50 text-black font-bold rounded-xl text-xs transition-all shadow-md flex items-center justify-center gap-2"
        >
          {inserting ? (
            <div className="w-4 h-4 border-2 border-black/20 border-t-black animate-spin rounded-full" />
          ) : (
            <>Créer et publier le cours</>
          )}
        </button>
      </form>
    </div>
  );
}

// ============================================================================
// 8. FORMATEUR: APPRENANTS
// ============================================================================
export function FormateurApprenants() {
  const [learners, setLearners] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchApprenants = async () => {
      try {
        const { data } = await supabase
          .from("profiles")
          .select("*")
          .eq("role", "apprenant")
          .limit(10);
        if (data) {
          setLearners(data as Profile[]);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchApprenants();
  }, []);

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-5xl mx-auto text-white">
      <div>
        <h1 className="text-3xl font-extrabold tracking-tight font-[Space_Grotesk]">
          Suivi des Apprenants
        </h1>
        <p className="text-gray-400 text-sm mt-1">
          Visualisez les progrès, scores et assiduités des apprenants inscrits à vos cours.
        </p>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-2 border-[#D4AF37]/20 border-t-[#D4AF37] animate-spin rounded-full" />
        </div>
      ) : learners.length === 0 ? (
        <div className="text-center py-16 bg-[#111] rounded-2xl border border-white/5 flex flex-col items-center justify-center space-y-2">
          <Users size={32} className="text-gray-600" />
          <p className="text-gray-500 text-sm">Aucun apprenant enregistré pour le moment.</p>
        </div>
      ) : (
        <div className="bg-[#111] border border-white/5 rounded-2xl overflow-hidden divide-y divide-white/5">
          {learners.map((learner) => (
            <div
              key={learner.id}
              className="flex flex-col sm:flex-row sm:items-center justify-between p-5 hover:bg-white/[0.01] transition-all gap-4"
            >
              <div className="flex items-center gap-4">
                <div className="w-11 h-11 rounded-full bg-gradient-to-br from-white/5 to-white/10 flex items-center justify-center text-white font-bold text-sm border border-white/10">
                  {learner.prenom?.charAt(0).toUpperCase()}
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white flex items-center gap-2">
                    {learner.prenom} {learner.nom}
                  </h3>
                  <span className="text-[10px] text-[#D4AF37] font-semibold bg-[#D4AF37]/10 px-2 py-0.5 rounded-full">
                    {learner.niveau_global || "A1 - Débutant"}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-6 justify-between sm:justify-end">
                <div className="text-left sm:text-right">
                  <div className="text-[10px] text-gray-500 uppercase font-bold tracking-wider">Score Global</div>
                  <div className="font-extrabold text-[#D4AF37] text-sm">{learner.points || 0} XP</div>
                </div>

                <div className="text-left sm:text-right">
                  <div className="text-[10px] text-gray-500 uppercase font-bold tracking-wider">Série de Jours</div>
                  <div className="font-bold text-orange-500 text-sm flex items-center gap-1 justify-end">
                    <Flame size={12} className="fill-orange-500" /> {learner.streak_jours || 0} jours
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
