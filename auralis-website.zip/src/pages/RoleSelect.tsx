import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { GraduationCap, BookOpen, CheckCircle2, ArrowRight, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { auralisLogo } from "@/lib/assets";

export default function RoleSelect() {
  const navigate = useNavigate();
  const { user, profile, refreshProfile, loading: authLoading } = useAuth();
  const [role, setRole] = useState<"apprenant" | "formateur">("apprenant");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [oauthProvider, setOauthProvider] = useState<string | null>(null);

  useEffect(() => {
    const provider = sessionStorage.getItem("oauth_provider");
    if (provider) {
      setOauthProvider(provider);
    }
  }, []);

  // If profile is already onboarded and has a role, redirect to dashboard immediately
  useEffect(() => {
    if (!authLoading && profile?.is_onboarded && profile?.role) {
      navigate(
        profile.role === "formateur" ? "/loading-formateur" : "/loading-apprenant",
        { replace: true }
      );
    }
  }, [authLoading, profile, navigate]);

  const handleConfirm = async () => {
    if (!user) return;
    setLoading(true);
    setError("");

    try {
      // Use SECURITY DEFINER RPC to update user role and set onboarded = true in DB
      const { data: result, error: rpcError } = await supabase.rpc("complete_onboarding", { _role: role });

      if (rpcError) {
        console.error("RoleSelect RPC error:", rpcError);
        // Fallback: try direct profile update if RPC fails
        const { error: directErr } = await supabase
          .from("profiles")
          .update({ role, is_onboarded: true })
          .eq("id", user.id);

        if (directErr) {
          setError("Impossible d'enregistrer le rôle dans la base de données. Réessayez.");
          setLoading(false);
          return;
        }
      } else {
        const profileRes = result as { id?: string; role?: string; is_onboarded?: boolean; error?: string };
        if (profileRes.error) {
          console.error("RoleSelect profile error:", profileRes.error);
        }
      }

      // Clear OAuth session state flags
      sessionStorage.removeItem("oauth_provider");
      sessionStorage.removeItem("oauth_login_in_progress");

      // Refresh AuthContext profile
      await refreshProfile();

      // Redirect immediately to dedicated dashboard loading screen
      navigate(
        role === "formateur" ? "/loading-formateur" : "/loading-apprenant",
        { replace: true }
      );
    } catch (err) {
      console.error("RoleSelect error:", err);
      setError("Une erreur inattendue est survenue. Réessayez.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page min-h-screen flex items-center justify-center relative overflow-hidden bg-[#0A0A0A] text-white">
      {/* Background radial glow */}
      <div className="absolute inset-0 bg-radial from-[#D4AF37]/10 via-transparent to-transparent pointer-events-none" />

      {/* Golden floating particles */}
      <div className="particles-container absolute inset-0 pointer-events-none" aria-hidden>
        {Array.from({ length: 20 }).map((_, i) => (
          <span key={i} className="particle" style={{ "--i": i } as React.CSSProperties} />
        ))}
      </div>

      <div className="relative z-10 w-full max-w-lg mx-4 py-8">
        <div className="text-center mb-6">
          <img src={auralisLogo} alt="AURALIS" className="w-24 h-24 mx-auto rounded-full object-cover border-2 border-[#D4AF37]/30 shadow-lg shadow-[#D4AF37]/10" />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#161616]/95 border border-[#D4AF37]/30 rounded-3xl p-6 md:p-8 backdrop-blur-xl shadow-2xl shadow-[#D4AF37]/10 space-y-6"
        >
          {/* OAuth Success Badge */}
          {oauthProvider && (
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-[#D4AF37]/10 border border-[#D4AF37]/30 rounded-2xl p-3.5 flex items-start gap-3"
            >
              <div className="p-1.5 bg-[#D4AF37]/20 rounded-lg text-[#D4AF37] flex-shrink-0 mt-0.5">
                <CheckCircle2 size={18} />
              </div>
              <div className="text-xs space-y-0.5">
                <p className="font-bold text-[#D4AF37] flex items-center gap-1.5">
                  Authentification {oauthProvider} Réussie !
                </p>
                <p className="text-gray-300">
                  Votre compte a été vérifié et enregistré en base de données.
                </p>
              </div>
            </motion.div>
          )}

          <div className="text-center space-y-1">
            <h1
              className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-[#D4AF37] via-[#F0C940] to-amber-200"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              Sélectionnez votre profil
            </h1>
            <p className="text-gray-400 text-xs leading-relaxed max-w-sm mx-auto">
              Afin de vous orienter vers votre tableau de bord dédié, indiquez si vous vous connectez en tant qu'Apprenant ou Formateur.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <RoleOption
              selected={role === "apprenant"}
              onClick={() => setRole("apprenant")}
              icon={<GraduationCap size={32} />}
              label="Apprenant"
              desc="Accès aux cours, parcours d'apprentissage & statistiques de progression"
            />
            <RoleOption
              selected={role === "formateur"}
              onClick={() => setRole("formateur")}
              icon={<BookOpen size={32} />}
              label="Formateur"
              desc="Gestion des cours, création de contenus & suivi des élèves"
            />
          </div>

          {error && (
            <div className="text-xs text-red-400 bg-red-400/10 border border-red-400/20 rounded-xl p-3">
              {error}
            </div>
          )}

          <div className="space-y-2 pt-2">
            <Button
              onClick={handleConfirm}
              disabled={loading}
              className="w-full bg-gradient-to-r from-[#D4AF37] to-[#F0C940] hover:scale-[1.01] active:scale-[0.99] text-black font-bold h-12 rounded-xl text-sm transition-all shadow-lg shadow-[#D4AF37]/20 flex items-center justify-center gap-2"
            >
              {loading ? (
                "Enregistrement du profil..."
              ) : (
                <>
                  Valider et accéder à mon tableau de bord <ArrowRight size={16} />
                </>
              )}
            </Button>

            <div className="flex items-center justify-center gap-1.5 text-[11px] text-gray-500 font-medium">
              <ShieldCheck size={13} className="text-[#D4AF37]" />
              Vos données sont sécurisées et synchronisées en temps réel.
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

function RoleOption({
  selected,
  onClick,
  icon,
  label,
  desc,
}: {
  selected: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
  desc: string;
}) {
  return (
    <motion.button
      type="button"
      onClick={onClick}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className={`rounded-2xl p-5 text-left transition-all duration-300 border flex flex-col justify-between relative overflow-hidden ${
        selected
          ? "bg-[#D4AF37]/15 border-[#D4AF37] shadow-lg shadow-[#D4AF37]/10"
          : "bg-[#101010] border-white/10 hover:border-white/20 text-gray-400"
      }`}
    >
      {selected && (
        <div className="absolute top-3 right-3 w-2 h-2 rounded-full bg-[#D4AF37] shadow-[0_0_8px_#D4AF37]" />
      )}
      <div>
        <div className={`mb-3 ${selected ? "text-[#D4AF37]" : "text-gray-500"}`}>
          {icon}
        </div>
        <div className={`text-base font-extrabold ${selected ? "text-[#D4AF37]" : "text-white"}`}>
          {label}
        </div>
        <p className="text-[11px] text-gray-400 mt-1.5 leading-relaxed">{desc}</p>
      </div>
    </motion.button>
  );
}
