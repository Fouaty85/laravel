import { useState, useEffect, useCallback, Suspense, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import type { User } from "@supabase/supabase-js";
import { Label } from "@/components/ui/label";
import {
  signUpWithEmail,
  signInWithEmail,
  signInWithGoogle,
  signInWithMicrosoft,
  translateAuthError,
} from "@/lib/supabase";
import { GraduationCap, BookOpen, Eye, EyeOff } from "lucide-react";
import { useAuralisAvatar, useAuralisStore } from "@/hooks/useAuralisAvatar";
import { useAvatarScenario } from "@/hooks/useAvatarScenario";
import AuralisWelcomeModal from "@/components/auralis/AuralisWelcomeModal";
import AuralisAvatar from "@/components/auralis/AuralisAvatar";

type Mode = "login" | "register";

export default function Auth() {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const { speak } = useAuralisAvatar();
  const {
    scenarioBienvenuePage,
    scenarioConnexionEnCours,
    scenarioConnexionReussie,
    scenarioErreurConnexion,
    scenarioInscriptionReussie,
    scenarioChampFocus,
    scenarioFrappe,
  } = useAvatarScenario();

  const [mode, setMode] = useState<Mode>("login");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  // Form fields
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [pseudo, setPseudo] = useState("");
  const [prenom, setPrenom] = useState("");
  const [nom, setNom] = useState("");
  const [role, setRole] = useState<"apprenant" | "formateur">("apprenant");

  const lastTypingRef = useRef(0);

  const handleTyping = () => {
    const now = Date.now();
    if (now - lastTypingRef.current > 3000) {
      scenarioFrappe();
      lastTypingRef.current = now;
    }
  };

  // Check profile and redirect accordingly
  const ensureProfileAndRedirect = useCallback(
    async (_signedUser: User) => {
      try {
        const { data: result, error: rpcError } = await supabase.rpc("ensure_profile_exists");

        if (rpcError || !result) {
          console.error("ensure_profile_exists error:", rpcError);
          setError("Impossible de finaliser votre profil. Réessayez.");
          return;
        }

        const profile = result as {
          id: string;
          role: string;
          is_onboarded: boolean;
          exists: boolean;
          error?: string;
          prenom?: string;
          pseudo?: string;
        };

        if (profile.error) {
          setError(profile.error);
          return;
        }

        const welcomeName = profile.prenom || profile.pseudo || "";

        // If user is already onboarded and has chosen a role, redirect directly to their dedicated interface
        if (profile.is_onboarded && profile.role) {
          sessionStorage.removeItem("oauth_provider");
          sessionStorage.removeItem("oauth_login_in_progress");

          scenarioConnexionReussie(welcomeName);
          setTimeout(() => {
            if (profile.role === "admin") {
              navigate("/admin", { replace: true });
            } else {
              navigate(
                profile.role === "formateur" ? "/loading-formateur" : "/loading-apprenant",
                { replace: true }
              );
            }
          }, 1200);
          return;
        }

        // If user is new or hasn't selected a role yet, ask them to select a role
        scenarioConnexionReussie(welcomeName);
        setTimeout(() => {
          navigate("/role-select", { replace: true });
        }, 1200);
      } catch (err) {
        console.error("ensureProfileAndRedirect catch:", err);
        setError("Une erreur est survenue. Réessayez.");
        scenarioErreurConnexion("Une erreur est survenue lors de la connexion.");
      }
    },
    [navigate, scenarioConnexionReussie, scenarioErreurConnexion]
  );

  // Listen for OAuth sign-in events
  useEffect(() => {
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === "SIGNED_IN" && session?.user) {
        setTimeout(() => {
          void ensureProfileAndRedirect(session.user);
        }, 500);
      }
    });
    return () => subscription.unsubscribe();
  }, [ensureProfileAndRedirect]);

  useEffect(() => {
    if (!authLoading && user) {
      void ensureProfileAndRedirect(user);
    }
  }, [authLoading, user, ensureProfileAndRedirect]);

  const resetForm = () => {
    setError("");
    setSuccess("");
    setShowPassword(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    resetForm();

    try {
      if (mode === "login") {
        scenarioConnexionEnCours();
        const { data, error } = await signInWithEmail(email, password);
        if (error) {
          const transErr = "Identifiants incorrects. Vérifiez votre email et mot de passe.";
          setError(transErr);
          scenarioErreurConnexion(transErr);
        } else if (data.user) {
          await ensureProfileAndRedirect(data.user);
        }
      } else {
        if (!pseudo || !prenom || !nom) {
          const errStr = "Veuillez remplir tous les champs.";
          setError(errStr);
          setLoading(false);
          scenarioErreurConnexion(errStr);
          return;
        }

        // Check pseudo uniqueness before signup
        const { data: existingPseudo } = await supabase
          .from("profiles")
          .select("id")
          .eq("pseudo", pseudo)
          .maybeSingle();

        if (existingPseudo) {
          const errStr = "Ce pseudo est déjà utilisé. Choisissez-en un autre.";
          setError(errStr);
          setLoading(false);
          scenarioErreurConnexion(errStr);
          return;
        }

        const { error } = await signUpWithEmail({
          email,
          password,
          pseudo,
          prenom,
          nom,
          role,
        });

        if (error) {
          const transErr = translateAuthError(error.message);
          setError(transErr);
          scenarioErreurConnexion(transErr);
        } else {
          setSuccess("Compte créé ! Vérifiez votre email pour confirmer votre inscription.");
          scenarioInscriptionReussie(prenom, role);
        }
      }
    } catch {
      const genericErr = "Une erreur inattendue est survenue.";
      setError(genericErr);
      scenarioErreurConnexion(genericErr);
    } finally {
      setLoading(false);
    }
  };

  const switchMode = (newMode: Mode) => {
    resetForm();
    setMode(newMode);
    if (newMode === "register") {
      scenarioBienvenuePage();
    } else {
      const store = useAuralisStore.getState();
      store.setGesture("nod");
      store.setExpression("smile_light");
      setTimeout(() => {
        const innerStore = useAuralisStore.getState();
        innerStore.setGesture("idle");
        innerStore.setExpression("neutral");
      }, 800);
    }
  };

  const handleRoleSelect = (selectedRole: "apprenant" | "formateur") => {
    setRole(selectedRole);
    if (selectedRole === "apprenant") {
      speak("Excellent choix ! En tant qu'apprenant, accédez à d'innombrables cours.", "celebrate");
    } else {
      speak("Parfait ! En tant que formateur, partagez votre savoir avec nos apprenants.", "nod");
    }
  };

  const handleOAuthGoogle = async () => {
    setLoading(true);
    resetForm();
    sessionStorage.setItem("oauth_provider", "Google");
    sessionStorage.setItem("oauth_login_in_progress", "true");
    try {
      const { error } = await signInWithGoogle();
      if (error) {
        sessionStorage.removeItem("oauth_provider");
        sessionStorage.removeItem("oauth_login_in_progress");
        setError(translateAuthError(error.message));
        return;
      }

      const { data: userData } = await supabase.auth.getUser();
      if (userData.user) {
        await ensureProfileAndRedirect(userData.user);
      }
    } catch {
      sessionStorage.removeItem("oauth_provider");
      sessionStorage.removeItem("oauth_login_in_progress");
      setError("Erreur lors de la connexion Google.");
    } finally {
      setLoading(false);
    }
  };

  const handleOAuthMicrosoft = async () => {
    setLoading(true);
    resetForm();
    sessionStorage.setItem("oauth_provider", "Microsoft");
    sessionStorage.setItem("oauth_login_in_progress", "true");
    try {
      const { error } = await signInWithMicrosoft();
      if (error) {
        sessionStorage.removeItem("oauth_provider");
        sessionStorage.removeItem("oauth_login_in_progress");
        setError(translateAuthError(error.message));
        return;
      }

      const { data: userData } = await supabase.auth.getUser();
      if (userData.user) {
        await ensureProfileAndRedirect(userData.user);
      }
    } catch {
      sessionStorage.removeItem("oauth_provider");
      sessionStorage.removeItem("oauth_login_in_progress");
      setError("Erreur lors de la connexion Microsoft.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "#0A0A0A" }} className="overflow-y-auto overflow-x-hidden md:overflow-hidden md:h-screen w-full">
      {/* Welcome modal popup on first visit */}
      <AuralisWelcomeModal showAvatar={false} />

      {/* LEFT COLUMN: 3D Avatar (hidden on mobile, flex on desktop) */}
      <div className="hidden md:flex md:flex-1 relative flex-col items-center justify-end overflow-hidden">
        {/* Decorative ambient background */}
        <div style={{ position: "absolute", inset: 0, background: "radial-gradient(ellipse at center, #111111 0%, #0A0A0A 100%)", zIndex: 0 }} />
        <div
          style={{
            position: "absolute",
            width: "300px",
            height: "300px",
            bottom: "-50px",
            left: "50%",
            transform: "translateX(-50%)",
            background: "radial-gradient(circle, rgba(212,175,55,0.08) 0%, transparent 70%)",
            zIndex: 1,
          }}
        />

        {/* 3D Model Render */}
        <div className="w-full h-[85vh] relative z-10">
          <Suspense
            fallback={
              <div className="flex items-center justify-center h-full">
                <div className="w-10 h-10 rounded-full border-2 border-[#D4AF37]/30 border-t-[#D4AF37] animate-spin" />
              </div>
            }
          >
            <AuralisAvatar size="large" locked={true} className="w-full h-full" />
          </Suspense>
        </div>

        {/* Text bottom of left column */}
        <div className="absolute bottom-8 text-center w-full z-20 pointer-events-none">
          <h1 style={{ color: "#D4AF37", fontSize: "28px", fontWeight: 800, letterSpacing: "0.1em", margin: 0 }}>
            AURALIS
          </h1>
          <p style={{ color: "#A0A0A0", fontSize: "13px", marginTop: "4px", margin: 0 }}>
            Votre compagnon d'apprentissage IA
          </p>
        </div>
      </div>

      {/* RIGHT COLUMN: Glassmorphism Form container */}
      <div className="w-full md:w-[480px] md:min-w-[480px] flex items-center justify-center p-6 sm:p-12 relative z-10">
        {/* Mobile top Logo header */}
        <div className="md:hidden absolute top-6 left-1/2 -translate-x-1/2 text-center">
          <span style={{ color: "#D4AF37", fontSize: "22px", fontWeight: 800 }}>AURALIS</span>
        </div>

        {/* Card wrapper */}
        <div
          style={{
            width: "100%",
            maxWidth: "420px",
            background: "rgba(26,26,26,0.95)",
            border: "1px solid rgba(212,175,55,0.2)",
            borderRadius: "24px",
            padding: mode === "register" ? "20px 24px" : "40px 32px",
            boxShadow: "0 0 60px rgba(212,175,55,0.1)",
          }}
        >
          {/* Mobile-only avatar circle */}
          <div className="md:hidden flex justify-center mb-6">
            <div className="w-24 h-24 rounded-full border-2 border-[#D4AF37]/50 bg-neutral-950/80 relative overflow-hidden shadow-lg shadow-black flex items-center justify-center">
              <Suspense fallback={null}>
                <AuralisAvatar size="small" locked={true} className="w-full h-full" />
              </Suspense>
            </div>
          </div>

          {/* Mode Tabs: Connexion / Inscription */}
          <div style={{ display: "flex", marginBottom: mode === "register" ? "12px" : "24px", borderRadius: "12px", overflow: "hidden", border: "1px solid rgba(212,175,55,0.2)" }}>
            <button
              type="button"
              onClick={() => switchMode("login")}
              style={{
                flex: 1,
                padding: "12px 0",
                fontSize: "14px",
                fontWeight: 600,
                cursor: "pointer",
                border: "none",
                background: mode === "login" ? "rgba(212,175,55,0.15)" : "transparent",
                color: mode === "login" ? "#D4AF37" : "#A0A0A0",
                transition: "all 0.2s",
              }}
            >
              Connexion
            </button>
            <button
              type="button"
              onClick={() => switchMode("register")}
              style={{
                flex: 1,
                padding: "12px 0",
                fontSize: "14px",
                fontWeight: 600,
                cursor: "pointer",
                border: "none",
                background: mode === "register" ? "rgba(212,175,55,0.15)" : "transparent",
                color: mode === "register" ? "#D4AF37" : "#A0A0A0",
                transition: "all 0.2s",
              }}
            >
              Inscription
            </button>
          </div>

          <AnimatePresence mode="wait">
            <motion.form
              key={mode}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              onSubmit={handleSubmit}
              className={mode === "register" ? "space-y-2" : "space-y-4"}
            >
              {mode === "register" && (
                <>
                  {/* Role Selector card */}
                  <div className="grid grid-cols-2 gap-3 mb-2">
                    <RoleCard
                      selected={role === "apprenant"}
                      onClick={() => handleRoleSelect("apprenant")}
                      icon={<GraduationCap size={24} />}
                      label="Apprenant"
                      desc="Je veux apprendre"
                    />
                    <RoleCard
                      selected={role === "formateur"}
                      onClick={() => handleRoleSelect("formateur")}
                      icon={<BookOpen size={24} />}
                      label="Formateur"
                      desc="Je veux enseigner"
                    />
                  </div>

                  {/* Name fields */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <Label className="text-gold-muted text-xs">Prénom</Label>
                      <input
                        type="text"
                        value={prenom}
                        onChange={(e) => {
                          setPrenom(e.target.value);
                          handleTyping();
                        }}
                        onFocus={() => scenarioChampFocus("prenom")}
                        placeholder="Jean"
                        required
                        style={{
                          width: "100%",
                          padding: mode === "register" ? "10px 12px" : "14px 16px",
                          background: "#222222",
                          border: "1px solid rgba(212,175,55,0.15)",
                          borderRadius: "12px",
                          color: "#FFFFFF",
                          fontSize: "15px",
                          transition: "all 0.2s",
                          outline: "none",
                        }}
                        className="focus:border-[rgba(212,175,55,0.5)] focus:bg-[#2A2A2A] focus:ring-4 focus:ring-[rgba(212,175,55,0.08)]"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-gold-muted text-xs">Nom</Label>
                      <input
                        type="text"
                        value={nom}
                        onChange={(e) => {
                          setNom(e.target.value);
                          handleTyping();
                        }}
                        onFocus={() => scenarioChampFocus("prenom")}
                        placeholder="Dupont"
                        required
                        style={{
                          width: "100%",
                          padding: mode === "register" ? "10px 12px" : "14px 16px",
                          background: "#222222",
                          border: "1px solid rgba(212,175,55,0.15)",
                          borderRadius: "12px",
                          color: "#FFFFFF",
                          fontSize: "15px",
                          transition: "all 0.2s",
                          outline: "none",
                        }}
                        className="focus:border-[rgba(212,175,55,0.5)] focus:bg-[#2A2A2A] focus:ring-4 focus:ring-[rgba(212,175,55,0.08)]"
                      />
                    </div>
                  </div>

                  {/* Pseudo field */}
                  <div className="space-y-1.5">
                    <Label className="text-gold-muted text-xs">Pseudo</Label>
                    <input
                      type="text"
                      value={pseudo}
                      onChange={(e) => {
                        setPseudo(e.target.value);
                        handleTyping();
                      }}
                      onFocus={() => scenarioChampFocus("pseudo")}
                      placeholder="jdupont42"
                      required
                      style={{
                        width: "100%",
                        padding: mode === "register" ? "10px 12px" : "14px 16px",
                        background: "#222222",
                        border: "1px solid rgba(212,175,55,0.15)",
                        borderRadius: "12px",
                        color: "#FFFFFF",
                        fontSize: "15px",
                        transition: "all 0.2s",
                        outline: "none",
                      }}
                      className="focus:border-[rgba(212,175,55,0.5)] focus:bg-[#2A2A2A] focus:ring-4 focus:ring-[rgba(212,175,55,0.08)]"
                    />
                  </div>
                </>
              )}

              {/* Email field */}
              <div className="space-y-1.5">
                <Label className="text-gold-muted text-xs">Email</Label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    handleTyping();
                  }}
                  onFocus={() => scenarioChampFocus("email")}
                  placeholder="jean@example.com"
                  required
                  style={{
                    width: "100%",
                    padding: mode === "register" ? "10px 12px" : "14px 16px",
                    background: "#222222",
                    border: "1px solid rgba(212,175,55,0.15)",
                    borderRadius: "12px",
                    color: "#FFFFFF",
                    fontSize: "15px",
                    transition: "all 0.2s",
                    outline: "none",
                  }}
                  className="focus:border-[rgba(212,175,55,0.5)] focus:bg-[#2A2A2A] focus:ring-4 focus:ring-[rgba(212,175,55,0.08)]"
                />
              </div>

              {/* Password field */}
              <div className="space-y-1.5">
                <Label className="text-gold-muted text-xs">Mot de passe</Label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      handleTyping();
                    }}
                    onFocus={() => scenarioChampFocus("password")}
                    placeholder="••••••••"
                    required
                    minLength={6}
                    style={{
                      width: "100%",
                      padding: mode === "register" ? "10px 44px 10px 12px" : "14px 44px 14px 16px",
                      background: "#222222",
                      border: "1px solid rgba(212,175,55,0.15)",
                      borderRadius: "12px",
                      color: "#FFFFFF",
                      fontSize: "15px",
                      transition: "all 0.2s",
                      outline: "none",
                    }}
                    className="focus:border-[rgba(212,175,55,0.5)] focus:bg-[#2A2A2A] focus:ring-4 focus:ring-[rgba(212,175,55,0.08)]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((prev) => !prev)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gold-muted hover:text-[#D4AF37] transition-colors focus:outline-none p-1"
                    style={{ background: "none", border: "none", cursor: "pointer" }}
                    aria-label={showPassword ? "Masquer le mot de passe" : "Afficher le mot de passe"}
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>

              {/* Error messages */}
              {error && (
                <div style={{ color: "#EF4444", background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.2)", borderRadius: "12px", padding: "12px 16px", fontSize: "14px" }}>
                  {error}
                </div>
              )}

              {/* Success messages */}
              {success && (
                <div style={{ color: "#10B981", background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.2)", borderRadius: "12px", padding: "12px 16px", fontSize: "14px" }}>
                  {success}
                </div>
              )}

              {/* Submit Button */}
              <button
                type="submit"
                disabled={loading}
                style={{
                  width: "100%",
                  padding: mode === "register" ? "12px" : "16px",
                  background: "linear-gradient(135deg, #D4AF37, #F0C940)",
                  border: "none",
                  borderRadius: "12px",
                  color: "#0A0A0A",
                  fontSize: "16px",
                  fontWeight: 700,
                  cursor: "pointer",
                  transition: "all 0.2s",
                  boxShadow: "0 4px 20px rgba(212,175,55,0.3)",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = "translateY(-1px)";
                  e.currentTarget.style.boxShadow = "0 8px 30px rgba(212,175,55,0.4)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = "none";
                  e.currentTarget.style.boxShadow = "0 4px 20px rgba(212,175,55,0.3)";
                }}
              >
                {loading
                  ? "Chargement..."
                  : mode === "login"
                  ? "Se connecter"
                  : "Créer mon compte"}
              </button>
            </motion.form>
          </AnimatePresence>

          {/* Social login division */}
          <div style={{ display: "flex", alignItems: "center", margin: "24px 0" }}>
            <div style={{ flex: 1, height: "1px", background: "rgba(212,175,55,0.15)" }} />
            <span style={{ padding: "0 12px", color: "#A0A0A0", fontSize: "12px" }}>ou continuer avec</span>
            <div style={{ flex: 1, height: "1px", background: "rgba(212,175,55,0.15)" }} />
          </div>

          {/* Social login buttons */}
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={handleOAuthGoogle}
              disabled={loading}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: "8px",
                padding: "12px",
                background: "rgba(255,255,255,0.02)",
                border: "1px solid rgba(212,175,55,0.15)",
                borderRadius: "12px",
                color: "#FFFFFF",
                fontSize: "14px",
                fontWeight: 600,
                cursor: "pointer",
                transition: "all 0.2s",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = "rgba(212,175,55,0.05)";
                e.currentTarget.style.borderColor = "rgba(212,175,55,0.3)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = "rgba(255,255,255,0.02)";
                e.currentTarget.style.borderColor = "rgba(212,175,55,0.15)";
              }}
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="currentColor"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z"
                />
                <path
                  fill="currentColor"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="currentColor"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                />
                <path
                  fill="currentColor"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                />
              </svg>
              Google
            </button>
            <button
              type="button"
              onClick={handleOAuthMicrosoft}
              disabled={loading}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: "8px",
                padding: "12px",
                background: "rgba(255,255,255,0.02)",
                border: "1px solid rgba(212,175,55,0.15)",
                borderRadius: "12px",
                color: "#FFFFFF",
                fontSize: "14px",
                fontWeight: 600,
                cursor: "pointer",
                transition: "all 0.2s",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = "rgba(212,175,55,0.05)";
                e.currentTarget.style.borderColor = "rgba(212,175,55,0.3)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = "rgba(255,255,255,0.02)";
                e.currentTarget.style.borderColor = "rgba(212,175,55,0.15)";
              }}
            >
              <svg className="w-4 h-4" viewBox="0 0 21 21">
                <rect fill="#f25022" x="1" y="1" width="9" height="9" />
                <rect fill="#00a4ef" x="1" y="11" width="9" height="9" />
                <rect fill="#7fba00" x="11" y="1" width="9" height="9" />
                <rect fill="#ffb900" x="11" y="11" width="9" height="9" />
              </svg>
              Microsoft
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function RoleCard({
  selected,
  onClick,
  icon,
  label,
  desc,
}: {
  selected: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
  desc: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        flex: 1,
        padding: "8px 4px",
        background: selected ? "rgba(212,175,55,0.1)" : "rgba(255,255,255,0.02)",
        border: selected ? "1px solid #D4AF37" : "1px solid rgba(212,175,55,0.15)",
        borderRadius: "12px",
        cursor: "pointer",
        transition: "all 0.2s",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <div style={{ color: selected ? "#D4AF37" : "#A0A0A0", marginBottom: "2px" }}>
        {icon}
      </div>
      <div style={{ fontSize: "13px", fontWeight: 700, color: selected ? "#D4AF37" : "#FFFFFF" }}>
        {label}
      </div>
      <div style={{ fontSize: "10px", color: "#A0A0A0", marginTop: "1px" }}>
        {desc}
      </div>
    </button>
  );
}
