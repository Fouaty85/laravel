import { Suspense, useState, useEffect, useRef } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { useGLTF, useAnimations, ContactShadows, OrbitControls } from '@react-three/drei'
import * as THREE from 'three'
import { useAuralisStore, useAuralisAvatar, type AuralisGesture, type AuralisExpression } from '@/hooks/useAuralisAvatar'

// ── Constantes ──────────────────────────────────────────────────────────
const AVATAR_URL = 'https://honklrkiszbarbatdusq.supabase.co/storage/v1/object/public/avatars/auralis_final_v2.glb'
const ROOT_ROTATION: [number, number, number] = [-Math.PI / 2, 0, 0]
const ROOT_POSITION: [number, number, number] = [0, -1.55, 0]

// ── Modèle 3D inline (autonome pour le test) ────────────────────────────
function TestAvatarModel({ onLoaded, onError }: { onLoaded: (info: Record<string, unknown>) => void; onError: (err: string) => void }) {
  const group = useRef<THREE.Group>(null)
  const { scene, animations } = useGLTF(AVATAR_URL)
  const { actions, names, mixer } = useAnimations(animations, group)
  const gesture = useAuralisStore(s => s.gesture)
  const expression = useAuralisStore(s => s.expression)
  const isTalking = useAuralisStore(s => s.isTalking)
  const currentRef = useRef<THREE.AnimationAction | null>(null)
  const bonesRef = useRef<Record<string, THREE.Bone>>({})
  const [loaded, setLoaded] = useState(false)
  
  // Collecte os + infos au chargement
  useEffect(() => {
    if (!scene) return
    const bones: Record<string, THREE.Bone> = {}
    scene.traverse((child) => {
      const boneChild = child as THREE.Bone;
      if (boneChild.isBone) bones[boneChild.name] = boneChild
      if (child instanceof THREE.Mesh) { child.castShadow = true; child.receiveShadow = true }
    })
    bonesRef.current = bones
    onLoaded({ animations: names || [], bones: Object.keys(bones), bonesCount: Object.keys(bones).length })
    setLoaded(true)
    console.log('✅ Avatar chargé. Animations:', names)
    console.log('🦴 Os:', Object.keys(bones))
  }, [scene, names, onLoaded])

  // Idle au démarrage
  useEffect(() => {
    if (!loaded || !actions || !names.length) return
    const idleName = names.find(n => n.toLowerCase().includes('idle')) || names[0]
    const idleAction = actions[idleName]
    if (idleAction) {
      idleAction.reset().setLoop(THREE.LoopRepeat, Infinity).setEffectiveTimeScale(0.6).fadeIn(0.5).play()
      currentRef.current = idleAction
    }
  }, [loaded, actions, names])

  // Switch animation selon gesture
  useEffect(() => {
    if (!loaded || !actions || !names.length) return
    const clipName = names.find(n => {
      const nl = n.toLowerCase(), gl = gesture.toLowerCase()
      return nl === gl || nl.includes(gl)
    })
    if (!clipName) { console.warn(`⚠️ Animation "${gesture}" non trouvée dans:`, names); return }
    const next = actions[clipName]
    if (!next || next === currentRef.current) return
    const prev = currentRef.current
    next.reset()
    next.setLoop(gesture === 'idle' ? THREE.LoopRepeat : THREE.LoopOnce, Infinity)
    next.clampWhenFinished = gesture !== 'idle'
    next.setEffectiveTimeScale(0.7)
    if (prev) next.crossFadeFrom(prev, 0.4, true)
    next.fadeIn(0.4).play()
    currentRef.current = next
    // Retour idle après animation one-shot
    if (gesture !== 'idle') {
      const duration = (next.getClip().duration * 1000) / 0.7
      const timer = setTimeout(() => {
        if (currentRef.current === next) {
          const idleName = names.find(n => n.toLowerCase().includes('idle')) || names[0]
          const idleAction = actions[idleName]
          if (idleAction) {
            idleAction.reset().setLoop(THREE.LoopRepeat, Infinity)
              .crossFadeFrom(next, 0.4, true).play()
            currentRef.current = idleAction
            useAuralisStore.getState().setGesture('idle')
          }
        }
      }, duration)
      return () => clearTimeout(timer)
    }
  }, [gesture, actions, names, loaded])

  // useFrame : mixer + lip sync
  useFrame((state, delta) => {
    if (mixer) mixer.update(delta)
    // Lip sync via os tête
    const bones = bonesRef.current
    const jaw = bones['mixamorig7Head'] || bones['mixamorig7Neck'] || bones['Head'] || bones['Jaw']
    if (jaw) {
      if (isTalking) {
        const t = state.clock.elapsedTime
        const open = Math.abs(Math.sin(t * 9)) * 0.07 + Math.abs(Math.sin(t * 14.3)) * 0.04 + Math.abs(Math.sin(t * 5.7)) * 0.02
        jaw.rotation.x = THREE.MathUtils.lerp(jaw.rotation.x, open, delta * 15)
      } else {
        jaw.rotation.x = THREE.MathUtils.lerp(jaw.rotation.x, 0, delta * 8)
      }
    }
  })

  return (
    <group ref={group} rotation={ROOT_ROTATION} position={ROOT_POSITION} scale={1}>
      <primitive object={scene} />
    </group>
  )
}

// ── FPS Counter ──────────────────────────────────────────────────────────
function FPSCounter({ onFPS }: { onFPS: (fps: number) => void }) {
  const frameCount = useRef(0)
  const lastTime = useRef(performance.now())
  useFrame(() => {
    frameCount.current++
    const now = performance.now()
    if (now - lastTime.current >= 1000) {
      onFPS(frameCount.current)
      frameCount.current = 0
      lastTime.current = now
    }
  })
  return null
}

// ── Page principale ──────────────────────────────────────────────────────
const GESTURES: AuralisGesture[] = ['idle','walk','wave','talking','thinking','nod','celebrate','crossArms','headShake','point','sit','smile']
const EXPRESSIONS: AuralisExpression[] = ['neutral','smile_light','smile_medium','smile_big','thinking','concerned','proud']

export default function AvatarTest() {
  const { playGesture, setExpression, speak, gesture, expression, isTalking } = useAuralisAvatar()
  const [avatarInfo, setAvatarInfo] = useState<{ animations: string[]; bones: string[]; bonesCount: number } | null>(null)
  const [loadError, setLoadError] = useState<string | null>(null)
  const [fps, setFps] = useState(0)
  const [testLog, setTestLog] = useState<string[]>(['🚀 Page de test initialisée'])

  const addLog = (msg: string) => setTestLog(prev => [`[${new Date().toLocaleTimeString()}] ${msg}`, ...prev.slice(0, 19)])

  const handleGesture = (g: AuralisGesture) => {
    playGesture(g)
    addLog(`▶ Gesture: ${g}`)
  }

  const handleExpression = (e: AuralisExpression) => {
    setExpression(e)
    addLog(`😊 Expression: ${e}`)
  }

  const handleSpeak = () => {
    speak('Bonjour ! Je suis Auralis, votre assistant pédagogique intelligent. Je suis là pour vous accompagner dans votre apprentissage.', 'talking')
    addLog('🔊 Speech déclenché')
  }

  return (
    <div style={{ display: 'flex', height: '100vh', background: '#0A0A0A', fontFamily: 'Inter, sans-serif' }}>
      
      {/* ─ Canvas 3D ─ */}
      <div style={{ flex: 1, position: 'relative' }}>
        {/* Header */}
        <div style={{ position: 'absolute', top: 16, left: 16, zIndex: 10, color: '#D4AF37', fontSize: 20, fontWeight: 700 }}>
          ✨ AURALIS — Test Avatar
        </div>
        {/* Status badge */}
        <div style={{ position: 'absolute', top: 16, right: 16, zIndex: 10, padding: '6px 14px', borderRadius: 20, background: avatarInfo ? 'rgba(16,185,129,0.2)' : loadError ? 'rgba(239,68,68,0.2)' : 'rgba(212,175,55,0.2)', border: `1px solid ${avatarInfo ? '#10B981' : loadError ? '#EF4444' : '#D4AF37'}`, color: avatarInfo ? '#10B981' : loadError ? '#EF4444' : '#D4AF37', fontSize: 13 }}>
          {avatarInfo ? `✅ Avatar chargé · ${avatarInfo.bonesCount} os · ${avatarInfo.animations.length} animations` : loadError ? `❌ ${loadError}` : '⏳ Chargement...'}
        </div>
        {/* Lip sync indicator */}
        {isTalking && (
          <div style={{ position: 'absolute', bottom: 24, left: '50%', transform: 'translateX(-50%)', zIndex: 10, display: 'flex', gap: 4, alignItems: 'flex-end' }}>
            {[1,2,3,4,5].map(i => (
              <div key={i} style={{ width: 4, background: '#D4AF37', borderRadius: 2, animation: `wave ${0.5 + i * 0.1}s ease-in-out infinite alternate`, height: `${8 + i * 4}px` }} />
            ))}
          </div>
        )}
        <Canvas
          camera={{ position: [0, 0.6, 4.8], fov: 38, near: 0.1, far: 100 }}
          style={{ background: 'transparent' }}
          gl={{ alpha: true, antialias: true }}
          shadows
        >
          <ambientLight intensity={0.6} />
          <directionalLight position={[-2, 3, 4]} intensity={2.5} color="#FFF5E0" castShadow />
          <directionalLight position={[3, 1, 2]} intensity={0.8} color="#C0D0FF" />
          <pointLight position={[0, 2, -3]} intensity={1.5} color="#D4AF37" distance={8} />
          <Suspense fallback={null}>
            <TestAvatarModel
              onLoaded={info => { setAvatarInfo(info); addLog(`✅ GLB chargé: ${info.animations.length} animations, ${info.bonesCount} os`) }}
              onError={err => { setLoadError(err); addLog(`❌ Erreur: ${err}`) }}
            />
          </Suspense>
          <ContactShadows position={[0, -1.55, 0]} opacity={0.4} scale={4} blur={2.5} color="#D4AF37" />
          <OrbitControls enableZoom={false} enablePan={false} target={[0, 0.6, 0]} minPolarAngle={Math.PI / 2.4} maxPolarAngle={Math.PI / 1.9} />
          <FPSCounter onFPS={setFps} />
        </Canvas>
      </div>

      {/* ─ Panel debug ─ */}
      <div style={{ width: 320, background: '#111', borderLeft: '1px solid rgba(212,175,55,0.2)', overflowY: 'auto', padding: 16, display: 'flex', flexDirection: 'column', gap: 16 }}>
        
        {/* Stats */}
        <div style={{ background: '#1A1A1A', border: '1px solid rgba(212,175,55,0.15)', borderRadius: 12, padding: 12 }}>
          <div style={{ color: '#D4AF37', fontSize: 12, fontWeight: 600, marginBottom: 8 }}>📊 ÉTAT EN TEMPS RÉEL</div>
          <div style={{ color: '#A0A0A0', fontSize: 12, lineHeight: 1.8 }}>
            <div>FPS : <span style={{ color: fps >= 50 ? '#10B981' : fps >= 30 ? '#D4AF37' : '#EF4444' }}>{fps}</span></div>
            <div>Gesture : <span style={{ color: '#FFF' }}>{gesture}</span></div>
            <div>Expression : <span style={{ color: '#FFF' }}>{expression}</span></div>
            <div>Speaking : <span style={{ color: isTalking ? '#10B981' : '#A0A0A0' }}>{isTalking ? '🎙️ OUI' : 'NON'}</span></div>
            {avatarInfo && <>
              <div>Animations : <span style={{ color: '#FFF' }}>{avatarInfo.animations.length}</span></div>
              <div>Os : <span style={{ color: '#FFF' }}>{avatarInfo.bonesCount}</span></div>
            </>}
          </div>
        </div>

        {/* Test parole */}
        <div style={{ background: '#1A1A1A', border: '1px solid rgba(212,175,55,0.15)', borderRadius: 12, padding: 12 }}>
          <div style={{ color: '#D4AF37', fontSize: 12, fontWeight: 600, marginBottom: 8 }}>🔊 TEST VOCAL</div>
          <button onClick={handleSpeak} style={{ width: '100%', padding: '10px', background: 'rgba(212,175,55,0.15)', border: '1px solid #D4AF37', borderRadius: 8, color: '#D4AF37', cursor: 'pointer', fontSize: 13, fontWeight: 600 }}>
            {isTalking ? '⏹ En train de parler...' : '▶ Déclencher la voix'}
          </button>
        </div>

        {/* Animations */}
        <div style={{ background: '#1A1A1A', border: '1px solid rgba(212,175,55,0.15)', borderRadius: 12, padding: 12 }}>
          <div style={{ color: '#D4AF37', fontSize: 12, fontWeight: 600, marginBottom: 8 }}>🎭 ANIMATIONS</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
            {GESTURES.map(g => (
              <button key={g} onClick={() => handleGesture(g)} style={{ padding: '8px 4px', background: gesture === g ? 'rgba(212,175,55,0.3)' : 'rgba(255,255,255,0.05)', border: `1px solid ${gesture === g ? '#D4AF37' : 'rgba(255,255,255,0.1)'}`, borderRadius: 6, color: gesture === g ? '#D4AF37' : '#A0A0A0', cursor: 'pointer', fontSize: 11, transition: 'all 0.2s' }}>
                {g}
              </button>
            ))}
          </div>
        </div>

        {/* Expressions */}
        <div style={{ background: '#1A1A1A', border: '1px solid rgba(212,175,55,0.15)', borderRadius: 12, padding: 12 }}>
          <div style={{ color: '#D4AF37', fontSize: 12, fontWeight: 600, marginBottom: 8 }}>😊 EXPRESSIONS</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
            {EXPRESSIONS.map(e => (
              <button key={e} onClick={() => handleExpression(e)} style={{ padding: '7px', background: expression === e ? 'rgba(212,175,55,0.3)' : 'rgba(255,255,255,0.05)', border: `1px solid ${expression === e ? '#D4AF37' : 'rgba(255,255,255,0.1)'}`, borderRadius: 6, color: expression === e ? '#D4AF37' : '#A0A0A0', cursor: 'pointer', fontSize: 11, transition: 'all 0.2s', textAlign: 'left' }}>
                {e}
              </button>
            ))}
          </div>
        </div>

        {/* Animations détectées */}
        {avatarInfo && (
          <div style={{ background: '#1A1A1A', border: '1px solid rgba(212,175,55,0.15)', borderRadius: 12, padding: 12 }}>
            <div style={{ color: '#D4AF37', fontSize: 12, fontWeight: 600, marginBottom: 8 }}>📋 ANIMATIONS DU GLB</div>
            <div style={{ maxHeight: 120, overflowY: 'auto' }}>
              {avatarInfo.animations.map(a => (
                <div key={a} style={{ color: '#A0A0A0', fontSize: 11, padding: '2px 0' }}>• {a}</div>
              ))}
            </div>
          </div>
        )}

        {/* Log */}
        <div style={{ background: '#1A1A1A', border: '1px solid rgba(212,175,55,0.15)', borderRadius: 12, padding: 12 }}>
          <div style={{ color: '#D4AF37', fontSize: 12, fontWeight: 600, marginBottom: 8 }}>📝 LOG</div>
          <div style={{ maxHeight: 150, overflowY: 'auto' }}>
            {testLog.map((l, i) => (
              <div key={i} style={{ color: '#666', fontSize: 10, padding: '1px 0', borderBottom: '1px solid rgba(255,255,255,0.03)' }}>{l}</div>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes wave {
          from { transform: scaleY(1); }
          to { transform: scaleY(2); }
        }
      `}</style>
    </div>
  )
}
