import { Navigate } from "react-router-dom";

// Index now redirects to dashboard (handled by ProtectedRoute)
const Index = () => <Navigate to="/" replace />;

export default Index;
