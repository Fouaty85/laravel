import { useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import {
  BookOpen,
  Users,
  Eye,
  TrendingUp,
  PlusCircle,
  BarChart3,
  Clock,
  CheckCircle2,
  FileText,
  Award,
  Star,
  Brain,
  Sparkles,
  ShieldCheck,
} from "lucide-react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import StatCard from "@/components/dashboard/StatCard";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useAvatarScenario } from "@/hooks/useAvatarScenario";
import {
  calculateLevelFromXP,
  getRoleTitle,
  getXPForLevel,
  calculateComprehensionLevel,
} from "@/lib/gamification";

export default function FormateurDashboard() {
  const { profile, user } = useAuth();
  const navigate = useNavigate();
  const { scenarioDashboardFormateur } = useAvatarScenario();

  // Fetch formateur's courses
  const { data: courses, isLoading: coursesLoading } = useQuery({
    queryKey: ["formateur-courses", user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("courses")
        .select("*")
        .eq("formateur_id", user!.id)
        .order("created_at", { ascending: false });
      return data ?? [];
    },
    enabled: !!user,
  });

  // Fetch enrollments for formateur's courses
  const { data: enrollments } = useQuery({
    queryKey: ["formateur-enrollments", user?.id],
    queryFn: async () => {
      if (!courses || courses.length === 0) return [];
      const courseIds = courses.map((c) => c.id);
      const { data } = await supabase
        .from("enrollments")
        .select("*, courses(titre)")
        .in("course_id", courseIds);
      return data ?? [];
    },
    enabled: !!courses && courses.length > 0,
  });

  // Play Auralis scenario on mount
  useEffect(() => {
    if (profile?.prenom) {
      const alreadyGreeted = localStorage.getItem("auralis_formateur_greeted");
      if (alreadyGreeted === "true") return;

      const t = setTimeout(() => {
        scenarioDashboardFormateur(profile.prenom);
        localStorage.setItem("auralis_formateur_greeted", "true");
      }, 1200);
      return () => clearTimeout(t);
    }
  }, [profile?.prenom, scenarioDashboardFormateur]);

  // Derived stats
  const totalCourses = courses?.length ?? 0;
  const publishedCourses = courses?.filter((c) => c.is_published)?.length ?? 0;
  const draftCourses = totalCourses - publishedCourses;
  const totalEnrollments = enrollments?.length ?? 0;
  const completedEnrollments = enrollments?.filter((e) => e.completed_at)?.length ?? 0;
  const avgProgression =
    enrollments && enrollments.length > 0
      ? Math.round(enrollments.reduce((sum, e) => sum + (e.progression ?? 0), 0) / enrollments.length)
      : 0;

  const points = profile?.points ?? 0;
  const formateurLevelNum = calculateLevelFromXP(points);
  const formateurTitle = getRoleTitle(formateurLevelNum, "formateur");
  const displayNiveauGlobal = profile?.niveau_global || `Niveau ${formateurLevelNum} - ${formateurTitle}`;
  const displayNiveauComprehension = profile?.niveau_comprehension || calculateComprehensionLevel(points, 92);

  const currentLevelXP = getXPForLevel(formateurLevelNum);
  const nextLevelXP = getXPForLevel(formateurLevelNum + 1);
  const levelProgressPercent = Math.min(
    100,
    Math.max(0, Math.round(((points - currentLevelXP) / Math.max(1, nextLevelXP - currentLevelXP)) * 100))
  );

  return (
    <div className="w-full min-h-screen pb-16">
      {/* Top bar (Sticky) */}
      <header className="sticky top-0 z-40 h-16 border-b border-border/50 bg-background/80 backdrop-blur-md flex items-center px-8 justify-between">
        <div>
          <h1 className="text-lg font-semibold text-foreground font-[Space_Grotesk]">
            Espace Formateur
          </h1>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <p className="text-sm font-medium text-foreground">
              {profile?.prenom} {profile?.nom}
            </p>
            <p className="text-[11px] text-[#D4AF37] font-semibold flex items-center justify-end gap-1">
              {formateurLevelNum >= 400 && <ShieldCheck size={12} className="text-amber-400" />}
              {displayNiveauGlobal}
            </p>
          </div>
          <div className="w-9 h-9 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-sm">
            {profile?.prenom?.charAt(0)?.toUpperCase() ?? "F"}
          </div>
        </div>
      </header>

      <div className="p-8 space-y-8 max-w-7xl mx-auto">
        {/* Welcome + CTA */}
        <motion.section
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
        >
          <div>
            <h2 className="text-3xl font-bold text-foreground font-[Space_Grotesk]">
              Bonjour, <span className="text-primary">{profile?.prenom ?? "Formateur"}</span> 👋
            </h2>
            <p className="text-muted-foreground mt-1">
              Gérez vos cours et suivez la progression de vos apprenants.
            </p>
          </div>
          <Button
            className="gold-button h-11 px-6 font-semibold gap-2"
            onClick={() => navigate("/formateur/cours/nouveau")}
          >
            <PlusCircle size={18} />
            Créer un cours
          </Button>
        </motion.section>

        {/* Real-time Level & Certification Banner */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.15 }}
          className="glass-card rounded-2xl p-6 border border-[#D4AF37]/30 bg-gradient-to-r from-[#141414] via-[#1c180e] to-[#141414]"
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 divide-y md:divide-y-0 md:divide-x divide-white/10">
            {/* 1. Niveau Formateur */}
            <div className="flex items-start gap-4 pr-0 md:pr-4 pt-2 md:pt-0">
              <div className="w-12 h-12 rounded-2xl bg-[#D4AF37]/15 border border-[#D4AF37]/30 flex items-center justify-center flex-shrink-0 text-[#D4AF37]">
                <Award size={26} />
              </div>
              <div className="space-y-1.5 flex-1">
                <div className="flex items-center justify-between">
                  <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                    Niveau Formateur (Temps Réel)
                  </p>
                  <span className="text-[10px] bg-[#D4AF37]/20 text-[#D4AF37] px-2 py-0.5 rounded-full font-bold">
                    Niv. {formateurLevelNum} / 500
                  </span>
                </div>
                <p className="text-base font-extrabold text-white font-[Space_Grotesk]">
                  {displayNiveauGlobal}
                </p>
                {/* Progress bar to next level */}
                <div className="space-y-1 pt-1">
                  <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-[#D4AF37] to-[#F0C940] h-full transition-all duration-500 rounded-full"
                      style={{ width: `${levelProgressPercent}%` }}
                    />
                  </div>
                  <p className="text-[10px] text-gray-400 flex items-center justify-between">
                    <span>Vers Niv. {formateurLevelNum + 1}</span>
                    <span className="font-bold text-[#D4AF37]">{levelProgressPercent}%</span>
                  </p>
                </div>
              </div>
            </div>

            {/* 2. Titre du Formateur & Certification Level 400 */}
            <div className="flex items-start gap-4 px-0 md:px-4 pt-4 md:pt-0">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center flex-shrink-0 text-amber-400">
                <ShieldCheck size={26} />
              </div>
              <div className="space-y-1.5 flex-1">
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                  Statut de Certification
                </p>
                <p className="text-base font-extrabold text-amber-300 font-[Space_Grotesk]">
                  {formateurLevelNum >= 400 ? "🏅 Professeur Certifié" : formateurTitle}
                </p>
                <p className="text-[11px] text-gray-400 leading-snug">
                  {formateurLevelNum >= 400
                    ? "Titre Officiel de Professeur Certifié par la Plateforme activé !"
                    : `Atteignez le Niveau 400 pour débloquer le titre officiel de Professeur Certifié (${formateurLevelNum}/400).`}
                </p>
              </div>
            </div>

            {/* 3. Formateur XP & Activité */}
            <div className="flex items-start gap-4 pl-0 md:pl-4 pt-4 md:pt-0">
              <div className="w-12 h-12 rounded-2xl bg-yellow-400/15 border border-yellow-400/30 flex items-center justify-center flex-shrink-0 text-yellow-400">
                <Star size={26} />
              </div>
              <div className="space-y-1.5 flex-1">
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                  XP Formateur Cumulés
                </p>
                <p className="text-2xl font-black text-white font-[Space_Grotesk]">
                  {points} <span className="text-xs text-[#D4AF37] font-semibold">XP</span>
                </p>
                <p className="text-[11px] text-gray-400 flex items-center gap-1">
                  <Sparkles size={12} className="text-[#D4AF37]" />
                  Gagnez des XP en publiant des cours & en animant la communauté !
                </p>
              </div>
            </div>
          </div>
        </motion.section>

        {/* Stats grid */}
        <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            icon={<BookOpen size={20} />}
            label="Cours créés"
            value={totalCourses}
            subtitle={`${publishedCourses} publiés`}
            delay={0}
          />
          <StatCard
            icon={<Users size={20} />}
            label="Apprenants inscrits"
            value={totalEnrollments}
            subtitle={`${completedEnrollments} ont terminé`}
            delay={0.05}
          />
          <StatCard
            icon={<Eye size={20} />}
            label="Cours publiés"
            value={publishedCourses}
            subtitle={`${draftCourses} brouillons`}
            delay={0.1}
          />
          <StatCard
            icon={<TrendingUp size={20} />}
            label="Progression moy."
            value={`${avgProgression}%`}
            subtitle="de vos apprenants"
            delay={0.15}
          />
        </section>

        {/* Courses list */}
        <section>
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-2">
              <BarChart3 size={18} className="text-primary" />
              <h3 className="text-xl font-semibold text-foreground font-[Space_Grotesk]">
                Mes cours
              </h3>
            </div>
            {totalCourses > 0 && (
              <span className="text-xs text-muted-foreground">
                {totalCourses} cours au total
              </span>
            )}
          </div>

          {coursesLoading ? (
            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-5">
              {[1, 2, 3].map((i) => (
                <div key={i} className="glass-card rounded-2xl h-64 animate-pulse" />
              ))}
            </div>
          ) : totalCourses === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="glass-card rounded-2xl p-10 text-center"
            >
              <BookOpen size={44} className="mx-auto text-muted-foreground/40 mb-4" />
              <p className="text-foreground font-medium">Aucun cours créé</p>
              <p className="text-sm text-muted-foreground mt-1 mb-6">
                Commencez à partager vos connaissances en créant votre premier cours.
              </p>
              <Button
                className="gold-button h-10 px-6 font-semibold gap-2"
                onClick={() => navigate("/formateur/cours/nouveau")}
              >
                <PlusCircle size={16} />
                Créer mon premier cours
              </Button>
            </motion.div>
          ) : (
            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-5">
              {courses?.map((course, i) => {
                const courseEnrollments = enrollments?.filter(
                  (e) => e.course_id === course.id
                ) ?? [];
                const enrollmentCount = courseEnrollments.length;
                const courseAvgProgress =
                  enrollmentCount > 0
                    ? Math.round(
                        courseEnrollments.reduce((s, e) => s + (e.progression ?? 0), 0) /
                          enrollmentCount
                      )
                    : 0;

                return (
                  <FormateurCourseCard
                    key={course.id}
                    title={course.titre}
                    description={course.description}
                    imageUrl={course.image_url}
                    niveau={course.niveau}
                    isPublished={course.is_published ?? false}
                    enrollmentCount={enrollmentCount}
                    avgProgression={courseAvgProgress}
                    dureeMinutes={course.duree_minutes}
                    delay={i * 0.05}
                  />
                );
              })}
            </div>
          )}
        </section>

        {/* Quick insights */}
        {totalEnrollments > 0 && (
          <motion.section
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.3 }}
          >
            <div className="flex items-center gap-2 mb-5">
              <BarChart3 size={18} className="text-primary" />
              <h3 className="text-xl font-semibold text-foreground font-[Space_Grotesk]">
                Aperçu rapide
              </h3>
            </div>
            <div className="glass-card rounded-2xl p-6">
              <div className="grid sm:grid-cols-3 gap-6">
                <InsightItem
                  label="Taux de complétion"
                  value={
                    totalEnrollments > 0
                      ? Math.round((completedEnrollments / totalEnrollments) * 100)
                      : 0
                  }
                  unit="%"
                  icon={<CheckCircle2 size={20} />}
                />
                <InsightItem
                  label="Progression moyenne"
                  value={avgProgression}
                  unit="%"
                  icon={<TrendingUp size={20} />}
                />
                <InsightItem
                  label="Cours les plus suivis"
                  value={publishedCourses}
                  unit="publiés"
                  icon={<FileText size={20} />}
                />
              </div>
            </div>
          </motion.section>
        )}
      </div>
    </div>
  );
}

/* ─── Sub-components ─────────────────────────────────────────── */

function FormateurCourseCard({
  title,
  description,
  imageUrl,
  niveau,
  isPublished,
  enrollmentCount,
  avgProgression,
  dureeMinutes,
  delay = 0,
}: {
  title: string;
  description?: string | null;
  imageUrl?: string | null;
  niveau?: string | null;
  isPublished: boolean;
  enrollmentCount: number;
  avgProgression: number;
  dureeMinutes?: number | null;
  delay?: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
      className="glass-card rounded-2xl overflow-hidden group hover:border-primary/25 transition-all cursor-pointer"
    >
      {/* Image */}
      <div className="relative h-36 bg-muted overflow-hidden">
        {imageUrl ? (
          <img
            src={imageUrl}
            alt={title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/5 to-primary/15">
            <BookOpen size={40} className="text-primary/30" />
          </div>
        )}
        {/* Status badge */}
        <div className="absolute top-3 right-3">
          <span
            className={`text-[11px] font-medium px-2.5 py-1 rounded-full backdrop-blur-md ${
              isPublished
                ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                : "bg-amber-500/20 text-amber-400 border border-amber-500/30"
            }`}
          >
            {isPublished ? "Publié" : "Brouillon"}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-3">
        <div>
          <h4 className="font-semibold text-foreground line-clamp-1 text-sm leading-snug">
            {title}
          </h4>
          {description && (
            <p className="text-xs text-muted-foreground line-clamp-2 mt-1">{description}</p>
          )}
        </div>

        {/* Meta */}
        <div className="flex items-center gap-3 text-xs text-muted-foreground">
          {niveau && (
            <span className="px-2 py-0.5 rounded-full bg-primary/10 text-primary text-[11px] font-medium">
              {niveau}
            </span>
          )}
          {dureeMinutes != null && dureeMinutes > 0 && (
            <span className="flex items-center gap-1">
              <Clock size={12} />
              {dureeMinutes}min
            </span>
          )}
          <span className="flex items-center gap-1">
            <Users size={12} />
            {enrollmentCount}
          </span>
        </div>

        {/* Progress bar */}
        {enrollmentCount > 0 && (
          <div className="space-y-1">
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-muted-foreground">Progression moy.</span>
              <span className="text-primary font-medium">{avgProgression}%</span>
            </div>
            <Progress value={avgProgression} className="h-1.5" />
          </div>
        )}
      </div>
    </motion.div>
  );
}

function InsightItem({
  label,
  value,
  unit,
  icon,
}: {
  label: string;
  value: number;
  unit: string;
  icon: React.ReactNode;
}) {
  return (
    <div className="flex items-center gap-4">
      <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary flex-shrink-0">
        {icon}
      </div>
      <div>
        <p className="text-2xl font-bold text-foreground font-[Space_Grotesk]">
          {value}
          <span className="text-sm text-muted-foreground ml-1">{unit}</span>
        </p>
        <p className="text-xs text-muted-foreground">{label}</p>
      </div>
    </div>
  );
}
