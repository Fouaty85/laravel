import { useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { BookOpen, Clock, Trophy, Flame, Star, Sparkles, Brain, Award } from "lucide-react";
import { motion } from "framer-motion";
import StatCard from "@/components/dashboard/StatCard";
import CourseCard from "@/components/dashboard/CourseCard";
import RecommendationCard from "@/components/dashboard/RecommendationCard";
import { useAvatarScenario } from "@/hooks/useAvatarScenario";
import { useUserProfileSync } from "@/hooks/useUserProfileSync";
import { LevelUpCelebration } from "@/components/dashboard/LevelUpCelebration";

interface CourseType {
  titre?: string | null;
  image_url?: string | null;
  niveau?: string | null;
  duree_minutes?: number | null;
  description?: string | null;
}

export default function Dashboard() {
  const { profile, user } = useAuth();
  const { scenarioDashboardApprenant } = useAvatarScenario();

  // Real-time synchronization hook for points, level, streak, study time & level-up events
  const {
    points,
    currentLevel,
    niveauGlobal,
    niveauComprehension,
    streakJours,
    levelProgressPercent,
    completedSectionsCount,
    totalStudyMinutes,
    levelUpData,
    dismissLevelUpModal,
  } = useUserProfileSync();

  const { data: enrollments, refetch: refetchEnrollments } = useQuery({
    queryKey: ["enrollments", user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("enrollments")
        .select("*, courses(*)")
        .eq("user_id", user!.id)
        .order("enrolled_at", { ascending: false });
      return data ?? [];
    },
    enabled: !!user,
    refetchInterval: 5000,
  });

  const { data: recommendations } = useQuery({
    queryKey: ["recommendations", user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("recommendations")
        .select("*, courses(*)")
        .eq("user_id", user!.id)
        .eq("is_dismissed", false)
        .order("score_confiance", { ascending: false })
        .limit(6);
      return data ?? [];
    },
    enabled: !!user,
  });

  // Listen for local profile updates to instantly refresh React Query cache
  useEffect(() => {
    const handleUpdate = () => {
      refetchEnrollments();
    };
    window.addEventListener("profile-updated", handleUpdate);
    return () => window.removeEventListener("profile-updated", handleUpdate);
  }, [refetchEnrollments]);

  const coursesInProgress = enrollments?.filter((e) => !e.completed_at) ?? [];
  const coursesCompleted = enrollments?.filter((e) => e.completed_at).length ?? 0;

  // Play Auralis scenario on mount
  useEffect(() => {
    if (profile?.prenom) {
      const alreadyGreeted = localStorage.getItem("auralis_dashboard_greeted");
      if (alreadyGreeted === "true") return;

      const t = setTimeout(() => {
        scenarioDashboardApprenant(profile.prenom, coursesInProgress.length);
        localStorage.setItem("auralis_dashboard_greeted", "true");
      }, 1200);
      return () => clearTimeout(t);
    }
  }, [profile?.prenom, coursesInProgress.length, scenarioDashboardApprenant]);

  return (
    <div className="w-full min-h-screen pb-16">
      {/* Level-Up Celebration Modal + Confetti */}
      <LevelUpCelebration data={levelUpData} onClose={dismissLevelUpModal} />

      {/* Top bar (Sticky) */}
      <header className="sticky top-0 z-40 h-16 border-b border-border/50 bg-background/80 backdrop-blur-md flex items-center px-8 justify-between">
        <div>
          <h1 className="text-lg font-semibold text-foreground font-[Space_Grotesk]">
            Tableau de bord
          </h1>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <p className="text-sm font-medium text-foreground">
              {profile?.prenom} {profile?.nom}
            </p>
            <p className="text-[11px] text-[#D4AF37] font-semibold">
              {niveauGlobal}
            </p>
          </div>
          <div className="w-9 h-9 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-sm">
            {profile?.prenom?.charAt(0)?.toUpperCase() ?? "A"}
          </div>
        </div>
      </header>

      <div className="p-8 space-y-8 max-w-7xl mx-auto">
        {/* Welcome message & Real-Time Sync Indicator */}
        <motion.section
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <div>
            <h2 className="text-3xl font-bold text-foreground font-[Space_Grotesk]">
              Bonjour, <span className="text-primary">{profile?.prenom ?? "Apprenant"}</span> 👋
            </h2>
            <p className="text-muted-foreground mt-1">
              Continuez votre apprentissage là où vous l'avez laissé.
            </p>
          </div>
        </motion.section>

        {/* Stats Grid */}
        <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            icon={<BookOpen size={20} />}
            label="Cours en cours"
            value={coursesInProgress.length}
            delay={0}
          />
          <StatCard
            icon={<Trophy size={20} />}
            label="Cours terminés"
            value={coursesCompleted}
            delay={0.05}
          />
          <StatCard
            icon={<Clock size={20} />}
            label="Temps d'étude"
            value={totalStudyMinutes > 60 ? `${Math.floor(totalStudyMinutes / 60)}h${totalStudyMinutes % 60}` : `${totalStudyMinutes}min`}
            subtitle={`${completedSectionsCount} sections complétées`}
            delay={0.1}
          />
          <StatCard
            icon={<Flame size={20} />}
            label="Streak"
            value={`${streakJours} jours`}
            subtitle={`${points} points XP`}
            delay={0.15}
          />
        </section>

        {/* Real-time Level & Comprehension Banner */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.2 }}
          className="glass-card rounded-2xl p-6 border border-[#D4AF37]/30 bg-gradient-to-r from-[#141414] via-[#1a1810] to-[#141414] relative overflow-hidden"
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 divide-y md:divide-y-0 md:divide-x divide-white/10">
            {/* 1. Niveau Global */}
            <div className="flex items-start gap-4 pr-0 md:pr-4 pt-2 md:pt-0">
              <div className="w-12 h-12 rounded-2xl bg-[#D4AF37]/15 border border-[#D4AF37]/30 flex items-center justify-center flex-shrink-0 text-[#D4AF37]">
                <Award size={26} />
              </div>
              <div className="space-y-1.5 flex-1">
                <div className="flex items-center justify-between">
                  <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                    Niveau Global
                  </p>
                  <span className="text-[10px] bg-[#D4AF37]/20 text-[#D4AF37] px-2 py-0.5 rounded-full font-bold">
                    Niv. {currentLevel} / 500
                  </span>
                </div>
                <p className="text-base font-extrabold text-white font-[Space_Grotesk]">
                  {niveauGlobal}
                </p>
                {/* Progress bar to next level */}
                <div className="space-y-1 pt-1">
                  <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-[#D4AF37] via-[#F0C940] to-amber-300 h-full transition-all duration-500 rounded-full"
                      style={{ width: `${levelProgressPercent}%` }}
                    />
                  </div>
                  <p className="text-[10px] text-gray-400 flex items-center justify-between">
                    <span>Progression Niveau {currentLevel + 1}</span>
                    <span className="font-bold text-[#D4AF37]">{levelProgressPercent}%</span>
                  </p>
                </div>
              </div>
            </div>

            {/* 2. Niveau de Compréhension */}
            <div className="flex items-start gap-4 px-0 md:px-4 pt-4 md:pt-0">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center flex-shrink-0 text-amber-400">
                <Brain size={26} />
              </div>
              <div className="space-y-1.5 flex-1">
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                  Niveau de Compréhension IA
                </p>
                <p className="text-base font-extrabold text-amber-300 font-[Space_Grotesk]">
                  {niveauComprehension}
                </p>
                <p className="text-[11px] text-gray-400 leading-snug">
                  Évalué en continu selon la précision de vos quiz & votre vitesse d'assimilation.
                </p>
              </div>
            </div>

            {/* 3. XP Totaux & Statut Gamifié */}
            <div className="flex items-start gap-4 pl-0 md:pl-4 pt-4 md:pt-0">
              <div className="w-12 h-12 rounded-2xl bg-yellow-400/15 border border-yellow-400/30 flex items-center justify-center flex-shrink-0 text-yellow-400">
                <Star size={26} />
              </div>
              <div className="space-y-1.5 flex-1">
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                  Points d'Expérience (XP)
                </p>
                <p className="text-2xl font-black text-white font-[Space_Grotesk]">
                  {points} <span className="text-xs text-[#D4AF37] font-semibold">XP</span>
                </p>
                <p className="text-[11px] text-gray-400 flex items-center gap-1">
                  <Sparkles size={12} className="text-[#D4AF37]" />
                  Mises à jour instantanées enregistrées en base.
                </p>
              </div>
            </div>
          </div>
        </motion.section>

        {/* Active courses */}
        <section>
          <div className="flex items-center justify-between mb-5">
            <h3 className="text-xl font-semibold text-foreground font-[Space_Grotesk]">
              Mes cours en cours
            </h3>
            {coursesInProgress.length > 0 && (
              <span className="text-xs text-muted-foreground">
                {coursesInProgress.length} cours
              </span>
            )}
          </div>
          {coursesInProgress.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="glass-card rounded-2xl p-10 text-center"
            >
              <BookOpen size={44} className="mx-auto text-muted-foreground/40 mb-4" />
              <p className="text-foreground font-medium">Aucun cours en cours</p>
              <p className="text-sm text-muted-foreground mt-1">
                Explorez les recommandations ci-dessous pour commencer.
              </p>
            </motion.div>
          ) : (
            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-5">
              {coursesInProgress.map((enrollment, i) => {
                const course = enrollment.courses as unknown as CourseType;
                return (
                  <CourseCard
                    key={enrollment.id}
                    title={course?.titre ?? "Cours"}
                    imageUrl={course?.image_url}
                    niveau={course?.niveau}
                    progression={enrollment.progression ?? 0}
                    adjustedLevel={enrollment.adjusted_level}
                    dureeMinutes={course?.duree_minutes}
                    delay={i * 0.05}
                  />
                );
              })}
            </div>
          )}
        </section>

        {/* Personalized recommendations */}
        <section>
          <div className="flex items-center gap-2 mb-5">
            <Sparkles size={18} className="text-primary" />
            <h3 className="text-xl font-semibold text-foreground font-[Space_Grotesk]">
              Recommandés pour vous
            </h3>
          </div>
          {recommendations?.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="glass-card rounded-2xl p-10 text-center"
            >
              <Sparkles size={44} className="mx-auto text-muted-foreground/40 mb-4" />
              <p className="text-foreground font-medium">Aucune recommandation</p>
              <p className="text-sm text-muted-foreground mt-1">
                Les recommandations apparaîtront au fur et à mesure de votre apprentissage.
              </p>
            </motion.div>
          ) : (
            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-5">
              {recommendations?.map((rec, i) => {
                const course = rec.courses as unknown as CourseType;
                return (
                  <RecommendationCard
                    key={rec.id}
                    title={course?.titre ?? "Cours"}
                    description={course?.description}
                    imageUrl={course?.image_url}
                    niveau={course?.niveau}
                    scoreConfiance={rec.score_confiance}
                    reason={rec.reason}
                    delay={i * 0.05}
                  />
                );
              })}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
