import { Canvas, useThree } from "@react-three/fiber";
import { ContactShadows, OrbitControls } from "@react-three/drei";
import { Suspense, useEffect } from "react";
import { AuralisModel } from "./AuralisModel";
import { type AuralisSize, useAuralisStore } from "@/hooks/useAuralisAvatar";
import * as THREE from "three";

interface Props {
  size?: AuralisSize;
  locked?: boolean;
}

const CAMERA_CONFIG: Record<
  AuralisSize,
  { position: [number, number, number]; fov: number; target: [number, number, number] }
> = {
  large:  { position: [0, 0.05, 4.3], fov: 36, target: [0, -0.18, 0] },
  medium: { position: [0, 0.1, 3.1], fov: 34, target: [0, -0.12, 0] },
  small:  { position: [0, 0.05, 2.5], fov: 32, target: [0, -0.15, 0] },
};

// Store the reset function in a module-level variable (avoids store type issues)
let _cameraResetFn: (() => void) | null = null;

function resetAuralisCamera() {
  _cameraResetFn?.();
}

function CameraResetter({
  config,
}: {
  config: (typeof CAMERA_CONFIG)["large"];
}) {
  const { camera } = useThree();

  useEffect(() => {
    _cameraResetFn = () => {
      camera.position.set(...config.position);
      (camera as THREE.PerspectiveCamera).fov = config.fov;
      (camera as THREE.PerspectiveCamera).updateProjectionMatrix();
    };
    return () => { _cameraResetFn = null; };
  }, [camera, config]);

  return null;
}

export default function AuralisAvatarScene({ size = "large", locked = false }: Props) {
  const cam = CAMERA_CONFIG[size];
  const gesture = useAuralisStore((s) => s.gesture);

  return (
    <div style={{ width: "100%", height: "100%", position: "relative" }}>
      <Canvas
        camera={{ position: cam.position, fov: cam.fov, near: 0.1, far: 100 }}
        style={{ background: "transparent", position: "absolute", inset: 0 }}
        gl={{ alpha: true, antialias: true, powerPreference: "high-performance" }}
        shadows
        dpr={[1, 2]}
      >
        <CameraResetter config={cam} />

        <ambientLight intensity={0.6} />
        <directionalLight
          position={[-2, 3, 4]}
          intensity={2.5}
          color="hsl(40 100% 94%)"
          castShadow
          shadow-mapSize-width={2048}
          shadow-mapSize-height={2048}
        />
        <directionalLight position={[3, 1, 2]} intensity={0.8} color="hsl(224 100% 89%)" />
        <pointLight position={[0, 2, -3]} intensity={1.5} color="hsl(45 65% 52%)" distance={8} />
        <pointLight position={[0, 1.2, -0.5]} intensity={0.3} color="hsl(0 100% 85%)" distance={3} />

        <Suspense fallback={null}>
          <AuralisModel gesture={gesture} />
        </Suspense>

        <ContactShadows
          position={[0, -1.55, 0]}
          opacity={0.4}
          scale={4}
          blur={2.5}
          far={5}
          color="hsl(45 65% 52%)"
        />

        <OrbitControls
          enableZoom={false}
          enablePan={false}
          enableRotate={!locked}
          target={cam.target}
          minPolarAngle={Math.PI / 2.4}
          maxPolarAngle={Math.PI / 1.9}
        />
      </Canvas>
    </div>
  );
}
