import React, { Component, ReactNode } from "react";
import { auralisLogo } from "@/lib/assets";

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

export class AvatarErrorBoundary extends Component<Props, State> {
  public state: State = { hasError: false };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.warn("AvatarErrorBoundary: 3D canvas/texture load error intercepted:", error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      if (this.props.fallback) return this.props.fallback;
      return (
        <div className="w-full h-full flex flex-col items-center justify-center relative overflow-hidden bg-gradient-to-b from-transparent to-black/20 p-4">
          <div className="relative w-20 h-20 rounded-full border border-[#D4AF37]/30 flex items-center justify-center bg-black/60 shadow-[0_0_25px_rgba(212,175,55,0.15)]">
            <img
              src={auralisLogo}
              alt="Auralis Avatar Fallback"
              className="w-16 h-16 object-cover rounded-full"
            />
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
