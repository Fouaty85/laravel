import { useRef, useMemo, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import { useGLTF } from "@react-three/drei";
import * as THREE from "three";
import { useAuralisStore, type RigDebugInfo } from "@/hooks/useAuralisAvatar";
import { type BoneMap, applyBlinking, applyEyeTracking } from "./AuralisAnimations";
import { applyExpression } from "./AuralisExpressions";
import { applyLipSyncFromAmplitude } from "./AuralisLipSync";
import { createAllClips, CLIP_GESTURE_MAP } from "./AuralisClips";

const AVATAR_URL = "https://honklrkiszbarbatdusq.supabase.co/storage/v1/object/public/avatar/auralis_compressed.glb";

const normalizeBoneName = (value: string) => value.toLowerCase().replace(/[^a-z0-9]/g, "");

function findBoneByAliases(skeleton: THREE.Skeleton | null, aliases: string[]): THREE.Bone | null {
  if (!skeleton) return null;
  const normalizedAliases = aliases.map(normalizeBoneName);
  for (const bone of skeleton.bones) {
    const boneName = normalizeBoneName(bone.name);
    if (normalizedAliases.some((alias) => boneName.includes(alias))) {
      return bone;
    }
  }
  return null;
}

export default function AuralisAvatarInner() {
  const { scene } = useGLTF(AVATAR_URL);
  const groupRef = useRef<THREE.Group>(null);
  const mixerRef = useRef<THREE.AnimationMixer | null>(null);
  const currentActionRef = useRef<THREE.AnimationAction | null>(null);
  const clipMapRef = useRef<Map<string, THREE.AnimationClip>>(new Map());

  const gesture = useAuralisStore((s) => s.gesture);
  const expression = useAuralisStore((s) => s.expression);
  const isTalking = useAuralisStore((s) => s.isTalking);

  const clonedScene = useMemo(() => {
    const clone = scene.clone(true);
    clone.traverse((child) => {
      if ((child as THREE.SkinnedMesh).isSkinnedMesh) {
        (child as THREE.SkinnedMesh).frustumCulled = false;
      }
    });
    return clone;
  }, [scene]);

  const { skeleton, morphMeshes, primarySkinnedMesh } = useMemo(() => {
    let skel: THREE.Skeleton | null = null;
    let primary: THREE.SkinnedMesh | null = null;
    const morphs: THREE.SkinnedMesh[] = [];
    clonedScene.traverse((child) => {
      if ((child as THREE.SkinnedMesh).isSkinnedMesh) {
        const mesh = child as THREE.SkinnedMesh;
        if (!primary) primary = mesh;
        if (!skel && mesh.skeleton) skel = mesh.skeleton;
        if (mesh.morphTargetDictionary) morphs.push(mesh);
      }
    });
    return { skeleton: skel, morphMeshes: morphs, primarySkinnedMesh: primary };
  }, [clonedScene]);

  const bones = useMemo<BoneMap | null>(() => {
    if (!skeleton) return null;
    return {
      head: findBoneByAliases(skeleton, ["head"]),
      neck: findBoneByAliases(skeleton, ["neck"]),
      spine: findBoneByAliases(skeleton, ["spine", "spine01", "spine1"]),
      spine1: findBoneByAliases(skeleton, ["spine1", "spine01", "chest", "upperchest"]),
      spine2: findBoneByAliases(skeleton, ["spine2", "spine02", "upperchest", "chest"]),
      hips: findBoneByAliases(skeleton, ["hips", "pelvis", "root"]),
      leftArm: findBoneByAliases(skeleton, ["leftupperarm", "leftarm", "upperarml", "arml"]),
      leftForeArm: findBoneByAliases(skeleton, ["leftlowerarm", "leftforearm", "forearml", "lowerarml"]),
      leftHand: findBoneByAliases(skeleton, ["lefthand", "handl", "leftwrist"]),
      rightArm: findBoneByAliases(skeleton, ["rightupperarm", "rightarm", "upperarmr", "armr"]),
      rightForeArm: findBoneByAliases(skeleton, ["rightlowerarm", "rightforearm", "forearmr", "lowerarmr"]),
      rightHand: findBoneByAliases(skeleton, ["righthand", "handr", "rightwrist"]),
      leftUpLeg: findBoneByAliases(skeleton, ["leftupleg", "leftthigh", "thighl", "uplegl"]),
      leftLeg: findBoneByAliases(skeleton, ["leftleg", "leftcalf", "calfl", "legl"]),
      leftFoot: findBoneByAliases(skeleton, ["leftfoot", "footl"]),
      rightUpLeg: findBoneByAliases(skeleton, ["rightupleg", "rightthigh", "thighr", "uplegr"]),
      rightLeg: findBoneByAliases(skeleton, ["rightleg", "rightcalf", "calfr", "legr"]),
      rightFoot: findBoneByAliases(skeleton, ["rightfoot", "footr"]),
      leftShoulder: findBoneByAliases(skeleton, ["leftshoulder", "shoulderl"]),
      rightShoulder: findBoneByAliases(skeleton, ["rightshoulder", "shoulderr"]),
      leftEye: findBoneByAliases(skeleton, ["lefteye", "eyel"]),
      rightEye: findBoneByAliases(skeleton, ["righteye", "eyer"]),
    };
  }, [skeleton]);

  // Create mixer + clips once bones are ready
  useEffect(() => {
    if (!bones || !clonedScene || !primarySkinnedMesh) return;

    const mixer = new THREE.AnimationMixer(primarySkinnedMesh);
    mixerRef.current = mixer;

    const clips = createAllClips(bones);
    const map = new Map<string, THREE.AnimationClip>();
    for (const clip of clips) {
      map.set(clip.name, clip);
    }
    clipMapRef.current = map;

    const idleClip = map.get("idle");
    if (idleClip) {
      const action = mixer.clipAction(idleClip, primarySkinnedMesh);
      action.setLoop(THREE.LoopRepeat, Infinity);
      action.play();
      currentActionRef.current = action;
    }

    return () => {
      mixer.stopAllAction();
      mixer.uncacheRoot(primarySkinnedMesh);
    };
  }, [bones, clonedScene, primarySkinnedMesh]);

  // Switch animation clip on gesture change
  useEffect(() => {
    const mixer = mixerRef.current;
    if (!mixer || !primarySkinnedMesh) return;

    const clipName = CLIP_GESTURE_MAP[gesture] ?? "idle";
    const clip = clipMapRef.current.get(clipName);
    if (!clip) return;

    const nextAction = mixer.clipAction(clip, primarySkinnedMesh);
    if (currentActionRef.current === nextAction) return;

    const isOneShot = ["nod", "headShake", "wink"].includes(gesture);

    currentActionRef.current?.fadeOut(0.25);

    nextAction
      .reset()
      .setEffectiveWeight(1)
      .setEffectiveTimeScale(gesture === "walk" ? 1.4 : 1)
      .fadeIn(0.25);

    if (isOneShot) {
      nextAction.setLoop(THREE.LoopOnce, 1);
      nextAction.clampWhenFinished = true;
    } else {
      nextAction.setLoop(THREE.LoopRepeat, Infinity);
    }

    nextAction.play();
    currentActionRef.current = nextAction;
  }, [gesture, primarySkinnedMesh]);

  // Emit debug rig info
  useEffect(() => {
    const allBoneNames = skeleton?.bones.map((b) => b.name) ?? [];
    const mappedBones: Record<string, string | null> = {};
    if (bones) {
      for (const [key, bone] of Object.entries(bones)) {
        mappedBones[key] = bone?.name ?? null;
      }
    }
    const morphTargets: string[] = [];
    for (const mesh of morphMeshes) {
      if (mesh.morphTargetDictionary) {
        morphTargets.push(...Object.keys(mesh.morphTargetDictionary));
      }
    }
    const clipNames = Array.from(clipMapRef.current.keys());
    const info: RigDebugInfo = {
      allBoneNames,
      mappedBones,
      animationClips: clipNames,
      morphTargets: [...new Set(morphTargets)],
      skeletonFound: Boolean(skeleton),
    };
    useAuralisStore.getState().setDebugRig(info);
  }, [skeleton, bones, morphMeshes]);

  useFrame((state, delta) => {
    if (!groupRef.current) return;

    // Update the animation mixer — THIS drives the skeleton
    mixerRef.current?.update(delta);

    const t = state.clock.getElapsedTime();

    // Blinking overlay (morph targets, always on unless wink)
    if (gesture !== "wink") {
      applyBlinking(morphMeshes, t);
    }

    // Eye tracking overlay (additive on top of clip)
    if (bones) {
      applyEyeTracking(bones, state.mouse.x, state.mouse.y, 0.15);
    }

    // Expression overlay
    if (expression !== "neutral") {
      applyExpression(morphMeshes, expression, 1.0, 0.12);
    }

    // Lip sync when talking
    if (isTalking) {
      applyLipSyncFromAmplitude(morphMeshes, t);
    }

    // Celebrate smile override
    if (gesture === "celebrate") {
      for (const mesh of morphMeshes) {
        const d = mesh.morphTargetDictionary;
        const i = mesh.morphTargetInfluences;
        if (!d || !i) continue;
        if (d["mouthSmileLeft"] !== undefined) i[d["mouthSmileLeft"]] = 0.7;
        if (d["mouthSmileRight"] !== undefined) i[d["mouthSmileRight"]] = 0.65;
      }
    }

    // Wink morph overlay
    if (gesture === "wink") {
      const wt = state.clock.getElapsedTime() % 2;
      const winkValue = wt < 0.3 ? Math.sin((wt / 0.3) * Math.PI) : 0;
      for (const mesh of morphMeshes) {
        const d = mesh.morphTargetDictionary;
        const i = mesh.morphTargetInfluences;
        if (!d || !i) continue;
        if (d["eyeBlinkLeft"] !== undefined) i[d["eyeBlinkLeft"]] = winkValue;
        if (d["mouthSmileLeft"] !== undefined) i[d["mouthSmileLeft"]] = Math.max(i[d["mouthSmileLeft"]] ?? 0, winkValue * 0.6);
      }
    }
  });

  return (
    <group ref={groupRef} rotation={[-Math.PI / 2, 0, 0]}>
      <primitive object={clonedScene} position={[0, 0, 0]} />
    </group>
  );
}

useGLTF.preload(AVATAR_URL);
