import type * as THREE from "three";

export function applyLipSyncFromAmplitude(
  morphMeshes: THREE.Mesh[],
  t: number,
  lerpSpeed: number = 0.15
) {
  // Simulate speech with multi-frequency noise
  const amplitude =
    Math.sin(t * 12) * 0.3 +
    Math.sin(t * 17.3) * 0.2 +
    Math.sin(t * 23.7) * 0.15 +
    Math.sin(t * 31.1) * 0.1 +
    Math.abs(Math.sin(t * 7.5)) * 0.25;
  const amp = Math.max(0, Math.min(1, amplitude));

  for (const mesh of morphMeshes) {
    const d = mesh.morphTargetDictionary;
    const i = mesh.morphTargetInfluences;
    if (!d || !i) continue;

    if (d["jawOpen"] !== undefined) {
      const target = amp * 0.35;
      i[d["jawOpen"]] += (target - i[d["jawOpen"]]) * lerpSpeed;
    }
    if (d["mouthOpen"] !== undefined) {
      const target = amp * 0.5;
      i[d["mouthOpen"]] += (target - i[d["mouthOpen"]]) * lerpSpeed;
    }
    if (d["mouthFunnel"] !== undefined) {
      const target = Math.max(0, Math.sin(t * 8) * 0.15 * amp);
      i[d["mouthFunnel"]] += (target - i[d["mouthFunnel"]]) * lerpSpeed;
    }
    if (d["mouthStretchLeft"] !== undefined) {
      const target = Math.max(0, Math.cos(t * 10) * 0.12 * amp);
      i[d["mouthStretchLeft"]] += (target - i[d["mouthStretchLeft"]]) * lerpSpeed;
    }
    if (d["mouthStretchRight"] !== undefined) {
      const target = Math.max(0, Math.cos(t * 10 + 0.5) * 0.12 * amp);
      i[d["mouthStretchRight"]] += (target - i[d["mouthStretchRight"]]) * lerpSpeed;
    }
    if (d["mouthPucker"] !== undefined) {
      const target = Math.max(0, Math.sin(t * 6) * 0.1 * amp);
      i[d["mouthPucker"]] += (target - i[d["mouthPucker"]]) * lerpSpeed;
    }
  }
}
