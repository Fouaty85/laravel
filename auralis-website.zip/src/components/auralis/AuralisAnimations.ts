import * as THREE from "three";

export interface BoneMap {
  head: THREE.Bone | null;
  neck: THREE.Bone | null;
  spine: THREE.Bone | null;
  spine1: THREE.Bone | null;
  spine2: THREE.Bone | null;
  hips: THREE.Bone | null;
  leftArm: THREE.Bone | null;
  leftForeArm: THREE.Bone | null;
  leftHand: THREE.Bone | null;
  rightArm: THREE.Bone | null;
  rightForeArm: THREE.Bone | null;
  rightHand: THREE.Bone | null;
  leftUpLeg: THREE.Bone | null;
  leftLeg: THREE.Bone | null;
  leftFoot: THREE.Bone | null;
  rightUpLeg: THREE.Bone | null;
  rightLeg: THREE.Bone | null;
  rightFoot: THREE.Bone | null;
  leftShoulder: THREE.Bone | null;
  rightShoulder: THREE.Bone | null;
  leftEye: THREE.Bone | null;
  rightEye: THREE.Bone | null;
}

type IR = Map<string, THREE.Euler>;

/** Snappy lerp — high alpha for instant Fortnite-style motion */
function lerp(c: number, t: number, a: number): number {
  return c + (t - c) * a;
}

function ir(map: IR, key: string, axis: "x" | "y" | "z"): number {
  return map.get(key)?.[axis] || 0;
}

// ═══════════════════ ALWAYS-ON ═══════════════════

export function applyBreathing(b: BoneMap, m: IR, t: number, _s: number) {
  const s = 0.3;
  const breath = Math.sin(t * 1.2) * 0.5 + 0.5;
  if (b.spine1) {
    b.spine1.rotation.x = lerp(b.spine1.rotation.x, ir(m, "spine1", "x") + breath * 0.04, s);
    b.spine1.scale.y = 1 + breath * 0.015;
    b.spine1.scale.x = 1 + breath * 0.01;
  }
  if (b.spine2) {
    b.spine2.rotation.x = lerp(b.spine2.rotation.x, ir(m, "spine2", "x") + breath * 0.03, s);
  }
}

export function applyBlinking(morphMeshes: THREE.Mesh[], t: number) {
  const period = 3.0 + Math.sin(t * 0.15) * 1.0;
  const cycle = t % period;
  let blink = 0;
  if (cycle < 0.1) {
    blink = Math.sin((cycle / 0.1) * Math.PI);
  } else if (cycle > 0.18 && cycle < 0.28 && Math.sin(t * 2.7) > 0.7) {
    blink = Math.sin(((cycle - 0.18) / 0.1) * Math.PI) * 0.8;
  }
  for (const mesh of morphMeshes) {
    const d = mesh.morphTargetDictionary;
    const i = mesh.morphTargetInfluences;
    if (!d || !i) continue;
    if (d["eyeBlinkLeft"] !== undefined) i[d["eyeBlinkLeft"]] = blink;
    if (d["eyeBlinkRight"] !== undefined) i[d["eyeBlinkRight"]] = blink;
    if (d["mouthSmileLeft"] !== undefined) {
      i[d["mouthSmileLeft"]] = Math.max(i[d["mouthSmileLeft"]], 0.15 + Math.sin(t * 0.7) * 0.08);
    }
    if (d["mouthSmileRight"] !== undefined) {
      i[d["mouthSmileRight"]] = Math.max(i[d["mouthSmileRight"]], 0.15 + Math.sin(t * 0.7 + 0.3) * 0.08);
    }
  }
}

export function applyEyeTracking(b: BoneMap, mx: number, my: number, _s: number) {
  const s = 0.5;
  const tx = mx * 0.5;
  const ty = my * 0.25;
  if (b.leftEye) {
    b.leftEye.rotation.y = lerp(b.leftEye.rotation.y, -tx, s);
    b.leftEye.rotation.x = lerp(b.leftEye.rotation.x, ty, s);
  }
  if (b.rightEye) {
    b.rightEye.rotation.y = lerp(b.rightEye.rotation.y, -tx, s);
    b.rightEye.rotation.x = lerp(b.rightEye.rotation.x, ty, s);
  }
}

// ═══════════════════ GESTURES ═══════════════════
// Fortnite-style: FAST interpolation, BIG amplitudes, SNAPPY transitions

export function applyIdle(b: BoneMap, m: IR, t: number, _s: number, g: THREE.Group) {
  const s = 0.4;
  // Pronounced weight shifting
  const shift = Math.sin(t * 0.8);
  
  if (b.hips) {
    b.hips.rotation.z = lerp(b.hips.rotation.z, shift * 0.06, s);
    b.hips.rotation.y = lerp(b.hips.rotation.y, ir(m, "hips", "y") + Math.sin(t * 0.45) * 0.05, s);
    b.hips.position.x = lerp(b.hips.position.x || 0, shift * 0.02, s);
  }
  // Head — alive, looking around with attitude
  if (b.head) {
    b.head.rotation.y = lerp(b.head.rotation.y, ir(m, "head", "y") + Math.sin(t * 0.5) * 0.15, s);
    b.head.rotation.x = lerp(b.head.rotation.x, ir(m, "head", "x") + Math.sin(t * 0.35 + 1) * 0.08, s);
    b.head.rotation.z = lerp(b.head.rotation.z, ir(m, "head", "z") + Math.sin(t * 0.3 + 2) * 0.06, s);
  }
  if (b.neck) {
    b.neck.rotation.y = lerp(b.neck.rotation.y, ir(m, "neck", "y") + Math.sin(t * 0.7) * 0.06, s);
  }
  // Arms — natural sway with personality
  if (b.leftArm) {
    b.leftArm.rotation.z = lerp(b.leftArm.rotation.z, ir(m, "leftArm", "z") + Math.sin(t * 0.6) * 0.12, s);
    b.leftArm.rotation.x = lerp(b.leftArm.rotation.x, ir(m, "leftArm", "x") + Math.sin(t * 0.5) * 0.08, s);
  }
  if (b.leftForeArm) {
    b.leftForeArm.rotation.z = lerp(b.leftForeArm.rotation.z, ir(m, "leftForeArm", "z") - 0.1 + Math.sin(t * 0.55) * 0.06, s);
  }
  if (b.rightArm) {
    b.rightArm.rotation.z = lerp(b.rightArm.rotation.z, ir(m, "rightArm", "z") - Math.sin(t * 0.6) * 0.12, s);
    b.rightArm.rotation.x = lerp(b.rightArm.rotation.x, ir(m, "rightArm", "x") + Math.sin(t * 0.5 + 1) * 0.08, s);
  }
  if (b.rightForeArm) {
    b.rightForeArm.rotation.z = lerp(b.rightForeArm.rotation.z, ir(m, "rightForeArm", "z") + 0.1 + Math.sin(t * 0.55 + 1) * 0.06, s);
  }
  // Legs — subtle weight shift
  if (b.leftUpLeg) {
    b.leftUpLeg.rotation.x = lerp(b.leftUpLeg.rotation.x, ir(m, "leftUpLeg", "x") + Math.sin(t * 0.4) * 0.04, s);
    b.leftUpLeg.rotation.z = lerp(b.leftUpLeg.rotation.z, ir(m, "leftUpLeg", "z") + shift * 0.02, s);
  }
  if (b.rightUpLeg) {
    b.rightUpLeg.rotation.x = lerp(b.rightUpLeg.rotation.x, ir(m, "rightUpLeg", "x") - Math.sin(t * 0.4) * 0.04, s);
    b.rightUpLeg.rotation.z = lerp(b.rightUpLeg.rotation.z, ir(m, "rightUpLeg", "z") - shift * 0.02, s);
  }
  // Spine alive
  if (b.spine) {
    b.spine.rotation.y = lerp(b.spine.rotation.y, ir(m, "spine", "y") + Math.sin(t * 0.4) * 0.03, s);
  }
  g.rotation.z = lerp(g.rotation.z, 0, s);
  g.position.y = THREE.MathUtils.lerp(g.position.y, 0, s);
}

export function applyWalk(b: BoneMap, m: IR, t: number, _s: number, g: THREE.Group) {
  const s = 0.6; // VERY fast for snappy motion
  const wt = t * 4.0; // Fast walk cycle

  // LEGS — big exaggerated strides like Fortnite lobby
  if (b.leftUpLeg) b.leftUpLeg.rotation.x = lerp(b.leftUpLeg.rotation.x, ir(m, "leftUpLeg", "x") + Math.sin(wt) * 0.7, s);
  if (b.rightUpLeg) b.rightUpLeg.rotation.x = lerp(b.rightUpLeg.rotation.x, ir(m, "rightUpLeg", "x") - Math.sin(wt) * 0.7, s);
  if (b.leftLeg) b.leftLeg.rotation.x = lerp(b.leftLeg.rotation.x, ir(m, "leftLeg", "x") + Math.max(0, Math.sin(wt + 0.5)) * 1.0, s);
  if (b.rightLeg) b.rightLeg.rotation.x = lerp(b.rightLeg.rotation.x, ir(m, "rightLeg", "x") + Math.max(0, -Math.sin(wt + 0.5)) * 1.0, s);
  if (b.leftFoot) b.leftFoot.rotation.x = lerp(b.leftFoot.rotation.x, ir(m, "leftFoot", "x") + Math.sin(wt + 1) * 0.35, s);
  if (b.rightFoot) b.rightFoot.rotation.x = lerp(b.rightFoot.rotation.x, ir(m, "rightFoot", "x") - Math.sin(wt + 1) * 0.35, s);

  // ARMS — huge swing opposite to legs
  if (b.leftArm) {
    b.leftArm.rotation.x = lerp(b.leftArm.rotation.x, ir(m, "leftArm", "x") - Math.sin(wt) * 0.65, s);
  }
  if (b.rightArm) {
    b.rightArm.rotation.x = lerp(b.rightArm.rotation.x, ir(m, "rightArm", "x") + Math.sin(wt) * 0.65, s);
  }
  if (b.leftForeArm) {
    b.leftForeArm.rotation.x = lerp(b.leftForeArm.rotation.x, ir(m, "leftForeArm", "x") - 0.5 - Math.max(0, -Math.sin(wt)) * 0.5, s);
  }
  if (b.rightForeArm) {
    b.rightForeArm.rotation.x = lerp(b.rightForeArm.rotation.x, ir(m, "rightForeArm", "x") - 0.5 - Math.max(0, Math.sin(wt)) * 0.5, s);
  }

  // BIG bounce — feels powerful
  g.position.y = THREE.MathUtils.lerp(g.position.y, Math.abs(Math.sin(wt)) * 0.08, 0.4);

  // Hip rotation & sway — exaggerated
  if (b.hips) {
    b.hips.rotation.y = lerp(b.hips.rotation.y, ir(m, "hips", "y") + Math.sin(wt) * 0.15, s);
    b.hips.rotation.z = lerp(b.hips.rotation.z, Math.sin(wt) * 0.08, s);
  }
  // Lean forward
  if (b.spine) b.spine.rotation.x = lerp(b.spine.rotation.x, ir(m, "spine", "x") + 0.12, s * 0.7);
  // Head bob
  if (b.head) {
    b.head.rotation.x = lerp(b.head.rotation.x, ir(m, "head", "x") + 0.08 + Math.sin(wt * 2) * 0.04, s);
    b.head.rotation.y = lerp(b.head.rotation.y, ir(m, "head", "y") + Math.sin(wt) * 0.06, s);
  }
  // Shoulders alternate
  if (b.leftShoulder) {
    b.leftShoulder.rotation.y = lerp(b.leftShoulder.rotation.y, ir(m, "leftShoulder", "y") + Math.sin(wt) * 0.08, s);
  }
  if (b.rightShoulder) {
    b.rightShoulder.rotation.y = lerp(b.rightShoulder.rotation.y, ir(m, "rightShoulder", "y") - Math.sin(wt) * 0.08, s);
  }
}

export function applyWave(b: BoneMap, m: IR, t: number, _s: number) {
  const s = 0.55;
  // Right arm WAY up high — instant snap
  if (b.rightArm) {
    b.rightArm.rotation.z = lerp(b.rightArm.rotation.z, -2.0, s);
    b.rightArm.rotation.x = lerp(b.rightArm.rotation.x, -0.5, s);
  }
  if (b.rightForeArm) {
    b.rightForeArm.rotation.z = lerp(b.rightForeArm.rotation.z, 0.6 + Math.sin(t * 10) * 0.6, s);
    b.rightForeArm.rotation.y = lerp(b.rightForeArm.rotation.y, Math.sin(t * 10) * 0.4, s);
  }
  if (b.rightHand) {
    b.rightHand.rotation.z = lerp(b.rightHand.rotation.z, Math.sin(t * 12) * 0.5, s);
    b.rightHand.rotation.x = lerp(b.rightHand.rotation.x, Math.sin(t * 8) * 0.3, s);
  }
  // Left arm on hip — confident pose
  if (b.leftArm) {
    b.leftArm.rotation.z = lerp(b.leftArm.rotation.z, 0.7, s);
    b.leftArm.rotation.x = lerp(b.leftArm.rotation.x, -0.15, s);
  }
  if (b.leftForeArm) {
    b.leftForeArm.rotation.z = lerp(b.leftForeArm.rotation.z, -1.3, s);
  }
  // Body lean
  if (b.spine) {
    b.spine.rotation.z = lerp(b.spine.rotation.z, 0.08, s);
    b.spine.rotation.y = lerp(b.spine.rotation.y, ir(m, "spine", "y") + 0.06, s);
  }
  // Head tilts with wave
  if (b.head) {
    b.head.rotation.z = lerp(b.head.rotation.z, -0.12 + Math.sin(t * 5) * 0.05, s);
    b.head.rotation.y = lerp(b.head.rotation.y, ir(m, "head", "y") + 0.15, s);
  }
  // Weight on one leg
  if (b.hips) {
    b.hips.rotation.z = lerp(b.hips.rotation.z, 0.05, s * 0.5);
  }
}

export function applyPoint(b: BoneMap, m: IR, t: number, _s: number) {
  const s = 0.55;
  // Right arm THRUSTS forward — dramatic point
  if (b.rightArm) {
    b.rightArm.rotation.x = lerp(b.rightArm.rotation.x, -1.5, s);
    b.rightArm.rotation.z = lerp(b.rightArm.rotation.z, -0.3, s);
  }
  if (b.rightForeArm) {
    b.rightForeArm.rotation.x = lerp(b.rightForeArm.rotation.x, 0.15, s);
    b.rightForeArm.rotation.z = lerp(b.rightForeArm.rotation.z, 0.05, s);
  }
  if (b.rightHand) {
    b.rightHand.rotation.x = lerp(b.rightHand.rotation.x, 0.1, s);
  }
  // Left arm behind back — cool pose
  if (b.leftArm) {
    b.leftArm.rotation.z = lerp(b.leftArm.rotation.z, 0.5, s);
    b.leftArm.rotation.x = lerp(b.leftArm.rotation.x, 0.3, s);
  }
  if (b.leftForeArm) {
    b.leftForeArm.rotation.x = lerp(b.leftForeArm.rotation.x, -0.8, s);
    b.leftForeArm.rotation.z = lerp(b.leftForeArm.rotation.z, -0.5, s);
  }
  // Lean INTO the point — aggressive
  if (b.spine) {
    b.spine.rotation.x = lerp(b.spine.rotation.x, ir(m, "spine", "x") + 0.18, s);
    b.spine.rotation.y = lerp(b.spine.rotation.y, ir(m, "spine", "y") - 0.08, s);
  }
  // Head follows — eyes locked on target
  if (b.head) {
    b.head.rotation.x = lerp(b.head.rotation.x, ir(m, "head", "x") - 0.1, s);
    b.head.rotation.y = lerp(b.head.rotation.y, ir(m, "head", "y") - 0.15, s);
  }
  // Step forward with right foot
  if (b.rightUpLeg) {
    b.rightUpLeg.rotation.x = lerp(b.rightUpLeg.rotation.x, ir(m, "rightUpLeg", "x") + 0.15, s);
  }
}

export function applyCelebrate(b: BoneMap, m: IR, t: number, _s: number, g: THREE.Group) {
  const s = 0.65; // SUPER snappy
  // MASSIVE bounce — jumping celebration like Fortnite victory royale
  const bounce = Math.pow(Math.abs(Math.sin(t * 6)), 0.7) * 0.2;
  g.position.y = THREE.MathUtils.lerp(g.position.y, bounce, 0.5);

  // Both arms PUMPING sky high
  const armPump = Math.sin(t * 6);
  if (b.leftArm) {
    b.leftArm.rotation.z = lerp(b.leftArm.rotation.z, 2.2 + armPump * 0.3, s);
    b.leftArm.rotation.x = lerp(b.leftArm.rotation.x, -0.4 + Math.sin(t * 8) * 0.2, s);
  }
  if (b.leftForeArm) {
    b.leftForeArm.rotation.z = lerp(b.leftForeArm.rotation.z, -0.6 + Math.sin(t * 9 + 1) * 0.4, s);
  }
  if (b.leftHand) {
    b.leftHand.rotation.z = lerp(b.leftHand.rotation.z, Math.sin(t * 10) * 0.5, s);
  }
  if (b.rightArm) {
    b.rightArm.rotation.z = lerp(b.rightArm.rotation.z, -2.2 - armPump * 0.3, s);
    b.rightArm.rotation.x = lerp(b.rightArm.rotation.x, -0.4 + Math.sin(t * 8 + 0.5) * 0.2, s);
  }
  if (b.rightForeArm) {
    b.rightForeArm.rotation.z = lerp(b.rightForeArm.rotation.z, 0.6 + Math.sin(t * 9 + 2) * 0.4, s);
  }
  if (b.rightHand) {
    b.rightHand.rotation.z = lerp(b.rightHand.rotation.z, Math.sin(t * 10 + 1) * 0.5, s);
  }
  // Knees pumping with jumps
  if (b.leftLeg) b.leftLeg.rotation.x = lerp(b.leftLeg.rotation.x, ir(m, "leftLeg", "x") + bounce * 4, s);
  if (b.rightLeg) b.rightLeg.rotation.x = lerp(b.rightLeg.rotation.x, ir(m, "rightLeg", "x") + bounce * 4, s);
  if (b.leftUpLeg) b.leftUpLeg.rotation.x = lerp(b.leftUpLeg.rotation.x, ir(m, "leftUpLeg", "x") - bounce * 2, s);
  if (b.rightUpLeg) b.rightUpLeg.rotation.x = lerp(b.rightUpLeg.rotation.x, ir(m, "rightUpLeg", "x") - bounce * 2, s);
  // Head crazy happy — bobbing everywhere
  if (b.head) {
    b.head.rotation.z = lerp(b.head.rotation.z, Math.sin(t * 7) * 0.2, s);
    b.head.rotation.y = lerp(b.head.rotation.y, ir(m, "head", "y") + Math.sin(t * 5) * 0.15, s);
    b.head.rotation.x = lerp(b.head.rotation.x, ir(m, "head", "x") - 0.1, s);
  }
  // Body PARTY sway — full torso rotation
  if (b.spine) {
    b.spine.rotation.z = lerp(b.spine.rotation.z, Math.sin(t * 5) * 0.12, s);
    b.spine.rotation.y = lerp(b.spine.rotation.y, ir(m, "spine", "y") + Math.sin(t * 4) * 0.1, s);
  }
  if (b.hips) {
    b.hips.rotation.y = lerp(b.hips.rotation.y, ir(m, "hips", "y") + Math.sin(t * 5) * 0.12, s);
    b.hips.rotation.z = lerp(b.hips.rotation.z, Math.sin(t * 6 + 1) * 0.06, s);
  }
}

export function applyThinking(b: BoneMap, m: IR, t: number, _s: number) {
  const s = 0.5;
  // Right hand on chin — classic thinker
  if (b.rightArm) {
    b.rightArm.rotation.x = lerp(b.rightArm.rotation.x, -1.0, s);
    b.rightArm.rotation.z = lerp(b.rightArm.rotation.z, -0.5, s);
  }
  if (b.rightForeArm) {
    b.rightForeArm.rotation.x = lerp(b.rightForeArm.rotation.x, -1.8, s);
    b.rightForeArm.rotation.z = lerp(b.rightForeArm.rotation.z, 0.2, s);
  }
  if (b.rightHand) {
    b.rightHand.rotation.x = lerp(b.rightHand.rotation.x, 0.3, s);
  }
  // Head tilted, looking up and to the side — dramatic thinking
  if (b.head) {
    b.head.rotation.z = lerp(b.head.rotation.z, 0.22 + Math.sin(t * 0.6) * 0.06, s);
    b.head.rotation.x = lerp(b.head.rotation.x, ir(m, "head", "x") - 0.18, s);
    b.head.rotation.y = lerp(b.head.rotation.y, ir(m, "head", "y") + 0.2 + Math.sin(t * 0.4) * 0.08, s);
  }
  // Left arm across body — crossed low
  if (b.leftArm) {
    b.leftArm.rotation.z = lerp(b.leftArm.rotation.z, 0.6, s);
    b.leftArm.rotation.x = lerp(b.leftArm.rotation.x, -0.3, s);
  }
  if (b.leftForeArm) {
    b.leftForeArm.rotation.z = lerp(b.leftForeArm.rotation.z, -1.0, s);
    b.leftForeArm.rotation.x = lerp(b.leftForeArm.rotation.x, -0.3, s);
  }
  // Weight shift
  if (b.hips) {
    b.hips.rotation.z = lerp(b.hips.rotation.z, 0.04, s * 0.5);
    b.hips.rotation.y = lerp(b.hips.rotation.y, ir(m, "hips", "y") + 0.06, s * 0.5);
  }
  // Slight pace back
  if (b.spine) {
    b.spine.rotation.x = lerp(b.spine.rotation.x, ir(m, "spine", "x") - 0.05, s);
  }
}

export function applyCrossArms(b: BoneMap, m: IR, t: number, _s: number) {
  const s = 0.5;
  // Left arm crosses to right — BIG fold
  if (b.leftArm) {
    b.leftArm.rotation.x = lerp(b.leftArm.rotation.x, -0.7, s);
    b.leftArm.rotation.z = lerp(b.leftArm.rotation.z, 1.2, s);
  }
  if (b.leftForeArm) {
    b.leftForeArm.rotation.x = lerp(b.leftForeArm.rotation.x, -0.5, s);
    b.leftForeArm.rotation.z = lerp(b.leftForeArm.rotation.z, -1.5, s);
  }
  // Right arm crosses to left
  if (b.rightArm) {
    b.rightArm.rotation.x = lerp(b.rightArm.rotation.x, -0.8, s);
    b.rightArm.rotation.z = lerp(b.rightArm.rotation.z, -1.1, s);
  }
  if (b.rightForeArm) {
    b.rightForeArm.rotation.x = lerp(b.rightForeArm.rotation.x, -0.4, s);
    b.rightForeArm.rotation.z = lerp(b.rightForeArm.rotation.z, 1.5, s);
  }
  // Shoulders up — imposing
  if (b.leftShoulder) b.leftShoulder.rotation.z = lerp(b.leftShoulder.rotation.z, ir(m, "leftShoulder", "z") - 0.12, s);
  if (b.rightShoulder) b.rightShoulder.rotation.z = lerp(b.rightShoulder.rotation.z, ir(m, "rightShoulder", "z") + 0.12, s);
  // Head slightly raised, chin up — boss stance
  if (b.head) {
    b.head.rotation.x = lerp(b.head.rotation.x, ir(m, "head", "x") + 0.12, s);
    b.head.rotation.z = lerp(b.head.rotation.z, Math.sin(t * 0.3) * 0.04, s);
    b.head.rotation.y = lerp(b.head.rotation.y, ir(m, "head", "y") + Math.sin(t * 0.25) * 0.06, s);
  }
  // Lean back — confident
  if (b.spine) b.spine.rotation.x = lerp(b.spine.rotation.x, ir(m, "spine", "x") - 0.1, s);
  // Feet wider apart
  if (b.leftUpLeg) b.leftUpLeg.rotation.z = lerp(b.leftUpLeg.rotation.z, ir(m, "leftUpLeg", "z") + 0.08, s * 0.5);
  if (b.rightUpLeg) b.rightUpLeg.rotation.z = lerp(b.rightUpLeg.rotation.z, ir(m, "rightUpLeg", "z") - 0.08, s * 0.5);
}

export function applyNod(b: BoneMap, m: IR, elapsed: number, _s: number) {
  if (!b.head) return;
  const s = 0.7; // INSTANT
  const phase = Math.min(elapsed / 0.8, 1);
  let nod = 0;
  if (phase < 0.15) nod = Math.sin((phase / 0.15) * Math.PI) * -0.4;
  else if (phase < 0.35) nod = Math.sin(((phase - 0.15) / 0.2) * Math.PI) * -0.2;
  else if (phase < 0.55) nod = Math.sin(((phase - 0.35) / 0.2) * Math.PI) * -0.3;
  b.head.rotation.x = lerp(b.head.rotation.x, ir(m, "head", "x") + nod, s);
}

export function applyHeadShake(b: BoneMap, m: IR, elapsed: number, _s: number) {
  if (!b.head) return;
  const s = 0.7;
  const phase = Math.min(elapsed / 0.8, 1);
  const shake = Math.sin(phase * Math.PI * 4) * 0.45 * (1 - phase);
  b.head.rotation.y = lerp(b.head.rotation.y, ir(m, "head", "y") + shake, s);
}

export function applyWink(morphMeshes: THREE.SkinnedMesh[], elapsed: number) {
  const winkValue = elapsed < 0.25 ? Math.sin((elapsed / 0.25) * Math.PI) : 0;
  for (const mesh of morphMeshes) {
    const d = mesh.morphTargetDictionary;
    const i = mesh.morphTargetInfluences;
    if (!d || !i) continue;
    if (d["eyeBlinkLeft"] !== undefined) i[d["eyeBlinkLeft"]] = winkValue;
    if (d["mouthSmileLeft"] !== undefined) i[d["mouthSmileLeft"]] = Math.max(i[d["mouthSmileLeft"]], winkValue * 0.6);
  }
}

export function applySit(b: BoneMap, m: IR, t: number, _s: number, g: THREE.Group) {
  const s = 0.5;
  g.position.y = THREE.MathUtils.lerp(g.position.y, -0.55, s);
  // Deep knee bend
  if (b.leftUpLeg) b.leftUpLeg.rotation.x = lerp(b.leftUpLeg.rotation.x, ir(m, "leftUpLeg", "x") + 1.6, s);
  if (b.rightUpLeg) b.rightUpLeg.rotation.x = lerp(b.rightUpLeg.rotation.x, ir(m, "rightUpLeg", "x") + 1.6, s);
  if (b.leftLeg) b.leftLeg.rotation.x = lerp(b.leftLeg.rotation.x, ir(m, "leftLeg", "x") - 1.4, s);
  if (b.rightLeg) b.rightLeg.rotation.x = lerp(b.rightLeg.rotation.x, ir(m, "rightLeg", "x") - 1.4, s);
  // Lean back relaxed
  if (b.spine) b.spine.rotation.x = lerp(b.spine.rotation.x, ir(m, "spine", "x") - 0.25, s);
  // Hands on knees
  if (b.leftArm) {
    b.leftArm.rotation.x = lerp(b.leftArm.rotation.x, -0.6, s);
    b.leftArm.rotation.z = lerp(b.leftArm.rotation.z, 0.5, s);
  }
  if (b.rightArm) {
    b.rightArm.rotation.x = lerp(b.rightArm.rotation.x, -0.6, s);
    b.rightArm.rotation.z = lerp(b.rightArm.rotation.z, -0.5, s);
  }
  // Head idle looking around
  if (b.head) {
    b.head.rotation.y = lerp(b.head.rotation.y, ir(m, "head", "y") + Math.sin(t * 0.4) * 0.1, s);
    b.head.rotation.x = lerp(b.head.rotation.x, ir(m, "head", "x") + 0.05, s);
  }
}

export function applyTalking(b: BoneMap, m: IR, t: number, _s: number) {
  const s = 0.5;
  // EXPRESSIVE hand gestures — like an Italian presenter
  if (b.rightArm) {
    b.rightArm.rotation.x = lerp(b.rightArm.rotation.x, ir(m, "rightArm", "x") + Math.sin(t * 3) * 0.35 - 0.5, s);
    b.rightArm.rotation.z = lerp(b.rightArm.rotation.z, ir(m, "rightArm", "z") + Math.sin(t * 2.2) * 0.2 - 0.3, s);
  }
  if (b.rightForeArm) {
    b.rightForeArm.rotation.x = lerp(b.rightForeArm.rotation.x, ir(m, "rightForeArm", "x") - 0.8 + Math.sin(t * 3.5) * 0.3, s);
    b.rightForeArm.rotation.z = lerp(b.rightForeArm.rotation.z, Math.sin(t * 2.8) * 0.15, s);
  }
  if (b.rightHand) {
    b.rightHand.rotation.z = lerp(b.rightHand.rotation.z, Math.sin(t * 4) * 0.3, s);
    b.rightHand.rotation.x = lerp(b.rightHand.rotation.x, Math.sin(t * 3.2) * 0.2, s);
  }
  if (b.leftArm) {
    b.leftArm.rotation.x = lerp(b.leftArm.rotation.x, ir(m, "leftArm", "x") + Math.sin(t * 2.5 + 1.5) * 0.3 - 0.4, s);
    b.leftArm.rotation.z = lerp(b.leftArm.rotation.z, ir(m, "leftArm", "z") - Math.sin(t * 2 + 1) * 0.2 + 0.25, s);
  }
  if (b.leftForeArm) {
    b.leftForeArm.rotation.x = lerp(b.leftForeArm.rotation.x, ir(m, "leftForeArm", "x") - 0.7 + Math.sin(t * 3 + 1) * 0.25, s);
    b.leftForeArm.rotation.z = lerp(b.leftForeArm.rotation.z, Math.sin(t * 2.5 + 1) * 0.12, s);
  }
  if (b.leftHand) {
    b.leftHand.rotation.z = lerp(b.leftHand.rotation.z, Math.sin(t * 3.8 + 1) * 0.25, s);
  }
  // Head — animated speaker, LOTS of head movement
  if (b.head) {
    b.head.rotation.x = lerp(b.head.rotation.x, ir(m, "head", "x") + Math.sin(t * 4) * 0.1, s);
    b.head.rotation.y = lerp(b.head.rotation.y, ir(m, "head", "y") + Math.sin(t * 2.2) * 0.15, s);
    b.head.rotation.z = lerp(b.head.rotation.z, ir(m, "head", "z") + Math.sin(t * 3) * 0.06, s);
  }
  // Body swaying with emphasis
  if (b.spine) {
    b.spine.rotation.y = lerp(b.spine.rotation.y, ir(m, "spine", "y") + Math.sin(t * 1.5) * 0.08, s);
    b.spine.rotation.x = lerp(b.spine.rotation.x, ir(m, "spine", "x") + Math.sin(t * 2) * 0.04, s);
  }
  if (b.hips) {
    b.hips.rotation.y = lerp(b.hips.rotation.y, ir(m, "hips", "y") + Math.sin(t * 1.2) * 0.04, s * 0.5);
  }
  // Slight weight shift
  if (b.leftUpLeg) {
    b.leftUpLeg.rotation.x = lerp(b.leftUpLeg.rotation.x, ir(m, "leftUpLeg", "x") + Math.sin(t * 0.8) * 0.04, s * 0.3);
  }
}

// ═══════════════════ DISPATCH ═══════════════════

export type GestureName =
  | "idle" | "walk" | "crossArms" | "wink" | "wave" | "point"
  | "thinking" | "nod" | "headShake" | "celebrate" | "sit" | "talking" | "smile";

export function applyGesture(
  gesture: GestureName,
  b: BoneMap,
  m: IR,
  t: number,
  elapsed: number,
  s: number,
  g: THREE.Group,
  morphMeshes: THREE.SkinnedMesh[]
) {
  switch (gesture) {
    case "idle": return applyIdle(b, m, t, s, g);
    case "walk": return applyWalk(b, m, t, s, g);
    case "wave": return applyWave(b, m, t, s);
    case "point": return applyPoint(b, m, t, s);
    case "celebrate": return applyCelebrate(b, m, t, s, g);
    case "thinking": return applyThinking(b, m, t, s);
    case "crossArms": return applyCrossArms(b, m, t, s);
    case "nod": return applyNod(b, m, elapsed, s);
    case "headShake": return applyHeadShake(b, m, elapsed, s);
    case "wink": { applyWink(morphMeshes, elapsed); return applyIdle(b, m, t, s, g); }
    case "sit": return applySit(b, m, t, s, g);
    case "talking": return applyTalking(b, m, t, s);
    case "smile": return applyIdle(b, m, t, s, g);
  }
}
