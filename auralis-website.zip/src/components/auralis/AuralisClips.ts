import * as THREE from "three";
import type { BoneMap } from "./AuralisAnimations";

/**
 * Procedural AnimationClip factory — creates real Three.js keyframe clips
 * so the mixer drives the skeleton like a proper game engine.
 *
 * Each clip targets bones by their actual name in the GLB skeleton.
 */

type BM = BoneMap;

function rot(boneName: string) {
  // Force binding to skeleton bones (most reliable for SkinnedMesh clips)
  return `.bones[${boneName}].quaternion`;
}

function pos(boneName: string) {
  return `.bones[${boneName}].position`;
}

/** Helper: euler → quaternion values for keyframe track */
function q(x: number, y: number, z: number): number[] {
  const e = new THREE.Euler(x, y, z);
  const quat = new THREE.Quaternion().setFromEuler(e);
  return [quat.x, quat.y, quat.z, quat.w];
}

/** Spread quaternion values for N keyframes */
function qFrames(...frames: number[][]): number[] {
  return frames.flat();
}

function quatTrack(boneName: string, times: number[], frames: number[][]): THREE.QuaternionKeyframeTrack {
  return new THREE.QuaternionKeyframeTrack(
    rot(boneName),
    times,
    qFrames(...frames)
  );
}

function posTrack(boneName: string, times: number[], frames: number[][]): THREE.VectorKeyframeTrack {
  return new THREE.VectorKeyframeTrack(
    pos(boneName),
    times,
    frames.flat()
  );
}

// ═══════════════════ IDLE ═══════════════════
function createIdle(b: BM): THREE.AnimationClip {
  const tracks: THREE.KeyframeTrack[] = [];
  const dur = 4.0;
  const t = [0, 1, 2, 3, 4];

  if (b.spine1) {
    tracks.push(quatTrack(b.spine1.name, t, [
      q(0.02, 0, 0), q(0.04, 0.02, 0.01), q(0.02, 0, 0), q(0.04, -0.02, -0.01), q(0.02, 0, 0),
    ]));
  }
  if (b.head) {
    tracks.push(quatTrack(b.head.name, t, [
      q(0, 0, 0), q(0.03, 0.08, 0.03), q(-0.02, 0, -0.02), q(0.03, -0.08, -0.03), q(0, 0, 0),
    ]));
  }
  if (b.hips) {
    tracks.push(quatTrack(b.hips.name, t, [
      q(0, 0, 0), q(0, 0.03, 0.04), q(0, 0, 0), q(0, -0.03, -0.04), q(0, 0, 0),
    ]));
  }
  if (b.leftArm) {
    tracks.push(quatTrack(b.leftArm.name, t, [
      q(0, 0, 0.08), q(0.04, 0, 0.12), q(0, 0, 0.08), q(-0.04, 0, 0.06), q(0, 0, 0.08),
    ]));
  }
  if (b.rightArm) {
    tracks.push(quatTrack(b.rightArm.name, t, [
      q(0, 0, -0.08), q(-0.04, 0, -0.12), q(0, 0, -0.08), q(0.04, 0, -0.06), q(0, 0, -0.08),
    ]));
  }

  const clip = new THREE.AnimationClip("idle", dur, tracks);
  return clip;
}

// ═══════════════════ WALK ═══════════════════
function createWalk(b: BM): THREE.AnimationClip {
  const tracks: THREE.KeyframeTrack[] = [];
  const dur = 1.0;
  // 2-step cycle: 0, 0.25, 0.5, 0.75, 1.0
  const t = [0, 0.25, 0.5, 0.75, 1.0];
  const amp = 0.6;
  const knee = 0.8;

  if (b.leftUpLeg) {
    tracks.push(quatTrack(b.leftUpLeg.name, t, [
      q(0, 0, 0), q(-amp, 0, 0), q(0, 0, 0), q(amp, 0, 0), q(0, 0, 0),
    ]));
  }
  if (b.rightUpLeg) {
    tracks.push(quatTrack(b.rightUpLeg.name, t, [
      q(0, 0, 0), q(amp, 0, 0), q(0, 0, 0), q(-amp, 0, 0), q(0, 0, 0),
    ]));
  }
  if (b.leftLeg) {
    tracks.push(quatTrack(b.leftLeg.name, t, [
      q(0, 0, 0), q(knee, 0, 0), q(0.1, 0, 0), q(0, 0, 0), q(0, 0, 0),
    ]));
  }
  if (b.rightLeg) {
    tracks.push(quatTrack(b.rightLeg.name, t, [
      q(0.1, 0, 0), q(0, 0, 0), q(0, 0, 0), q(knee, 0, 0), q(0.1, 0, 0),
    ]));
  }
  // Arms swing opposite
  if (b.leftArm) {
    tracks.push(quatTrack(b.leftArm.name, t, [
      q(0, 0, 0), q(0.5, 0, 0.1), q(0, 0, 0), q(-0.5, 0, 0.1), q(0, 0, 0),
    ]));
  }
  if (b.rightArm) {
    tracks.push(quatTrack(b.rightArm.name, t, [
      q(0, 0, 0), q(-0.5, 0, -0.1), q(0, 0, 0), q(0.5, 0, -0.1), q(0, 0, 0),
    ]));
  }
  if (b.leftForeArm) {
    tracks.push(quatTrack(b.leftForeArm.name, t, [
      q(-0.3, 0, 0), q(-0.1, 0, 0), q(-0.3, 0, 0), q(-0.5, 0, 0), q(-0.3, 0, 0),
    ]));
  }
  if (b.rightForeArm) {
    tracks.push(quatTrack(b.rightForeArm.name, t, [
      q(-0.3, 0, 0), q(-0.5, 0, 0), q(-0.3, 0, 0), q(-0.1, 0, 0), q(-0.3, 0, 0),
    ]));
  }
  // Bounce
  if (b.hips) {
    tracks.push(quatTrack(b.hips.name, t, [
      q(0.05, 0, 0), q(0.02, 0.06, 0.03), q(0.05, 0, 0), q(0.02, -0.06, -0.03), q(0.05, 0, 0),
    ]));
    tracks.push(posTrack(b.hips.name, [0, 0.125, 0.25, 0.375, 0.5, 0.625, 0.75, 0.875, 1.0], [
      [0, 0, 0], [0, 0.04, 0], [0, 0, 0], [0, 0.04, 0], [0, 0, 0],
      [0, 0.04, 0], [0, 0, 0], [0, 0.04, 0], [0, 0, 0],
    ]));
  }
  // Head bob
  if (b.head) {
    tracks.push(quatTrack(b.head.name, t, [
      q(0, 0, 0), q(0.04, 0.04, 0), q(0, 0, 0), q(0.04, -0.04, 0), q(0, 0, 0),
    ]));
  }
  // Spine lean forward
  if (b.spine) {
    tracks.push(quatTrack(b.spine.name, t, [
      q(0.08, 0, 0), q(0.08, 0.03, 0), q(0.08, 0, 0), q(0.08, -0.03, 0), q(0.08, 0, 0),
    ]));
  }

  return new THREE.AnimationClip("walk", dur, tracks);
}

// ═══════════════════ WAVE ═══════════════════
function createWave(b: BM): THREE.AnimationClip {
  const tracks: THREE.KeyframeTrack[] = [];
  const dur = 2.0;
  const t = [0, 0.3, 0.5, 0.8, 1.2, 1.5, 1.8, 2.0];

  // Right arm up
  if (b.rightArm) {
    tracks.push(quatTrack(b.rightArm.name, t, [
      q(0, 0, 0), q(-0.3, 0, -1.8), q(-0.3, 0, -2.0), q(-0.3, 0, -1.8), q(-0.3, 0, -2.0),
      q(-0.3, 0, -1.8), q(-0.3, 0, -2.0), q(0, 0, 0),
    ]));
  }
  if (b.rightForeArm) {
    tracks.push(quatTrack(b.rightForeArm.name, t, [
      q(0, 0, 0), q(0, 0, 0.4), q(0, 0.3, 0.8), q(0, -0.3, 0.4), q(0, 0.3, 0.8),
      q(0, -0.3, 0.4), q(0, 0.3, 0.8), q(0, 0, 0),
    ]));
  }
  if (b.rightHand) {
    tracks.push(quatTrack(b.rightHand.name, t, [
      q(0, 0, 0), q(0.2, 0, 0.3), q(-0.2, 0, -0.3), q(0.2, 0, 0.3), q(-0.2, 0, -0.3),
      q(0.2, 0, 0.3), q(-0.2, 0, -0.3), q(0, 0, 0),
    ]));
  }
  // Left arm on hip
  if (b.leftArm) {
    tracks.push(quatTrack(b.leftArm.name, [0, 0.3, 1.8, 2.0], [
      q(0, 0, 0), q(-0.2, 0, 0.7), q(-0.2, 0, 0.7), q(0, 0, 0),
    ]));
  }
  if (b.leftForeArm) {
    tracks.push(quatTrack(b.leftForeArm.name, [0, 0.3, 1.8, 2.0], [
      q(0, 0, 0), q(-0.3, 0, -1.2), q(-0.3, 0, -1.2), q(0, 0, 0),
    ]));
  }
  // Head tilts toward wave
  if (b.head) {
    tracks.push(quatTrack(b.head.name, t, [
      q(0, 0, 0), q(0, 0.1, -0.1), q(0, 0.15, -0.08), q(0, 0.1, -0.12), q(0, 0.15, -0.08),
      q(0, 0.1, -0.12), q(0, 0.15, -0.08), q(0, 0, 0),
    ]));
  }
  // Body lean
  if (b.spine) {
    tracks.push(quatTrack(b.spine.name, [0, 0.3, 1.8, 2.0], [
      q(0, 0, 0), q(0, 0.05, 0.06), q(0, 0.05, 0.06), q(0, 0, 0),
    ]));
  }

  return new THREE.AnimationClip("wave", dur, tracks);
}

// ═══════════════════ CELEBRATE ═══════════════════
function createCelebrate(b: BM): THREE.AnimationClip {
  const tracks: THREE.KeyframeTrack[] = [];
  const dur = 2.0;
  const t = [0, 0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0];

  // Both arms pumping
  if (b.leftArm) {
    tracks.push(quatTrack(b.leftArm.name, t, [
      q(0, 0, 1.5), q(-0.3, 0, 2.2), q(0, 0, 1.5), q(-0.3, 0, 2.2), q(0, 0, 1.5),
      q(-0.3, 0, 2.2), q(0, 0, 1.5), q(-0.3, 0, 2.2), q(0, 0, 1.5),
    ]));
  }
  if (b.rightArm) {
    tracks.push(quatTrack(b.rightArm.name, t, [
      q(0, 0, -1.5), q(-0.3, 0, -2.2), q(0, 0, -1.5), q(-0.3, 0, -2.2), q(0, 0, -1.5),
      q(-0.3, 0, -2.2), q(0, 0, -1.5), q(-0.3, 0, -2.2), q(0, 0, -1.5),
    ]));
  }
  if (b.leftForeArm) {
    tracks.push(quatTrack(b.leftForeArm.name, t, [
      q(0, 0, -0.4), q(0, 0, -0.8), q(0, 0, -0.4), q(0, 0, -0.8), q(0, 0, -0.4),
      q(0, 0, -0.8), q(0, 0, -0.4), q(0, 0, -0.8), q(0, 0, -0.4),
    ]));
  }
  if (b.rightForeArm) {
    tracks.push(quatTrack(b.rightForeArm.name, t, [
      q(0, 0, 0.4), q(0, 0, 0.8), q(0, 0, 0.4), q(0, 0, 0.8), q(0, 0, 0.4),
      q(0, 0, 0.8), q(0, 0, 0.4), q(0, 0, 0.8), q(0, 0, 0.4),
    ]));
  }
  // Jumping bounce on hips
  if (b.hips) {
    tracks.push(posTrack(b.hips.name, t, [
      [0, 0, 0], [0, 0.15, 0], [0, 0, 0], [0, 0.15, 0], [0, 0, 0],
      [0, 0.15, 0], [0, 0, 0], [0, 0.15, 0], [0, 0, 0],
    ]));
    tracks.push(quatTrack(b.hips.name, t, [
      q(0, 0, 0), q(0, 0.1, 0.05), q(0, 0, 0), q(0, -0.1, -0.05), q(0, 0, 0),
      q(0, 0.1, 0.05), q(0, 0, 0), q(0, -0.1, -0.05), q(0, 0, 0),
    ]));
  }
  // Knees pump
  if (b.leftLeg) {
    tracks.push(quatTrack(b.leftLeg.name, t, [
      q(0, 0, 0), q(0.6, 0, 0), q(0, 0, 0), q(0.6, 0, 0), q(0, 0, 0),
      q(0.6, 0, 0), q(0, 0, 0), q(0.6, 0, 0), q(0, 0, 0),
    ]));
  }
  if (b.rightLeg) {
    tracks.push(quatTrack(b.rightLeg.name, t, [
      q(0, 0, 0), q(0.6, 0, 0), q(0, 0, 0), q(0.6, 0, 0), q(0, 0, 0),
      q(0.6, 0, 0), q(0, 0, 0), q(0.6, 0, 0), q(0, 0, 0),
    ]));
  }
  // Head party
  if (b.head) {
    tracks.push(quatTrack(b.head.name, t, [
      q(0, 0, 0), q(-0.1, 0.15, 0.1), q(0, 0, 0), q(-0.1, -0.15, -0.1), q(0, 0, 0),
      q(-0.1, 0.15, 0.1), q(0, 0, 0), q(-0.1, -0.15, -0.1), q(0, 0, 0),
    ]));
  }
  // Spine sway
  if (b.spine) {
    tracks.push(quatTrack(b.spine.name, t, [
      q(0, 0, 0), q(0, 0.08, 0.1), q(0, 0, 0), q(0, -0.08, -0.1), q(0, 0, 0),
      q(0, 0.08, 0.1), q(0, 0, 0), q(0, -0.08, -0.1), q(0, 0, 0),
    ]));
  }

  return new THREE.AnimationClip("celebrate", dur, tracks);
}

// ═══════════════════ THINKING ═══════════════════
function createThinking(b: BM): THREE.AnimationClip {
  const tracks: THREE.KeyframeTrack[] = [];
  const dur = 3.0;
  const t = [0, 0.5, 1.5, 2.5, 3.0];

  // Right hand to chin
  if (b.rightArm) {
    tracks.push(quatTrack(b.rightArm.name, t, [
      q(0, 0, 0), q(-0.9, 0, -0.5), q(-0.9, 0, -0.5), q(-0.9, 0, -0.5), q(0, 0, 0),
    ]));
  }
  if (b.rightForeArm) {
    tracks.push(quatTrack(b.rightForeArm.name, t, [
      q(0, 0, 0), q(-1.6, 0, 0.2), q(-1.6, 0, 0.2), q(-1.6, 0, 0.2), q(0, 0, 0),
    ]));
  }
  // Left arm across body
  if (b.leftArm) {
    tracks.push(quatTrack(b.leftArm.name, t, [
      q(0, 0, 0), q(-0.3, 0, 0.6), q(-0.3, 0, 0.6), q(-0.3, 0, 0.6), q(0, 0, 0),
    ]));
  }
  if (b.leftForeArm) {
    tracks.push(quatTrack(b.leftForeArm.name, t, [
      q(0, 0, 0), q(-0.3, 0, -1.0), q(-0.3, 0, -1.0), q(-0.3, 0, -1.0), q(0, 0, 0),
    ]));
  }
  // Head tilted, looking up
  if (b.head) {
    tracks.push(quatTrack(b.head.name, t, [
      q(0, 0, 0), q(-0.15, 0.2, 0.15), q(-0.12, 0.25, 0.18), q(-0.18, 0.15, 0.12), q(0, 0, 0),
    ]));
  }
  // Weight shift
  if (b.hips) {
    tracks.push(quatTrack(b.hips.name, t, [
      q(0, 0, 0), q(0, 0.04, 0.03), q(0, 0.04, 0.03), q(0, 0.04, 0.03), q(0, 0, 0),
    ]));
  }

  return new THREE.AnimationClip("thinking", dur, tracks);
}

// ═══════════════════ TALKING ═══════════════════
function createTalking(b: BM): THREE.AnimationClip {
  const tracks: THREE.KeyframeTrack[] = [];
  const dur = 2.5;
  const t = [0, 0.3, 0.6, 0.9, 1.2, 1.5, 1.8, 2.1, 2.5];

  // Right arm gesticulating
  if (b.rightArm) {
    tracks.push(quatTrack(b.rightArm.name, t, [
      q(-0.3, 0, -0.2), q(-0.6, 0, -0.4), q(-0.3, 0, -0.2), q(-0.5, 0.1, -0.3), q(-0.3, 0, -0.2),
      q(-0.7, 0, -0.5), q(-0.3, 0, -0.2), q(-0.5, -0.1, -0.3), q(-0.3, 0, -0.2),
    ]));
  }
  if (b.rightForeArm) {
    tracks.push(quatTrack(b.rightForeArm.name, t, [
      q(-0.5, 0, 0), q(-0.8, 0, 0.1), q(-0.5, 0, 0), q(-0.9, 0, -0.1), q(-0.5, 0, 0),
      q(-0.7, 0, 0.15), q(-0.5, 0, 0), q(-1.0, 0, 0), q(-0.5, 0, 0),
    ]));
  }
  // Left arm gesticulating (offset phase)
  if (b.leftArm) {
    tracks.push(quatTrack(b.leftArm.name, t, [
      q(-0.3, 0, 0.2), q(-0.5, -0.1, 0.3), q(-0.3, 0, 0.2), q(-0.6, 0, 0.4), q(-0.3, 0, 0.2),
      q(-0.5, 0.1, 0.3), q(-0.3, 0, 0.2), q(-0.7, 0, 0.5), q(-0.3, 0, 0.2),
    ]));
  }
  if (b.leftForeArm) {
    tracks.push(quatTrack(b.leftForeArm.name, t, [
      q(-0.5, 0, 0), q(-0.9, 0, 0), q(-0.5, 0, 0), q(-0.7, 0, -0.1), q(-0.5, 0, 0),
      q(-1.0, 0, 0.1), q(-0.5, 0, 0), q(-0.8, 0, 0), q(-0.5, 0, 0),
    ]));
  }
  // Head nods and turns while speaking
  if (b.head) {
    tracks.push(quatTrack(b.head.name, t, [
      q(0, 0, 0), q(0.06, 0.1, 0.03), q(-0.04, 0, 0), q(0.06, -0.08, -0.03), q(0, 0.05, 0),
      q(-0.05, -0.1, 0), q(0.06, 0, 0.04), q(-0.03, 0.08, 0), q(0, 0, 0),
    ]));
  }
  // Spine sway
  if (b.spine) {
    tracks.push(quatTrack(b.spine.name, t, [
      q(0, 0, 0), q(0, 0.04, 0), q(0, 0, 0), q(0, -0.04, 0), q(0, 0, 0),
      q(0, 0.05, 0), q(0, 0, 0), q(0, -0.05, 0), q(0, 0, 0),
    ]));
  }

  return new THREE.AnimationClip("talking", dur, tracks);
}

// ═══════════════════ POINT ═══════════════════
function createPoint(b: BM): THREE.AnimationClip {
  const tracks: THREE.KeyframeTrack[] = [];
  const dur = 2.0;
  const t = [0, 0.4, 1.6, 2.0];

  if (b.rightArm) {
    tracks.push(quatTrack(b.rightArm.name, t, [
      q(0, 0, 0), q(-1.4, 0, -0.3), q(-1.4, 0, -0.3), q(0, 0, 0),
    ]));
  }
  if (b.rightForeArm) {
    tracks.push(quatTrack(b.rightForeArm.name, t, [
      q(0, 0, 0), q(0.1, 0, 0), q(0.1, 0, 0), q(0, 0, 0),
    ]));
  }
  // Left arm behind
  if (b.leftArm) {
    tracks.push(quatTrack(b.leftArm.name, t, [
      q(0, 0, 0), q(0.3, 0, 0.5), q(0.3, 0, 0.5), q(0, 0, 0),
    ]));
  }
  if (b.leftForeArm) {
    tracks.push(quatTrack(b.leftForeArm.name, t, [
      q(0, 0, 0), q(-0.8, 0, -0.5), q(-0.8, 0, -0.5), q(0, 0, 0),
    ]));
  }
  // Lean into point
  if (b.spine) {
    tracks.push(quatTrack(b.spine.name, t, [
      q(0, 0, 0), q(0.15, -0.06, 0), q(0.15, -0.06, 0), q(0, 0, 0),
    ]));
  }
  if (b.head) {
    tracks.push(quatTrack(b.head.name, t, [
      q(0, 0, 0), q(-0.08, -0.12, 0), q(-0.08, -0.12, 0), q(0, 0, 0),
    ]));
  }
  // Step forward
  if (b.rightUpLeg) {
    tracks.push(quatTrack(b.rightUpLeg.name, t, [
      q(0, 0, 0), q(0.15, 0, 0), q(0.15, 0, 0), q(0, 0, 0),
    ]));
  }

  return new THREE.AnimationClip("point", dur, tracks);
}

// ═══════════════════ CROSS ARMS ═══════════════════
function createCrossArms(b: BM): THREE.AnimationClip {
  const tracks: THREE.KeyframeTrack[] = [];
  const dur = 3.0;
  const t = [0, 0.5, 2.5, 3.0];

  if (b.leftArm) {
    tracks.push(quatTrack(b.leftArm.name, t, [
      q(0, 0, 0), q(-0.7, 0, 1.2), q(-0.7, 0, 1.2), q(0, 0, 0),
    ]));
  }
  if (b.leftForeArm) {
    tracks.push(quatTrack(b.leftForeArm.name, t, [
      q(0, 0, 0), q(-0.5, 0, -1.5), q(-0.5, 0, -1.5), q(0, 0, 0),
    ]));
  }
  if (b.rightArm) {
    tracks.push(quatTrack(b.rightArm.name, t, [
      q(0, 0, 0), q(-0.8, 0, -1.1), q(-0.8, 0, -1.1), q(0, 0, 0),
    ]));
  }
  if (b.rightForeArm) {
    tracks.push(quatTrack(b.rightForeArm.name, t, [
      q(0, 0, 0), q(-0.4, 0, 1.5), q(-0.4, 0, 1.5), q(0, 0, 0),
    ]));
  }
  // Chin up, confident
  if (b.head) {
    tracks.push(quatTrack(b.head.name, t, [
      q(0, 0, 0), q(0.1, 0, 0), q(0.1, 0, 0), q(0, 0, 0),
    ]));
  }
  // Lean back
  if (b.spine) {
    tracks.push(quatTrack(b.spine.name, t, [
      q(0, 0, 0), q(-0.08, 0, 0), q(-0.08, 0, 0), q(0, 0, 0),
    ]));
  }
  // Wider stance
  if (b.leftUpLeg) {
    tracks.push(quatTrack(b.leftUpLeg.name, t, [
      q(0, 0, 0), q(0, 0, 0.08), q(0, 0, 0.08), q(0, 0, 0),
    ]));
  }
  if (b.rightUpLeg) {
    tracks.push(quatTrack(b.rightUpLeg.name, t, [
      q(0, 0, 0), q(0, 0, -0.08), q(0, 0, -0.08), q(0, 0, 0),
    ]));
  }

  return new THREE.AnimationClip("crossArms", dur, tracks);
}

// ═══════════════════ NOD ═══════════════════
function createNod(b: BM): THREE.AnimationClip {
  const tracks: THREE.KeyframeTrack[] = [];
  const dur = 1.0;
  const t = [0, 0.15, 0.35, 0.55, 0.75, 1.0];

  if (b.head) {
    tracks.push(quatTrack(b.head.name, t, [
      q(0, 0, 0), q(-0.25, 0, 0), q(0.05, 0, 0), q(-0.2, 0, 0), q(0.03, 0, 0), q(0, 0, 0),
    ]));
  }
  if (b.neck) {
    tracks.push(quatTrack(b.neck.name, t, [
      q(0, 0, 0), q(-0.1, 0, 0), q(0, 0, 0), q(-0.08, 0, 0), q(0, 0, 0), q(0, 0, 0),
    ]));
  }

  return new THREE.AnimationClip("nod", dur, tracks);
}

// ═══════════════════ HEAD SHAKE ═══════════════════
function createHeadShake(b: BM): THREE.AnimationClip {
  const tracks: THREE.KeyframeTrack[] = [];
  const dur = 1.0;
  const t = [0, 0.12, 0.25, 0.37, 0.5, 0.62, 0.75, 1.0];

  if (b.head) {
    tracks.push(quatTrack(b.head.name, t, [
      q(0, 0, 0), q(0, 0.3, 0), q(0, -0.3, 0), q(0, 0.25, 0), q(0, -0.25, 0),
      q(0, 0.15, 0), q(0, -0.1, 0), q(0, 0, 0),
    ]));
  }

  return new THREE.AnimationClip("headShake", dur, tracks);
}

// ═══════════════════ SIT ═══════════════════
function createSit(b: BM): THREE.AnimationClip {
  const tracks: THREE.KeyframeTrack[] = [];
  const dur = 3.0;
  const t = [0, 0.6, 2.4, 3.0];

  if (b.hips) {
    tracks.push(posTrack(b.hips.name, t, [
      [0, 0, 0], [0, -0.45, 0], [0, -0.45, 0], [0, 0, 0],
    ]));
  }
  if (b.leftUpLeg) {
    tracks.push(quatTrack(b.leftUpLeg.name, t, [
      q(0, 0, 0), q(1.5, 0, 0), q(1.5, 0, 0), q(0, 0, 0),
    ]));
  }
  if (b.rightUpLeg) {
    tracks.push(quatTrack(b.rightUpLeg.name, t, [
      q(0, 0, 0), q(1.5, 0, 0), q(1.5, 0, 0), q(0, 0, 0),
    ]));
  }
  if (b.leftLeg) {
    tracks.push(quatTrack(b.leftLeg.name, t, [
      q(0, 0, 0), q(-1.4, 0, 0), q(-1.4, 0, 0), q(0, 0, 0),
    ]));
  }
  if (b.rightLeg) {
    tracks.push(quatTrack(b.rightLeg.name, t, [
      q(0, 0, 0), q(-1.4, 0, 0), q(-1.4, 0, 0), q(0, 0, 0),
    ]));
  }
  // Lean back
  if (b.spine) {
    tracks.push(quatTrack(b.spine.name, t, [
      q(0, 0, 0), q(-0.2, 0, 0), q(-0.2, 0, 0), q(0, 0, 0),
    ]));
  }
  // Hands on knees
  if (b.leftArm) {
    tracks.push(quatTrack(b.leftArm.name, t, [
      q(0, 0, 0), q(-0.5, 0, 0.5), q(-0.5, 0, 0.5), q(0, 0, 0),
    ]));
  }
  if (b.rightArm) {
    tracks.push(quatTrack(b.rightArm.name, t, [
      q(0, 0, 0), q(-0.5, 0, -0.5), q(-0.5, 0, -0.5), q(0, 0, 0),
    ]));
  }
  // Head looking around
  if (b.head) {
    tracks.push(quatTrack(b.head.name, [0, 0.6, 1.5, 2.4, 3.0], [
      q(0, 0, 0), q(0.05, 0, 0), q(0.05, 0.1, 0), q(0.05, -0.1, 0), q(0, 0, 0),
    ]));
  }

  return new THREE.AnimationClip("sit", dur, tracks);
}

// ═══════════════════ SMILE (idle variant) ═══════════════════
function createSmile(b: BM): THREE.AnimationClip {
  // Reuse idle with a slight different head tilt
  const tracks: THREE.KeyframeTrack[] = [];
  const dur = 3.0;
  const t = [0, 0.75, 1.5, 2.25, 3.0];

  if (b.head) {
    tracks.push(quatTrack(b.head.name, t, [
      q(0, 0, 0), q(0.05, 0.06, 0.04), q(-0.03, 0, -0.03), q(0.05, -0.06, -0.04), q(0, 0, 0),
    ]));
  }
  if (b.spine1) {
    tracks.push(quatTrack(b.spine1.name, t, [
      q(0.02, 0, 0), q(0.04, 0.02, 0.01), q(0.02, 0, 0), q(0.04, -0.02, -0.01), q(0.02, 0, 0),
    ]));
  }
  if (b.leftArm) {
    tracks.push(quatTrack(b.leftArm.name, t, [
      q(0, 0, 0.05), q(0.03, 0, 0.08), q(0, 0, 0.05), q(-0.03, 0, 0.03), q(0, 0, 0.05),
    ]));
  }
  if (b.rightArm) {
    tracks.push(quatTrack(b.rightArm.name, t, [
      q(0, 0, -0.05), q(-0.03, 0, -0.08), q(0, 0, -0.05), q(0.03, 0, -0.03), q(0, 0, -0.05),
    ]));
  }

  return new THREE.AnimationClip("smile", dur, tracks);
}

// ═══════════════════ WINK (just idle, wink is morph-based) ═══════════════════
function createWink(b: BM): THREE.AnimationClip {
  return createSmile(b); // body stays in smile pose, wink is morph overlay
}

// ═══════════════════ PUBLIC API ═══════════════════

export function createAllClips(bones: BoneMap): THREE.AnimationClip[] {
  return [
    createIdle(bones),
    createWalk(bones),
    createWave(bones),
    createCelebrate(bones),
    createThinking(bones),
    createTalking(bones),
    createPoint(bones),
    createCrossArms(bones),
    createNod(bones),
    createHeadShake(bones),
    createSit(bones),
    createSmile(bones),
    createWink(bones),
  ];
}

export const CLIP_GESTURE_MAP: Record<string, string> = {
  idle: "idle",
  walk: "walk",
  wave: "wave",
  celebrate: "celebrate",
  thinking: "thinking",
  talking: "talking",
  point: "point",
  crossArms: "crossArms",
  nod: "nod",
  headShake: "headShake",
  sit: "sit",
  smile: "smile",
  wink: "smile",
};
