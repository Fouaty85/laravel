import type * as THREE from "three";

export type ExpressionName =
  | "neutral" | "smile_light" | "smile_medium" | "smile_big"
  | "thinking" | "surprised" | "concerned" | "proud";

type MorphMap = Record<string, number>;

const EXPRESSIONS: Record<ExpressionName, MorphMap> = {
  neutral: {},
  smile_light: {
    mouthSmileLeft: 0.4,
    mouthSmileRight: 0.35,
  },
  smile_medium: {
    mouthSmileLeft: 0.7,
    mouthSmileRight: 0.65,
    cheekSquintLeft: 0.3,
    cheekSquintRight: 0.25,
  },
  smile_big: {
    mouthSmileLeft: 1.0,
    mouthSmileRight: 0.95,
    mouthOpen: 0.2,
    jawOpen: 0.15,
    eyeSquintLeft: 0.4,
    eyeSquintRight: 0.35,
    cheekSquintLeft: 0.5,
    cheekSquintRight: 0.45,
  },
  thinking: {
    browDownLeft: 0.3,
    browDownRight: 0.25,
    mouthPucker: 0.15,
    mouthLeft: 0.1,
  },
  surprised: {
    browInnerUp: 0.8,
    browOuterUpLeft: 0.5,
    browOuterUpRight: 0.5,
    eyeWideLeft: 0.6,
    eyeWideRight: 0.6,
    mouthOpen: 0.4,
    jawOpen: 0.3,
  },
  concerned: {
    browInnerUp: 0.4,
    browDownLeft: 0.2,
    mouthFrownLeft: 0.3,
    mouthFrownRight: 0.25,
    mouthPressLeft: 0.2,
    mouthPressRight: 0.2,
  },
  proud: {
    mouthSmileLeft: 0.5,
    mouthSmileRight: 0.45,
    browInnerUp: 0.2,
    noseSneerLeft: 0.1,
    cheekSquintLeft: 0.2,
    cheekSquintRight: 0.2,
  },
};

// Collect ALL morph target names used across all expressions (for resetting)
const ALL_EXPRESSION_MORPHS = new Set<string>();
for (const morphMap of Object.values(EXPRESSIONS)) {
  for (const key of Object.keys(morphMap)) {
    ALL_EXPRESSION_MORPHS.add(key);
  }
}

export function applyExpression(
  morphMeshes: THREE.Mesh[],
  expression: ExpressionName,
  intensity: number = 1.0,
  lerpSpeed: number = 0.08
) {
  const targets = EXPRESSIONS[expression];
  for (const mesh of morphMeshes) {
    const dict = mesh.morphTargetDictionary;
    const inf = mesh.morphTargetInfluences;
    if (!dict || !inf) continue;

    // For every morph used by ANY expression, lerp toward target (or 0 if not in current)
    for (const morphName of ALL_EXPRESSION_MORPHS) {
      if (dict[morphName] === undefined) continue;
      const idx = dict[morphName];
      const targetValue = (targets[morphName] ?? 0) * intensity;
      inf[idx] += (targetValue - inf[idx]) * lerpSpeed;
    }
  }
}
