import { useAnimations, useGLTF } from "@react-three/drei";
import { useEffect, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useAuralisStore, type AuralisExpression } from "@/hooks/useAuralisAvatar";

// Suppress unhandled GLTF texture blob load errors
if (typeof window !== "undefined") {
  THREE.DefaultLoadingManager.onError = (url) => {
    console.warn("THREE.GLTFLoader texture/asset load warning handled:", url);
  };
}

const AVATAR_URL =
  "https://honklrkiszbarbatdusq.supabase.co/storage/v1/object/public/avatars/auralis_final_v2.glb";

const ROOT_ROTATION: [number, number, number] = [-Math.PI / 2, 0, 0];
const ROOT_POSITION: [number, number, number] = [0, -1.55, 0];
const ROOT_SCALE = 1;

const GESTURE_MAP: Record<string, string[]> = {
  idle: ["idle", "Idle", "IDLE", "Breathing Idle", "Standing Idle"],
  walk: ["walk", "Walk", "Walking", "WALK"],
  wave: ["wave", "Wave", "Waving", "WAVE", "Happy Hand Wave"],
  point: ["point", "Point", "Pointing", "POINT"],
  thinking: ["thinking", "Thinking", "THINKING", "Think"],
  crossArms: ["crossArms", "CrossArms", "Arms Crossed", "Crossed Arms"],
  nod: ["nod", "Nod", "Nodding", "Head Nod", "NOD"],
  headShake: ["headShake", "HeadShake", "Head Shake", "Shake Head"],
  wink: ["wink", "Wink", "WINK"],
  celebrate: ["celebrate", "Celebrate", "Celebration", "Victory", "Happy"],
  sit: ["sit", "Sit", "Sitting", "SIT", "Seated"],
  talking: ["talking", "Talking", "Talk", "TALKING", "Speaking"],
  smile: ["smile", "Smile", "SMILE", "Smiling"],
};

const ANIMATION_SPEED: Record<string, number> = {
  idle: 0.6, walk: 0.75, wave: 0.7, point: 0.7, thinking: 0.55,
  crossArms: 0.65, nod: 0.6, headShake: 0.6, wink: 0.5,
  celebrate: 0.65, sit: 0.6, talking: 0.7, smile: 0.6,
};
const DEFAULT_SPEED = 0.65;

function findClipName(gesture: string, availableNames: string[]): string | null {
  const possibilities = GESTURE_MAP[gesture] || [gesture];
  for (const name of possibilities) {
    if (availableNames.includes(name)) return name;
  }
  const lowerGesture = gesture.toLowerCase();
  for (const name of availableNames) {
    if (name.toLowerCase().includes(lowerGesture)) return name;
  }
  return null;
}

export function isGestureAvailable(gesture: string, availableClips: string[]): boolean {
  return findClipName(gesture, availableClips) !== null;
}

// ══════════════ Bone-based expressions ══════════════
// Since this model has NO morph targets, we simulate expressions via bone rotations

interface FaceBones {
  head: THREE.Bone | null;
  jaw: THREE.Bone | null;
  leftEye: THREE.Bone | null;
  rightEye: THREE.Bone | null;
  neck: THREE.Bone | null;
  spine: THREE.Bone | null;
}

function findBone(root: THREE.Object3D, ...aliases: string[]): THREE.Bone | null {
  let found: THREE.Bone | null = null;
  root.traverse((child) => {
    if (found) return;
    if ((child as THREE.Bone).isBone) {
      const name = child.name.toLowerCase();
      if (aliases.some((a) => name.includes(a.toLowerCase()))) {
        found = child as THREE.Bone;
      }
    }
  });
  return found;
}

// Expression bone targets: { boneName: { axis: targetOffset } }
interface BoneExpressionTarget {
  head?: { x?: number; y?: number; z?: number };
  jaw?: { x?: number; y?: number; z?: number };
  neck?: { x?: number; y?: number; z?: number };
  spine?: { x?: number; y?: number; z?: number };
}

const BONE_EXPRESSIONS: Record<AuralisExpression, BoneExpressionTarget> = {
  neutral: {},
  smile_light: {
    head: { x: -0.12, z: 0.05 },
    neck: { x: -0.08 },
  },
  smile_medium: {
    head: { x: -0.20, z: 0.10 },
    neck: { x: -0.10 },
    jaw: { x: 0.06 },
  },
  smile_big: {
    head: { x: -0.30, z: 0.15 },
    neck: { x: -0.15 },
    jaw: { x: 0.14 },
    spine: { x: -0.08 },
  },
  thinking: {
    head: { x: -0.22, y: 0.35, z: 0.25 },
    neck: { y: 0.18 },
  },
  surprised: {
    head: { x: -0.35 },
    jaw: { x: 0.25 },
    neck: { x: -0.12 },
    spine: { x: -0.10 },
  },
  concerned: {
    head: { x: 0.15, z: -0.12 },
    neck: { x: 0.10 },
    jaw: { x: 0.05 },
  },
  proud: {
    head: { x: -0.25 },
    neck: { x: -0.15 },
    spine: { x: -0.12, y: 0.08 },
  },
};

function lerp(current: number, target: number, speed: number): number {
  return current + (target - current) * speed;
}

function applyBoneExpression(
  bones: FaceBones,
  expression: AuralisExpression,
  lerpSpeed: number,
  baseRotations: Map<string, THREE.Euler>
) {
  const targets = BONE_EXPRESSIONS[expression];
  
  const boneMap: { key: keyof FaceBones; target: BoneExpressionTarget[keyof BoneExpressionTarget] }[] = [
    { key: "head", target: targets.head },
    { key: "jaw", target: targets.jaw },
    { key: "neck", target: targets.neck },
    { key: "spine", target: targets.spine },
  ];

  for (const { key, target } of boneMap) {
    const bone = bones[key];
    if (!bone) continue;
    
    const base = baseRotations.get(key) || new THREE.Euler(0, 0, 0);
    const tx = (target?.x ?? 0) + base.x;
    const ty = (target?.y ?? 0) + base.y;
    const tz = (target?.z ?? 0) + base.z;

    bone.rotation.x = lerp(bone.rotation.x, tx, lerpSpeed);
    bone.rotation.y = lerp(bone.rotation.y, ty, lerpSpeed);
    bone.rotation.z = lerp(bone.rotation.z, tz, lerpSpeed);
  }
}

function applyBoneLipSync(bones: FaceBones, t: number, lerpSpeed: number) {
  if (!bones.jaw && !bones.head) return;
  
  // Multi-frequency jaw movement simulating speech
  const amplitude =
    Math.sin(t * 12) * 0.3 +
    Math.sin(t * 17.3) * 0.2 +
    Math.sin(t * 23.7) * 0.15 +
    Math.abs(Math.sin(t * 7.5)) * 0.25;
  const amp = Math.max(0, Math.min(1, amplitude));

  if (bones.jaw) {
    const jawTarget = amp * 0.15;  // Jaw rotation for mouth opening
    bones.jaw.rotation.x = lerp(bones.jaw.rotation.x, jawTarget, lerpSpeed);
  }
  
  // Subtle head movement while talking
  if (bones.head) {
    const headBob = Math.sin(t * 3.5) * 0.02 * amp;
    const headSway = Math.sin(t * 2.1) * 0.015 * amp;
    bones.head.rotation.x = lerp(bones.head.rotation.x, bones.head.rotation.x + headBob, lerpSpeed * 0.5);
    bones.head.rotation.y = lerp(bones.head.rotation.y, bones.head.rotation.y + headSway, lerpSpeed * 0.5);
  }
}

// ══════════════ Component ══════════════

const LOOPING_GESTURES = ["idle", "talking", "thinking", "walk", "sit"];

export function AuralisModel({ gesture = "idle" }: { gesture?: string }) {
  const group = useRef<THREE.Group>(null);
  const setAvailableClips = useAuralisStore((s) => s.setAvailableClips);
  const expression = useAuralisStore((s) => s.expression);
  const isTalking = useAuralisStore((s) => s.isTalking);

  const { scene, animations } = useGLTF(AVATAR_URL);
  const { actions, names, mixer } = useAnimations(animations, group);
  const currentActionRef = useRef<THREE.AnimationAction | null>(null);
  const faceBonesRef = useRef<FaceBones>({
    head: null, jaw: null, leftEye: null, rightEye: null, neck: null, spine: null
  });
  const baseRotationsRef = useRef<Map<string, THREE.Euler>>(new Map());

  // Find face bones after scene mounts
  useEffect(() => {
    if (!group.current) return;
    
    const root = group.current;
    const bones: FaceBones = {
      head: findBone(root, "head"),
      jaw: findBone(root, "jaw", "mandible"),
      leftEye: findBone(root, "lefteye", "eyel", "eye_l", "eye.l"),
      rightEye: findBone(root, "righteye", "eyer", "eye_r", "eye.r"),
      neck: findBone(root, "neck"),
      spine: findBone(root, "spine1", "spine01", "chest"),
    };
    
    faceBonesRef.current = bones;

    // Store base rotations for additive expression overlay
    const baseMap = new Map<string, THREE.Euler>();
    for (const [key, bone] of Object.entries(bones)) {
      if (bone) {
        baseMap.set(key, bone.rotation.clone());
      }
    }
    baseRotationsRef.current = baseMap;

    // Log found bones
    const foundBones = Object.entries(bones)
      .filter(([, b]) => b !== null)
      .map(([k, b]) => `${k}=${b!.name}`);
    console.log("🦴 Face bones trouvés:", foundBones.join(", ") || "aucun");

    // Also log all bones for debugging
    const allBones: string[] = [];
    root.traverse((child) => {
      if ((child as THREE.Bone).isBone) allBones.push(child.name);
    });
    console.log("🦴 Tous les os:", allBones.join(", "));
  }, [scene]);

  // Fix meshes on load + store available clips
  useEffect(() => {
    if (!scene) return;
    scene.rotation.set(0, 0, 0);
    scene.position.set(0, 0, 0);
    scene.scale.setScalar(1);
    scene.traverse((child) => {
      if (child instanceof THREE.Mesh) {
        child.castShadow = true;
        child.receiveShadow = true;
      }
    });
    setAvailableClips(names);
    console.log("🎬 Animations disponibles:", names.join(", "));
  }, [scene, names, animations, setAvailableClips]);

  // Start idle at mount
  useEffect(() => {
    if (!actions || names.length === 0) return;
    const idleClipName = findClipName("idle", names);
    const idleAction = idleClipName ? actions[idleClipName] : actions[names[0]];
    if (idleAction) {
      idleAction.reset();
      idleAction.setLoop(THREE.LoopRepeat, Infinity);
      idleAction.setEffectiveTimeScale(ANIMATION_SPEED["idle"] ?? DEFAULT_SPEED);
      idleAction.fadeIn(0.4);
      idleAction.play();
      currentActionRef.current = idleAction;
    }
  }, [actions, names]);

  // Automatically return to idle/talking when a one-shot animation finishes
  useEffect(() => {
    if (!mixer) return;
    const handleFinished = (e: THREE.Event) => {
      const finishedClipName = (e.action as THREE.AnimationAction).getClip().name;
      const currentClipName = currentActionRef.current?.getClip().name;
      if (finishedClipName === currentClipName) {
        const store = useAuralisStore.getState();
        // If the finished gesture is a one-shot, reset to talking (if speaking) or idle
        if (!LOOPING_GESTURES.includes(store.gesture)) {
          if (store.isTalking) {
            store.setGesture("talking");
          } else {
            store.setGesture("idle");
          }
        }
      }
    };
    mixer.addEventListener("finished", handleFinished);
    return () => {
      mixer.removeEventListener("finished", handleFinished);
    };
  }, [mixer]);

  // Switch animation based on gesture
  useEffect(() => {
    if (!actions || !gesture || names.length === 0) return;
    const clipName = findClipName(gesture, names);
    if (!clipName) return;

    const nextAction = actions[clipName];
    if (!nextAction) return;

    const prevAction = currentActionRef.current;
    if (prevAction === nextAction) return;

    const speed = ANIMATION_SPEED[gesture] ?? DEFAULT_SPEED;
    nextAction.reset();
    
    const isLooping = LOOPING_GESTURES.includes(gesture);
    nextAction.setLoop(isLooping ? THREE.LoopRepeat : THREE.LoopOnce, isLooping ? Infinity : 1);
    nextAction.clampWhenFinished = !isLooping;
    nextAction.setEffectiveTimeScale(speed);

    if (prevAction && prevAction !== nextAction) {
      nextAction.crossFadeFrom(prevAction, 0.4, true);
    }
    nextAction.fadeIn(0.4);
    nextAction.play();
    currentActionRef.current = nextAction;
    console.log(`🎭 Animation "${gesture}" → clip "${clipName}"`);
  }, [gesture, actions, names]);

  // Update mixer + bone-based expressions + lip sync each frame
  useFrame((state, delta) => {
    if (mixer) mixer.update(delta);

    const bones = faceBonesRef.current;
    const baseRots = baseRotationsRef.current;

    // Bone-based expression overlay (additive on top of animation)
    applyBoneExpression(bones, expression, 0.08, baseRots);

    // Bone-based lip sync when talking
    if (isTalking) {
      applyBoneLipSync(bones, state.clock.getElapsedTime(), 0.15);
    }
  });

  return (
    <group ref={group} rotation={ROOT_ROTATION} position={ROOT_POSITION} scale={ROOT_SCALE}>
      <primitive object={scene} />
    </group>
  );
}

useGLTF.preload(AVATAR_URL);
