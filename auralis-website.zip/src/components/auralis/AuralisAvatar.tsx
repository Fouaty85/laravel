import { Suspense, useEffect } from "react";
import AuralisAvatarScene from "./AuralisAvatarScene";
import { AvatarErrorBoundary } from "./AvatarErrorBoundary";
import { useAuralisStore } from "@/hooks/useAuralisAvatar";
import type { AuralisSize } from "@/hooks/useAuralisAvatar";

interface Props {
  size?: AuralisSize;
  className?: string;
  locked?: boolean;
}

import { auralisLogo } from "@/lib/assets";

function GoldenFallback() {
  return (
    <div className="w-full h-full flex flex-col items-center justify-center relative overflow-hidden bg-gradient-to-b from-transparent to-black/10">
      {/* Golden pulsing glow */}
      <div className="absolute w-24 h-24 rounded-full bg-[#D4AF37]/5 blur-xl animate-pulse" />
      {/* Logo container */}
      <div className="relative w-16 h-16 rounded-full border border-[#D4AF37]/20 flex items-center justify-center bg-black/40 shadow-[0_0_20px_rgba(212,175,55,0.05)]">
        <img
          src={auralisLogo}
          alt="Loading..."
          className="w-12 h-12 object-cover rounded-full opacity-75 animate-[pulse_2s_infinite]"
        />
        {/* Subtle circular spinner around the logo */}
        <div className="absolute inset-0 rounded-full border border-transparent border-t-[#D4AF37]/60 border-r-[#D4AF37]/20 animate-spin" />
      </div>
    </div>
  );
}

export default function AuralisAvatar({ size = "large", className = "", locked = false }: Props) {
  const incrementMounted = useAuralisStore((s) => s.incrementMounted);
  const decrementMounted = useAuralisStore((s) => s.decrementMounted);

  useEffect(() => {
    incrementMounted();
    return () => {
      decrementMounted();
      if (typeof window !== "undefined" && window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
    };
  }, [incrementMounted, decrementMounted]);

  return (
    <div className={`relative ${className}`}>
      <AvatarErrorBoundary fallback={<GoldenFallback />}>
        <Suspense fallback={<GoldenFallback />}>
          <AuralisAvatarScene size={size} locked={locked} />
        </Suspense>
      </AvatarErrorBoundary>
    </div>
  );
}
