import { useEffect } from "react";
import confetti from "canvas-confetti";
import { motion, AnimatePresence } from "framer-motion";
import { Trophy, Sparkles, Award, ArrowUpRight, Zap } from "lucide-react";
import type { LevelUpEventData } from "@/hooks/useUserProfileSync";

interface Props {
  data: LevelUpEventData | null;
  onClose: () => void;
}

export function LevelUpCelebration({ data, onClose }: Props) {
  useEffect(() => {
    if (data) {
      // 1. Initial Confetti Burst
      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.5 },
        colors: ["#D4AF37", "#F0C940", "#FFFFFF", "#10B981", "#3B82F6"],
      });

      // 2. Follow-up Side Bursts
      const timer = setTimeout(() => {
        confetti({
          particleCount: 60,
          angle: 60,
          spread: 55,
          origin: { x: 0 },
          colors: ["#D4AF37", "#FFD700", "#10B981"],
        });
        confetti({
          particleCount: 60,
          angle: 120,
          spread: 55,
          origin: { x: 1 },
          colors: ["#D4AF37", "#FFD700", "#3B82F6"],
        });
      }, 400);

      return () => clearTimeout(timer);
    }
  }, [data]);

  if (!data) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.8, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.8, y: 20 }}
          transition={{ type: "spring", damping: 22, stiffness: 300 }}
          className="relative w-full max-w-lg bg-gradient-to-b from-[#1c1810] via-[#14120c] to-[#0d0c08] border-2 border-[#D4AF37] rounded-3xl p-8 text-center shadow-[0_0_80px_rgba(212,175,55,0.3)] overflow-hidden"
        >
          {/* Ambient Glow */}
          <div className="absolute -top-24 -left-24 w-64 h-64 bg-[#D4AF37]/20 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -right-24 w-64 h-64 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />

          {/* Badge icon */}
          <div className="relative mx-auto mb-6 w-24 h-24 rounded-3xl bg-gradient-to-tr from-[#D4AF37] via-[#F0C940] to-amber-200 p-0.5 shadow-[0_0_30px_rgba(212,175,55,0.5)]">
            <div className="w-full h-full bg-[#14120c] rounded-[22px] flex items-center justify-center relative">
              <Trophy size={48} className="text-[#D4AF37] animate-bounce" />
              <div className="absolute -top-2 -right-2 bg-emerald-500 text-black p-1.5 rounded-full border border-black shadow-lg">
                <Zap size={16} className="fill-black" />
              </div>
            </div>
          </div>

          {/* Title */}
          <div className="space-y-2 mb-6">
            <span className="inline-flex items-center gap-1.5 text-xs font-extrabold uppercase tracking-widest text-[#D4AF37] bg-[#D4AF37]/15 px-3 py-1 rounded-full border border-[#D4AF37]/30">
              <Sparkles size={14} /> Celebration Auralis • Montée de Niveau
            </span>
            <h2 className="text-3xl font-black text-white font-[Space_Grotesk]">
              Félicitations !
            </h2>
            <p className="text-sm text-amber-200/80 font-medium">
              {data.actionName}
            </p>
          </div>

          {/* Level Numbers Comparison */}
          <div className="my-6 p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-around">
            <div className="text-center">
              <p className="text-[10px] text-gray-400 font-semibold uppercase">Ancien Niveau</p>
              <p className="text-2xl font-bold text-gray-400">Niv. {data.oldLevel}</p>
            </div>
            <ArrowUpRight size={28} className="text-[#D4AF37]" />
            <div className="text-center">
              <p className="text-[10px] text-[#D4AF37] font-bold uppercase">Nouveau Niveau</p>
              <p className="text-3xl font-extrabold text-[#D4AF37] font-[Space_Grotesk]">
                Niv. {data.newLevel}
              </p>
            </div>
          </div>

          {/* New Title Badge */}
          <div className="p-4 rounded-2xl bg-[#D4AF37]/10 border border-[#D4AF37]/30 mb-8 text-center space-y-1">
            <p className="text-xs text-amber-300 font-bold uppercase tracking-wider flex items-center justify-center gap-1">
              <Award size={14} /> Titre Obtenu
            </p>
            <p className="text-lg font-black text-white font-[Space_Grotesk]">
              {data.newTitle}
            </p>
            <p className="text-xs text-emerald-400 font-semibold">
              + Total : {data.points} XP (+{data.xpGained || 50} XP)
            </p>
          </div>

          {/* Close button */}
          <button
            onClick={onClose}
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-[#D4AF37] via-[#F0C940] to-amber-500 text-black font-extrabold text-base shadow-[0_0_25px_rgba(212,175,55,0.4)] hover:brightness-110 active:scale-[0.98] transition-all"
          >
            Continuer mon apprentissage 🚀
          </button>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
