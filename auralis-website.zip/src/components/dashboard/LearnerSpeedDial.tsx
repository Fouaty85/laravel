import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Zap, BookOpen, Bell, MessageSquare, Trophy, Settings, X, Sparkles } from "lucide-react";

export default function LearnerSpeedDial() {
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();

  const actions = [
    {
      id: "cours",
      label: "Mes Cours & Progression",
      icon: BookOpen,
      color: "bg-amber-500/10 text-amber-400 border-amber-500/20 hover:bg-amber-500/20",
      badge: "Cours",
      onClick: () => navigate("/cours"),
    },
    {
      id: "messages",
      label: "Messagerie & Formateurs",
      icon: MessageSquare,
      color: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20 hover:bg-emerald-500/20",
      badge: "Direct",
      onClick: () => navigate("/messages"),
    },
    {
      id: "notifications",
      label: "Notifications & Alertes",
      icon: Bell,
      color: "bg-blue-500/10 text-blue-400 border-blue-500/20 hover:bg-blue-500/20",
      badge: "Inscrit",
      onClick: () => navigate("/notifications"),
    },
    {
      id: "classement",
      label: "Classement & Xp",
      icon: Trophy,
      color: "bg-purple-500/10 text-purple-400 border-purple-500/20 hover:bg-purple-500/20",
      badge: "Top 10",
      onClick: () => navigate("/classement"),
    },
    {
      id: "parametres",
      label: "Mon Profil & Préférences",
      icon: Settings,
      color: "bg-neutral-500/10 text-neutral-300 border-neutral-500/20 hover:bg-neutral-500/20",
      badge: "Profil",
      onClick: () => navigate("/parametres"),
    },
  ];

  return (
    <div className="fixed bottom-24 right-6 z-[999] flex flex-col items-end group">
      {/* Tooltip label on hover */}
      <div className="absolute right-15 top-2.5 px-2.5 py-1 rounded-lg bg-black/90 border border-white/10 text-[11px] text-white font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-all pointer-events-none shadow-xl flex items-center gap-1.5 z-10">
        <Zap size={12} className="text-[#D4AF37]" /> Actions Rapides
      </div>

      {/* Backdrop overlay on mobile when open */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsOpen(false)}
            className="fixed inset-0 bg-black/40 backdrop-blur-xs z-[-1]"
          />
        )}
      </AnimatePresence>

      {/* Speed dial action items list */}
      <AnimatePresence>
        {isOpen && (
          <div className="flex flex-col items-end space-y-2.5 mb-3">
            {actions.map((action, index) => {
              const Icon = action.icon;
              return (
                <motion.div
                  key={action.id}
                  initial={{ opacity: 0, y: 20, scale: 0.8 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 15, scale: 0.8 }}
                  transition={{ duration: 0.2, delay: (actions.length - 1 - index) * 0.04 }}
                  className="flex items-center gap-3 cursor-pointer group"
                  onClick={() => {
                    action.onClick();
                    setIsOpen(false);
                  }}
                >
                  {/* Label tooltip */}
                  <div className="px-3 py-1.5 rounded-xl bg-black/90 border border-white/10 text-white text-xs font-semibold shadow-xl backdrop-blur-md opacity-90 group-hover:opacity-100 group-hover:scale-105 transition-all flex items-center gap-2">
                    <span>{action.label}</span>
                    <span className="text-[9px] uppercase px-1.5 py-0.5 rounded bg-white/10 font-bold text-[#D4AF37]">
                      {action.badge}
                    </span>
                  </div>

                  {/* Circle button */}
                  <button
                    className={`w-11 h-11 rounded-full border flex items-center justify-center shadow-xl backdrop-blur-md transition-all duration-200 ${action.color} group-hover:scale-110 active:scale-95`}
                  >
                    <Icon size={18} />
                  </button>
                </motion.div>
              );
            })}
          </div>
        )}
      </AnimatePresence>

      {/* Main trigger button */}
      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        whileHover={{ scale: 1.08 }}
        whileTap={{ scale: 0.92 }}
        className={`w-13 h-13 rounded-full flex items-center justify-center shadow-2xl border transition-all duration-300 relative ${
          isOpen
            ? "bg-red-500/20 text-red-400 border-red-500/40 rotate-90"
            : "bg-gradient-to-r from-[#D4AF37] to-[#F0C940] text-black border-[#D4AF37]/60 hover:shadow-[#D4AF37]/25"
        }`}
        title="Actions rapides Auralis"
      >
        {isOpen ? (
          <X size={22} className="stroke-[2.5]" />
        ) : (
          <div className="flex items-center justify-center relative">
            <Zap size={22} className="fill-black stroke-[1.5]" />
            <Sparkles size={10} className="absolute -top-1 -right-1 text-black animate-pulse" />
          </div>
        )}
      </motion.button>
    </div>
  );
}
