import { motion } from "framer-motion";
import { Progress } from "@/components/ui/progress";
import { Clock, BookOpen } from "lucide-react";

interface CourseCardProps {
  title: string;
  imageUrl?: string | null;
  niveau?: string | null;
  progression: number;
  adjustedLevel?: string | null;
  dureeMinutes?: number | null;
  delay?: number;
}

export default function CourseCard({
  title,
  imageUrl,
  niveau,
  progression,
  adjustedLevel,
  dureeMinutes,
  delay = 0,
}: CourseCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
      className="glass-card rounded-2xl overflow-hidden group hover:border-primary/25 transition-all cursor-pointer"
    >
      {/* Image */}
      <div className="relative h-36 bg-muted overflow-hidden">
        {imageUrl ? (
          <img
            src={imageUrl}
            alt={title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <BookOpen size={40} className="text-muted-foreground/30" />
          </div>
        )}
        {/* Progression overlay */}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-background/90 to-transparent p-3">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="text-foreground font-medium">{progression}%</span>
          </div>
          <div className="w-full h-1.5 rounded-full bg-muted/50 overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progression}%` }}
              transition={{ duration: 0.8, delay: delay + 0.2 }}
              className="h-full rounded-full bg-primary"
            />
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-2">
        <h4 className="font-semibold text-foreground line-clamp-2 text-sm leading-snug">
          {title}
        </h4>
        <div className="flex items-center gap-3 text-xs text-muted-foreground">
          {niveau && (
            <span className="px-2 py-0.5 rounded-full bg-primary/10 text-primary text-[11px] font-medium">
              {niveau}
            </span>
          )}
          {dureeMinutes && (
            <span className="flex items-center gap-1">
              <Clock size={12} />
              {dureeMinutes}min
            </span>
          )}
        </div>
        {adjustedLevel && (
          <p className="text-[11px] text-primary/60 italic">
            Niveau adapté : {adjustedLevel}
          </p>
        )}
      </div>
    </motion.div>
  );
}
