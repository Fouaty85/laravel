import { motion } from "framer-motion";
import { Sparkles, BookOpen } from "lucide-react";

interface RecommendationCardProps {
  title: string;
  description?: string | null;
  imageUrl?: string | null;
  niveau?: string | null;
  scoreConfiance?: number | null;
  reason?: string | null;
  delay?: number;
}

export default function RecommendationCard({
  title,
  description,
  imageUrl,
  niveau,
  scoreConfiance,
  reason,
  delay = 0,
}: RecommendationCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
      className="glass-card rounded-2xl overflow-hidden group hover:border-primary/25 transition-all cursor-pointer"
    >
      <div className="relative h-32 bg-muted overflow-hidden">
        {imageUrl ? (
          <img
            src={imageUrl}
            alt={title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <BookOpen size={32} className="text-muted-foreground/30" />
          </div>
        )}
        {scoreConfiance && (
          <div className="absolute top-2 right-2 flex items-center gap-1 px-2 py-1 rounded-full bg-background/80 backdrop-blur-sm border border-primary/20">
            <Sparkles size={12} className="text-primary" />
            <span className="text-[11px] font-medium text-primary">
              {Math.round(scoreConfiance * 100)}%
            </span>
          </div>
        )}
      </div>

      <div className="p-4 space-y-2">
        <h4 className="font-semibold text-foreground line-clamp-2 text-sm leading-snug">
          {title}
        </h4>
        {description && (
          <p className="text-xs text-muted-foreground line-clamp-2">{description}</p>
        )}
        <div className="flex items-center gap-2">
          {niveau && (
            <span className="px-2 py-0.5 rounded-full bg-primary/10 text-primary text-[11px] font-medium">
              {niveau}
            </span>
          )}
        </div>
        {reason && (
          <p className="text-[11px] text-muted-foreground/70 italic line-clamp-2">{reason}</p>
        )}
      </div>
    </motion.div>
  );
}
