import { useCallback } from "react";
import { useAuralisAvatar } from "./useAuralisAvatar";

export function useAuralisContext() {
  const { playGesture, setExpression, speak } = useAuralisAvatar();

  const onWelcome = useCallback((nameOrCustomText?: string) => {
    let greeting = "Bienvenue sur AURALIS ! Je suis ravi de vous retrouver.";
    if (nameOrCustomText) {
      if (nameOrCustomText.includes(" ") || nameOrCustomText.length > 20) {
        greeting = nameOrCustomText;
      } else {
        greeting = `Bonjour ${nameOrCustomText} ! Bienvenue sur AURALIS, votre plateforme d'apprentissage intelligente.`;
      }
    }
    playGesture("wave");
    setExpression("smile_medium");
    speak(greeting, "wave");
  }, [playGesture, setExpression, speak]);

  const onError = useCallback((message: string) => {
    playGesture("headShake");
    setExpression("concerned");
    speak(message, "headShake");
  }, [playGesture, setExpression, speak]);

  const onCongratulate = useCallback((message: string) => {
    playGesture("celebrate");
    setExpression("smile_big");
    speak(message, "celebrate");
  }, [playGesture, setExpression, speak]);

  const onLoading = useCallback((message: string = "Veuillez patienter pendant que je prépare cela...") => {
    playGesture("thinking");
    setExpression("thinking");
    speak(message, "thinking");
  }, [playGesture, setExpression, speak]);

  const onIdle = useCallback(() => {
    playGesture("idle");
    setExpression("neutral");
  }, [playGesture, setExpression]);

  const onInfo = useCallback((message: string) => {
    playGesture("point");
    setExpression("neutral");
    speak(message, "point");
  }, [playGesture, setExpression, speak]);

  const onSuccess = useCallback((message: string) => {
    playGesture("celebrate");
    setExpression("smile_medium");
    speak(message, "celebrate");
  }, [playGesture, setExpression, speak]);

  const onEncourage = useCallback((message: string) => {
    playGesture("nod");
    setExpression("smile_light");
    speak(message, "nod");
  }, [playGesture, setExpression, speak]);

  const onYes = useCallback((message: string = "Oui, c'est tout à fait correct ! Excellent travail.") => {
    playGesture("nod");
    setExpression("smile_medium");
    speak(message, "nod");
  }, [playGesture, setExpression, speak]);

  const onNo = useCallback((message: string = "Non, ce n'est pas tout à fait ça. Mais ne vous inquiétez pas, continuez d'essayer !") => {
    playGesture("headShake");
    setExpression("concerned");
    speak(message, "headShake");
  }, [playGesture, setExpression, speak]);

  return {
    onWelcome,
    onError,
    onCongratulate,
    onLoading,
    onIdle,
    onInfo,
    onSuccess,
    onEncourage,
    onYes,
    onNo,
  };
}
