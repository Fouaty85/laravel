import { useRef, useCallback } from "react";
import { useAuralisStore } from "@/hooks/useAuralisAvatar";
import type { AuralisGesture, AuralisExpression } from "@/hooks/useAuralisAvatar";

export interface ScenarioStep {
  gesture?: AuralisGesture;
  expression?: AuralisExpression;
  speech?: string;
  duration?: number; // ms before moving to the next step
  waitForSpeech?: boolean; // wait for speech to finish before moving to the next step
}

export function useAvatarScenario() {
  const queueRef = useRef<ScenarioStep[]>([]);
  const isRunningRef = useRef(false);
  const currentTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const cancelScenario = useCallback(() => {
    if (currentTimeoutRef.current) {
      clearTimeout(currentTimeoutRef.current);
    }
    if (typeof window !== "undefined" && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    queueRef.current = [];
    isRunningRef.current = false;
    const store = useAuralisStore.getState();
    store.setGesture("idle");
    store.setExpression("neutral");
    store.setTalking(false);
  }, []);

  const runQueue = useCallback(async (scenarioId: string) => {
    if (isRunningRef.current || queueRef.current.length === 0) return;
    isRunningRef.current = true;

    while (queueRef.current.length > 0) {
      // 1. Check if we've been preempted or component unmounted BEFORE dequeueing
      const storeState = useAuralisStore.getState();
      if (storeState.mountedComponentsCount === 0 || storeState.activeSpeechId !== scenarioId) {
        console.warn("Scenario stopped: component unmounted or preempted by another scenario/speak.");
        break;
      }

      const step = queueRef.current.shift()!;
      const currentStore = useAuralisStore.getState();

      if (step.gesture) currentStore.setGesture(step.gesture);
      if (step.expression) currentStore.setExpression(step.expression);

      if (step.speech && typeof window !== "undefined" && window.speechSynthesis) {
        // Double check right before speaking
        if (useAuralisStore.getState().mountedComponentsCount === 0 || useAuralisStore.getState().activeSpeechId !== scenarioId) {
          console.warn("Scenario step speech blocked: component unmounted or preempted.");
          break;
        }

        await new Promise<void>((resolve) => {
          const utterance = new SpeechSynthesisUtterance(step.speech);
          utterance.lang = "fr-FR";
          utterance.rate = 0.88;
          utterance.pitch = 0.8;
          utterance.volume = 1.0;

          // Search for a male voice or any French voice
          const voices = window.speechSynthesis.getVoices();
          const maleVoice =
            voices.find(
              (v) =>
                v.lang.startsWith("fr") &&
                !["amélie", "audrey", "marie", "sophie", "virginie", "céline", "sara"].some((f) =>
                  v.name.toLowerCase().includes(f)
                )
            ) ||
            voices.find((v) => v.lang.startsWith("fr")) ||
            voices[0];

          if (maleVoice) utterance.voice = maleVoice;

          currentStore.setTalking(true);
          currentStore.setGesture(step.gesture || "talking");

          utterance.onend = () => {
            const postStore = useAuralisStore.getState();
            if (postStore.activeSpeechId === scenarioId) {
              currentStore.setTalking(false);
            }
            resolve();
          };
          utterance.onerror = () => {
            const postStore = useAuralisStore.getState();
            if (postStore.activeSpeechId === scenarioId) {
              currentStore.setTalking(false);
            }
            resolve();
          };

          window.speechSynthesis.speak(utterance);
        });
      }

      if (step.duration && !step.waitForSpeech) {
        await new Promise<void>((resolve) => {
          currentTimeoutRef.current = setTimeout(() => {
            // Check preemption again inside timeout resolution
            const checkState = useAuralisStore.getState();
            if (checkState.mountedComponentsCount > 0 && checkState.activeSpeechId === scenarioId) {
              resolve();
            } else {
              resolve();
            }
          }, step.duration);
        });
      }
    }

    isRunningRef.current = false;
    const finalStore = useAuralisStore.getState();
    // Only reset gestures if we are still the active running scenario
    if (finalStore.activeSpeechId === scenarioId) {
      finalStore.setGesture("idle");
      finalStore.setExpression("neutral");
    }
  }, []);

  const playScenario = useCallback(
    (steps: ScenarioStep[]) => {
      cancelScenario();
      const scenarioId = "scenario_" + Math.random().toString(36).substring(7);
      useAuralisStore.getState().setActiveSpeechId(scenarioId);
      queueRef.current = [...steps];
      void runQueue(scenarioId);
    },
    [cancelScenario, runQueue]
  );

  // Predefined scenarios

  const scenarioBienvenuePage = useCallback(
    (prenom?: string) => {
      playScenario([
        { gesture: "wave", expression: "smile_big", duration: 500 },
        {
          gesture: "talking",
          expression: "smile_medium",
          speech: prenom
            ? `Bonjour ${prenom} ! Je suis Auralis, votre compagnon d'apprentissage intelligent. Bienvenue sur AURALIS !`
            : "Bonjour ! Je suis Auralis. Connectez-vous ou créez votre compte pour commencer votre aventure d'apprentissage !",
          waitForSpeech: true,
        },
        { gesture: "idle", expression: "smile_light", duration: 500 },
      ]);
    },
    [playScenario]
  );

  const scenarioConnexionEnCours = useCallback(() => {
    playScenario([
      { gesture: "thinking", expression: "thinking", duration: 200 },
      { gesture: "thinking", expression: "thinking", speech: "Connexion en cours...", waitForSpeech: true },
    ]);
  }, [playScenario]);

  const scenarioConnexionReussie = useCallback(
    (prenom?: string) => {
      playScenario([
        { gesture: "celebrate", expression: "smile_big", duration: 300 },
        {
          gesture: "talking",
          expression: "smile_big",
          speech: prenom ? `Connexion réussie ! Bienvenue ${prenom} !` : "Connexion réussie ! Bienvenue !",
          waitForSpeech: true,
        },
      ]);
    },
    [playScenario]
  );

  const scenarioErreurConnexion = useCallback(
    (message?: string) => {
      playScenario([
        { gesture: "headShake", expression: "concerned", duration: 400 },
        {
          gesture: "talking",
          expression: "concerned",
          speech: message || "Identifiants incorrects. Vérifiez votre email et mot de passe.",
          waitForSpeech: true,
        },
        { gesture: "idle", expression: "neutral", duration: 200 },
      ]);
    },
    [playScenario]
  );

  const scenarioInscriptionReussie = useCallback(
    (prenom?: string, role?: string) => {
      playScenario([
        { gesture: "celebrate", expression: "smile_big", duration: 500 },
        {
          gesture: "talking",
          expression: "smile_big",
          speech: `Bienvenue ${
            prenom || ""
          } ! Votre compte ${role === "formateur" ? "formateur" : "apprenant"} a été créé avec succès. Préparez-vous pour une expérience d'apprentissage exceptionnelle !`,
          waitForSpeech: true,
        },
      ]);
    },
    [playScenario]
  );

  const scenarioChampFocus = useCallback((champ: string) => {
    const messages: Record<string, { gesture: AuralisGesture; speech: string }> = {
      email: { gesture: "point", speech: "Entrez votre adresse email ici." },
      password: { gesture: "nod", speech: "Choisissez un mot de passe sécurisé." },
      pseudo: { gesture: "point", speech: "Choisissez un pseudo unique." },
      prenom: { gesture: "nod", speech: "Votre prénom pour personnaliser votre expérience." },
    };
    const config = messages[champ];
    if (!config) return;
    // Subtle reaction - no voice line to avoid interrupting input typing
    const store = useAuralisStore.getState();
    store.setGesture(config.gesture);
    store.setExpression("smile_light");
    setTimeout(() => {
      const currentStore = useAuralisStore.getState();
      currentStore.setGesture("idle");
      currentStore.setExpression("neutral");
    }, 1500);
  }, []);

  const scenarioFrappe = useCallback(() => {
    // Subtle physical confirmation - mild head nod
    const store = useAuralisStore.getState();
    if (store.gesture === "idle" && !store.isTalking) {
      store.setGesture("nod");
      store.setExpression("smile_light");
      setTimeout(() => {
        const currentStore = useAuralisStore.getState();
        currentStore.setGesture("idle");
        currentStore.setExpression("neutral");
      }, 800);
    }
  }, []);

  const scenarioDashboardApprenant = useCallback(
    (prenom?: string, coursCount?: number) => {
      const heure = new Date().getHours();
      const salut = heure < 12 ? "Bonjour" : heure < 18 ? "Bon après-midi" : "Bonsoir";
      playScenario([
        { gesture: "wave", expression: "smile_big", duration: 400 },
        {
          gesture: "talking",
          expression: "smile_medium",
          speech:
            coursCount && coursCount > 0
              ? `${salut} ${prenom || ""} ! Tu as ${coursCount} cours en cours. Continue comme ça, tu es sur la bonne voie !`
              : `${salut} ${prenom || ""} ! Je suis Auralis, ton assistant. Commence par découvrir nos cours en cliquant sur "Découvrir" !`,
          waitForSpeech: true,
        },
        { gesture: "idle", expression: "smile_light", duration: 200 },
      ]);
    },
    [playScenario]
  );

  const scenarioDashboardFormateur = useCallback(
    (prenom?: string) => {
      playScenario([
        { gesture: "wave", expression: "smile_big", duration: 400 },
        {
          gesture: "talking",
          expression: "smile_medium",
          speech: `Bonjour ${prenom || ""} ! Voici votre espace formateur. Suivez l'évolution de vos apprenants et gérez vos cours depuis ce tableau de bord.`,
          waitForSpeech: true,
        },
        { gesture: "idle", expression: "neutral", duration: 200 },
      ]);
    },
    [playScenario]
  );

  return {
    playScenario,
    cancelScenario,
    scenarioBienvenuePage,
    scenarioConnexionEnCours,
    scenarioConnexionReussie,
    scenarioErreurConnexion,
    scenarioInscriptionReussie,
    scenarioChampFocus,
    scenarioFrappe,
    scenarioDashboardApprenant,
    scenarioDashboardFormateur,
  };
}
