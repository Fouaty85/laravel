import { useEffect } from "react";
import { useGLTF } from "@react-three/drei";

const AVATAR_URL =
  "https://honklrkiszbarbatdusq.supabase.co/storage/v1/object/public/avatars/auralis_final_v2.glb";

export function useAvatarPreload() {
  useEffect(() => {
    // Précharge le GLB en arrière-plan dès que l'app démarre
    useGLTF.preload(AVATAR_URL);
  }, []);
}
