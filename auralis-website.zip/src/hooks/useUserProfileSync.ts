import { useState, useEffect, useCallback, useRef } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import {
  calculateLevelFromXP,
  getRoleTitle,
  getXPForLevel,
  calculateComprehensionLevel,
} from "@/lib/gamification";

export interface LevelUpEventData {
  oldLevel: number;
  newLevel: number;
  newTitle: string;
  points: number;
  actionName?: string;
  xpGained?: number;
}

export function useUserProfileSync() {
  const { user, profile, fetchProfile } = useAuth();

  const [realtimePoints, setRealtimePoints] = useState<number>(profile?.points ?? 0);
  const [realtimeStreak, setRealtimeStreak] = useState<number>(profile?.streak_jours ?? 1);
  const [realtimeNiveauGlobal, setRealtimeNiveauGlobal] = useState<string>(
    profile?.niveau_global ?? "Niveau 1 - Apprenant Assidu"
  );
  const [realtimeComprehension, setRealtimeComprehension] = useState<string>(
    profile?.niveau_comprehension ?? "85% - Bonne Maîtrise"
  );

  const [completedSectionsCount, setCompletedSectionsCount] = useState<number>(0);
  const [totalStudyMinutes, setTotalStudyMinutes] = useState<number>(0);
  const [quizzesTakenCount, setQuizzesTakenCount] = useState<number>(0);
  const [avgQuizScore, setAvgQuizScore] = useState<number>(85);

  const [levelUpData, setLevelUpData] = useState<LevelUpEventData | null>(null);
  const prevLevelRef = useRef<number>(calculateLevelFromXP(profile?.points ?? 0));

  // Sync state with auth profile whenever it updates
  useEffect(() => {
    if (profile) {
      if (profile.points !== undefined) setRealtimePoints(profile.points);
      if (profile.streak_jours !== undefined) setRealtimeStreak(profile.streak_jours);
      if (profile.niveau_global) setRealtimeNiveauGlobal(profile.niveau_global);
      if (profile.niveau_comprehension) setRealtimeComprehension(profile.niveau_comprehension);
    }
  }, [profile]);

  // Fetch detailed user activity stats from Supabase
  const fetchUserActivityStats = useCallback(async () => {
    if (!user) return;

    try {
      // 1. Progress stats
      const { data: progress } = await supabase
        .from("progress")
        .select("is_completed, time_spent_seconds")
        .eq("user_id", user.id);

      if (progress) {
        const completedCount = progress.filter((p) => p.is_completed).length;
        const seconds = progress.reduce((acc, p) => acc + (p.time_spent_seconds || 0), 0);
        setCompletedSectionsCount(completedCount);
        setTotalStudyMinutes(Math.round(seconds / 60));
      }

      // 2. Quiz attempts stats
      const { data: quizAttempts } = await supabase
        .from("quiz_attempts")
        .select("score, max_score")
        .eq("user_id", user.id);

      if (quizAttempts && quizAttempts.length > 0) {
        setQuizzesTakenCount(quizAttempts.length);
        const totalPct = quizAttempts.reduce((acc, q) => {
          const max = q.max_score || 100;
          return acc + Math.round(((q.score || 0) / max) * 100);
        }, 0);
        setAvgQuizScore(Math.round(totalPct / quizAttempts.length));
      }
    } catch (err) {
      console.warn("Error fetching user activity stats:", err);
    }
  }, [user]);

  // Handle Level-Up checks
  const checkForLevelUp = useCallback(
    (newXP: number, actionName?: string, xpGained?: number) => {
      const oldLevel = prevLevelRef.current;
      const newLevel = calculateLevelFromXP(newXP);

      if (newLevel > oldLevel) {
        const title = getRoleTitle(newLevel, profile?.role || "apprenant");
        setLevelUpData({
          oldLevel,
          newLevel,
          newTitle: title,
          points: newXP,
          actionName: actionName || "Excellente progression !",
          xpGained: xpGained || (newXP - (profile?.points || 0)),
        });
      }
      prevLevelRef.current = newLevel;
    },
    [profile?.role, profile?.points]
  );

  // Set up Realtime listener & Custom Window Events
  useEffect(() => {
    if (!user) return;

    fetchUserActivityStats();

    // Custom Window Event listener for fast local reactive updates
    const handleLocalUpdate = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail) {
        if (detail.points !== undefined) {
          setRealtimePoints(detail.points);
          checkForLevelUp(detail.points, detail.actionName, detail.amount);
        }
        if (detail.streak_jours !== undefined) setRealtimeStreak(detail.streak_jours);
        if (detail.niveau_global) setRealtimeNiveauGlobal(detail.niveau_global);
        if (detail.niveau_comprehension) setRealtimeComprehension(detail.niveau_comprehension);
      }
      fetchUserActivityStats();
    };

    window.addEventListener("profile-updated", handleLocalUpdate);

    // Supabase Realtime channel subscription for profiles, progress, quiz_attempts
    const channel = supabase
      .channel(`dashboard-sync-${user.id}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "profiles",
          filter: `id=eq.${user.id}`,
        },
        (payload) => {
          if (payload.new && typeof payload.new === "object") {
            const newProf = payload.new as Record<string, unknown>;
            if (typeof newProf.points === "number") {
              setRealtimePoints(newProf.points);
              checkForLevelUp(newProf.points);
            }
            if (typeof newProf.streak_jours === "number") setRealtimeStreak(newProf.streak_jours);
            if (typeof newProf.niveau_global === "string") setRealtimeNiveauGlobal(newProf.niveau_global);
            if (typeof newProf.niveau_comprehension === "string") setRealtimeComprehension(newProf.niveau_comprehension);
          }
          fetchProfile(user.id);
        }
      )
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "progress",
          filter: `user_id=eq.${user.id}`,
        },
        () => {
          fetchUserActivityStats();
        }
      )
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "quiz_attempts",
          filter: `user_id=eq.${user.id}`,
        },
        () => {
          fetchUserActivityStats();
        }
      )
      .subscribe();

    return () => {
      window.removeEventListener("profile-updated", handleLocalUpdate);
      supabase.removeChannel(channel);
    };
  }, [user, fetchProfile, fetchUserActivityStats, checkForLevelUp]);

  // Derived metrics
  const currentLevel = calculateLevelFromXP(realtimePoints);
  const currentRoleTitle = getRoleTitle(currentLevel, profile?.role || "apprenant");
  const currentLevelXP = getXPForLevel(currentLevel);
  const nextLevelXP = getXPForLevel(currentLevel + 1);
  const xpInCurrentLevel = realtimePoints - currentLevelXP;
  const xpNeededForNextLevel = Math.max(1, nextLevelXP - currentLevelXP);
  const levelProgressPercent = Math.min(
    100,
    Math.max(0, Math.round((xpInCurrentLevel / xpNeededForNextLevel) * 100))
  );

  const calculatedComprehension = calculateComprehensionLevel(realtimePoints, avgQuizScore);

  // Computed display totals (real dynamic metrics or baseline calculation)
  const displayStudyTime = Math.max(totalStudyMinutes, Math.round(realtimePoints * 0.3));
  const displayCompletedSections = Math.max(completedSectionsCount, Math.floor(realtimePoints / 30));

  const dismissLevelUpModal = () => setLevelUpData(null);

  return {
    points: realtimePoints,
    currentLevel,
    currentRoleTitle,
    niveauGlobal: `Niveau ${currentLevel} - ${currentRoleTitle}`,
    niveauComprehension: calculatedComprehension,
    streakJours: Math.max(realtimeStreak, realtimePoints > 0 ? 1 : 0),
    levelProgressPercent,
    currentLevelXP,
    nextLevelXP,
    xpInCurrentLevel,
    xpNeededForNextLevel,
    completedSectionsCount: displayCompletedSections,
    totalStudyMinutes: displayStudyTime,
    quizzesTakenCount,
    avgQuizScore,
    levelUpData,
    dismissLevelUpModal,
    refetchStats: fetchUserActivityStats,
  };
}
