import { create } from "zustand";
import { useCallback } from "react";

export type AuralisGesture =
  | "idle" | "walk" | "crossArms" | "wink" | "wave" | "point"
  | "thinking" | "nod" | "headShake" | "celebrate" | "sit" | "talking" | "smile";

export type AuralisExpression =
  | "neutral" | "smile_light" | "smile_medium" | "smile_big"
  | "thinking" | "surprised" | "concerned" | "proud";

export type AuralisSize = "small" | "medium" | "large";

export interface RigDebugInfo {
  allBoneNames: string[];
  mappedBones: Record<string, string | null>;
  animationClips: string[];
  morphTargets: string[];
  skeletonFound: boolean;
}

interface AuralisState {
  gesture: AuralisGesture;
  expression: AuralisExpression;
  isTalking: boolean;
  isVisible: boolean;
  size: AuralisSize;
  debugRig: RigDebugInfo | null;
  availableClips: string[];
  activeSpeechId: string | null;
  mountedComponentsCount: number;
  setGesture: (g: AuralisGesture) => void;
  setExpression: (e: AuralisExpression) => void;
  setTalking: (t: boolean) => void;
  setVisible: (v: boolean) => void;
  setSize: (s: AuralisSize) => void;
  setDebugRig: (d: RigDebugInfo) => void;
  setAvailableClips: (clips: string[]) => void;
  setActiveSpeechId: (id: string | null) => void;
  incrementMounted: () => void;
  decrementMounted: () => void;
}

export const useAuralisStore = create<AuralisState>((set) => ({
  gesture: "idle",
  expression: "neutral",
  isTalking: false,
  isVisible: true,
  size: "large",
  debugRig: null,
  availableClips: [],
  activeSpeechId: null,
  mountedComponentsCount: 0,
  setGesture: (gesture) => set({ gesture }),
  setExpression: (expression) => set({ expression }),
  setTalking: (isTalking) => set({ isTalking }),
  setVisible: (isVisible) => set({ isVisible }),
  setSize: (size) => set({ size }),
  setDebugRig: (debugRig) => set({ debugRig }),
  setAvailableClips: (availableClips) => set({ availableClips }),
  setActiveSpeechId: (activeSpeechId) => set({ activeSpeechId }),
  incrementMounted: () => set((state) => ({ mountedComponentsCount: state.mountedComponentsCount + 1 })),
  decrementMounted: () => set((state) => ({ mountedComponentsCount: Math.max(0, state.mountedComponentsCount - 1) })),
}));

export function useAuralisAvatar() {
  const gesture = useAuralisStore((s) => s.gesture);
  const expression = useAuralisStore((s) => s.expression);
  const isTalking = useAuralisStore((s) => s.isTalking);
  const isVisible = useAuralisStore((s) => s.isVisible);
  const size = useAuralisStore((s) => s.size);
  const debugRig = useAuralisStore((s) => s.debugRig);
  const availableClips = useAuralisStore((s) => s.availableClips);

  const setGesture = useAuralisStore((s) => s.setGesture);
  const setExpressionAction = useAuralisStore((s) => s.setExpression);
  const setTalking = useAuralisStore((s) => s.setTalking);
  const setVisible = useAuralisStore((s) => s.setVisible);
  const setSize = useAuralisStore((s) => s.setSize);
  const setDebugRig = useAuralisStore((s) => s.setDebugRig);
  const setAvailableClips = useAuralisStore((s) => s.setAvailableClips);

  const playGesture = useCallback(
    (g: AuralisGesture, durationMs?: number) => {
      setGesture(g);
      if (durationMs) {
        setTimeout(() => setGesture("idle"), durationMs);
      }
    },
    [setGesture]
  );

  const setExpression = useCallback(
    (e: AuralisExpression, durationMs?: number) => {
      setExpressionAction(e);
      if (durationMs) {
        setTimeout(() => setExpressionAction("neutral"), durationMs);
      }
    },
    [setExpressionAction]
  );

  const speak = useCallback(
    (text: string, g?: AuralisGesture) => {
      // Cancel any ongoing speech
      if ("speechSynthesis" in window) {
        speechSynthesis.cancel();
      }

      const speechId = Math.random().toString(36).substring(7);
      useAuralisStore.getState().setActiveSpeechId(speechId);

      setTalking(true);
      if (g) setGesture(g);

      // Create a compatible subset of store actions for doSpeak
      const mockStore: SpeakStoreSubset = {
        setTalking,
        setGesture,
        setExpression: setExpressionAction,
      };

      doSpeak(text, g, mockStore, speechId);
    },
    [setGesture, setExpressionAction, setTalking]
  );

  return {
    gesture,
    expression,
    isTalking,
    isVisible,
    size,
    debugRig,
    availableClips,
    setGesture,
    setExpression,
    setTalking,
    setVisible,
    setSize,
    setDebugRig,
    setAvailableClips,
    playGesture,
    speak,
  };
}

interface SpeakStoreSubset {
  setTalking: (t: boolean) => void;
  setGesture: (g: AuralisGesture) => void;
  setExpression: (e: AuralisExpression) => void;
}

// Known high-quality French male voice names across browsers/OS
const PREFERRED_FR_MALE_VOICES = [
  "thomas", "thomas (enhanced)", "thomas (premium)",
  "julien", "nicolas", "pierre", "laurent",
  "google français", // Chrome
  "microsoft claude", "microsoft paul", // Edge/Windows
  "daniel", "jacques", "jean",
];

function scoreFrenchVoice(voice: SpeechSynthesisVoice): number {
  const name = voice.name.toLowerCase();
  const lang = voice.lang.toLowerCase();

  if (!lang.startsWith("fr")) return -1;

  let score = 0;

  if (lang === "fr-fr") score += 10;

  const matchIndex = PREFERRED_FR_MALE_VOICES.findIndex((v) => name.includes(v));
  if (matchIndex !== -1) score += 50 - matchIndex;

  if (name.includes("premium")) score += 30;
  if (name.includes("enhanced")) score += 20;

  const femaleNames = ["amelie", "audrey", "marie", "sophie", "virginie", "céline", "sara"];
  if (femaleNames.some((f) => name.includes(f))) score -= 40;

  if (!name.includes("compact")) score += 5;
  if (!voice.localService) score += 2;

  return score;
}

function doSpeak(text: string, gesture: AuralisGesture | undefined, store: SpeakStoreSubset, speechId?: string) {
  if (!("speechSynthesis" in window)) {
    store.setTalking(false);
    return;
  }

  // Ensure mounting and explicit lifecycle check
  const storeState = useAuralisStore.getState();
  if (storeState.mountedComponentsCount === 0) {
    console.warn("Speech blocked: No avatar components mounted to handle speech audio.");
    store.setTalking(false);
    return;
  }

  if (speechId && storeState.activeSpeechId !== speechId) {
    console.warn("Speech blocked: Speech ID has changed or been preempted.");
    store.setTalking(false);
    return;
  }

  let hasSpoken = false;
  const attemptSpeak = () => {
    if (hasSpoken) return;
    hasSpoken = true;

    const currentState = useAuralisStore.getState();
    if (currentState.mountedComponentsCount === 0) {
      console.warn("Speech aborted: Component unmounted during voice loading.");
      store.setTalking(false);
      return;
    }
    if (speechId && currentState.activeSpeechId !== speechId) {
      console.warn("Speech aborted: Preempted by a newer speech trigger.");
      store.setTalking(false);
      return;
    }

    const voices = speechSynthesis.getVoices();
    const scored = voices
      .map((v) => ({ voice: v, score: scoreFrenchVoice(v) }))
      .filter((v) => v.score >= 0)
      .sort((a, b) => b.score - a.score);

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "fr-FR";
    utterance.rate = 0.92;
    utterance.pitch = 0.8;
    utterance.volume = 1.0;

    if (scored.length > 0) {
      utterance.voice = scored[0].voice;
      console.log("🎙️ Voix sélectionnée:", scored[0].voice.name, `(score: ${scored[0].score})`);
    }

    utterance.onend = () => {
      // Only reset store states if we are still the active speech utterance
      const postState = useAuralisStore.getState();
      if (!speechId || postState.activeSpeechId === speechId) {
        store.setTalking(false);
        store.setGesture("idle");
        store.setExpression("neutral");
      }
    };
    utterance.onerror = () => {
      const postState = useAuralisStore.getState();
      if (!speechId || postState.activeSpeechId === speechId) {
        store.setTalking(false);
        store.setGesture("idle");
      }
    };

    speechSynthesis.speak(utterance);
  };

  const voices = speechSynthesis.getVoices();
  if (voices.length > 0) {
    attemptSpeak();
  } else {
    speechSynthesis.onvoiceschanged = () => {
      attemptSpeak();
      speechSynthesis.onvoiceschanged = null;
    };
    setTimeout(() => {
      if (speechSynthesis.getVoices().length === 0) {
        store.setTalking(false);
      } else {
        attemptSpeak();
      }
    }, 1000);
  }
}
