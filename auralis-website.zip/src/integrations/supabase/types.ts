export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      audit_logs: {
        Row: {
          action: string
          created_at: string | null
          id: string
          ip_address: string | null
          resource_id: string | null
          resource_type: string | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string | null
          id?: string
          ip_address?: string | null
          resource_id?: string | null
          resource_type?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string | null
          id?: string
          ip_address?: string | null
          resource_id?: string | null
          resource_type?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "audit_logs_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      courses: {
        Row: {
          categorie: string | null
          created_at: string | null
          description: string | null
          duree_minutes: number | null
          formateur_id: string | null
          id: string
          image_url: string | null
          is_published: boolean | null
          langue: string | null
          niveau: string | null
          published_at: string | null
          tags: string[] | null
          titre: string
        }
        Insert: {
          categorie?: string | null
          created_at?: string | null
          description?: string | null
          duree_minutes?: number | null
          formateur_id?: string | null
          id?: string
          image_url?: string | null
          is_published?: boolean | null
          langue?: string | null
          niveau?: string | null
          published_at?: string | null
          tags?: string[] | null
          titre: string
        }
        Update: {
          categorie?: string | null
          created_at?: string | null
          description?: string | null
          duree_minutes?: number | null
          formateur_id?: string | null
          id?: string
          image_url?: string | null
          is_published?: boolean | null
          langue?: string | null
          niveau?: string | null
          published_at?: string | null
          tags?: string[] | null
          titre?: string
        }
        Relationships: [
          {
            foreignKeyName: "courses_formateur_id_fkey"
            columns: ["formateur_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      enrollments: {
        Row: {
          adjusted_level: string | null
          completed_at: string | null
          course_id: string | null
          enrolled_at: string | null
          id: string
          progression: number | null
          user_id: string | null
        }
        Insert: {
          adjusted_level?: string | null
          completed_at?: string | null
          course_id?: string | null
          enrolled_at?: string | null
          id?: string
          progression?: number | null
          user_id?: string | null
        }
        Update: {
          adjusted_level?: string | null
          completed_at?: string | null
          course_id?: string | null
          enrolled_at?: string | null
          id?: string
          progression?: number | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "enrollments_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "enrollments_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      forum_posts: {
        Row: {
          contenu: string
          course_id: string | null
          created_at: string | null
          id: string
          is_best_answer: boolean | null
          parent_id: string | null
          titre: string | null
          user_id: string | null
          votes: number | null
        }
        Insert: {
          contenu: string
          course_id?: string | null
          created_at?: string | null
          id?: string
          is_best_answer?: boolean | null
          parent_id?: string | null
          titre?: string | null
          user_id?: string | null
          votes?: number | null
        }
        Update: {
          contenu?: string
          course_id?: string | null
          created_at?: string | null
          id?: string
          is_best_answer?: boolean | null
          parent_id?: string | null
          titre?: string | null
          user_id?: string | null
          votes?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "forum_posts_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "forum_posts_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "forum_posts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "forum_posts_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      level_assessments: {
        Row: {
          assessed_at: string | null
          course_id: string | null
          gemini_analysis: string | null
          id: string
          level_detected: string | null
          questions_answers: Json | null
          score: number | null
          user_id: string | null
        }
        Insert: {
          assessed_at?: string | null
          course_id?: string | null
          gemini_analysis?: string | null
          id?: string
          level_detected?: string | null
          questions_answers?: Json | null
          score?: number | null
          user_id?: string | null
        }
        Update: {
          assessed_at?: string | null
          course_id?: string | null
          gemini_analysis?: string | null
          id?: string
          level_detected?: string | null
          questions_answers?: Json | null
          score?: number | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "level_assessments_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "level_assessments_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      messages: {
        Row: {
          contenu: string
          created_at: string | null
          id: string
          is_read: boolean | null
          receiver_id: string | null
          sender_id: string | null
        }
        Insert: {
          contenu: string
          created_at?: string | null
          id?: string
          is_read?: boolean | null
          receiver_id?: string | null
          sender_id?: string | null
        }
        Update: {
          contenu?: string
          created_at?: string | null
          id?: string
          is_read?: boolean | null
          receiver_id?: string | null
          sender_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "messages_receiver_id_fkey"
            columns: ["receiver_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "messages_sender_id_fkey"
            columns: ["sender_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      modules: {
        Row: {
          course_id: string | null
          created_at: string | null
          id: string
          is_locked: boolean | null
          ordre: number
          titre: string
        }
        Insert: {
          course_id?: string | null
          created_at?: string | null
          id?: string
          is_locked?: boolean | null
          ordre: number
          titre: string
        }
        Update: {
          course_id?: string | null
          created_at?: string | null
          id?: string
          is_locked?: boolean | null
          ordre?: number
          titre?: string
        }
        Relationships: [
          {
            foreignKeyName: "modules_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          created_at: string | null
          data: Json | null
          id: string
          is_read: boolean | null
          message: string
          titre: string
          type: string
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          data?: Json | null
          id?: string
          is_read?: boolean | null
          message: string
          titre: string
          type: string
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          data?: Json | null
          id?: string
          is_read?: boolean | null
          message?: string
          titre?: string
          type?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "notifications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string | null
          derniere_connexion: string | null
          id: string
          is_onboarded: boolean
          niveau_comprehension: string | null
          niveau_global: string | null
          nom: string
          points: number | null
          prenom: string
          pseudo: string
          role: string
          streak_jours: number | null
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string | null
          derniere_connexion?: string | null
          id: string
          is_onboarded?: boolean
          niveau_comprehension?: string | null
          niveau_global?: string | null
          nom: string
          points?: number | null
          prenom: string
          pseudo: string
          role: string
          streak_jours?: number | null
        }
        Update: {
          avatar_url?: string | null
          created_at?: string | null
          derniere_connexion?: string | null
          id?: string
          is_onboarded?: boolean
          niveau_comprehension?: string | null
          niveau_global?: string | null
          nom?: string
          points?: number | null
          prenom?: string
          pseudo?: string
          role?: string
          streak_jours?: number | null
        }
        Relationships: []
      }
      progress: {
        Row: {
          id: string
          is_completed: boolean | null
          last_accessed_at: string | null
          section_id: string | null
          time_spent_seconds: number | null
          user_id: string | null
        }
        Insert: {
          id?: string
          is_completed?: boolean | null
          last_accessed_at?: string | null
          section_id?: string | null
          time_spent_seconds?: number | null
          user_id?: string | null
        }
        Update: {
          id?: string
          is_completed?: boolean | null
          last_accessed_at?: string | null
          section_id?: string | null
          time_spent_seconds?: number | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "progress_section_id_fkey"
            columns: ["section_id"]
            isOneToOne: false
            referencedRelation: "sections"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "progress_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      questions: {
        Row: {
          correct_answer: string | null
          explication: string | null
          id: string
          options: Json | null
          ordre: number
          points: number | null
          quiz_id: string | null
          texte: string
          type: string | null
        }
        Insert: {
          correct_answer?: string | null
          explication?: string | null
          id?: string
          options?: Json | null
          ordre: number
          points?: number | null
          quiz_id?: string | null
          texte: string
          type?: string | null
        }
        Update: {
          correct_answer?: string | null
          explication?: string | null
          id?: string
          options?: Json | null
          ordre?: number
          points?: number | null
          quiz_id?: string | null
          texte?: string
          type?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "questions_quiz_id_fkey"
            columns: ["quiz_id"]
            isOneToOne: false
            referencedRelation: "quizzes"
            referencedColumns: ["id"]
          },
        ]
      }
      quiz_attempts: {
        Row: {
          answers: Json | null
          attempted_at: string | null
          duration_seconds: number | null
          id: string
          max_score: number
          passed: boolean
          quiz_id: string | null
          score: number
          user_id: string | null
        }
        Insert: {
          answers?: Json | null
          attempted_at?: string | null
          duration_seconds?: number | null
          id?: string
          max_score: number
          passed: boolean
          quiz_id?: string | null
          score: number
          user_id?: string | null
        }
        Update: {
          answers?: Json | null
          attempted_at?: string | null
          duration_seconds?: number | null
          id?: string
          max_score?: number
          passed?: boolean
          quiz_id?: string | null
          score?: number
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "quiz_attempts_quiz_id_fkey"
            columns: ["quiz_id"]
            isOneToOne: false
            referencedRelation: "quizzes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "quiz_attempts_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      quizzes: {
        Row: {
          course_id: string | null
          created_at: string | null
          duree_minutes: number | null
          id: string
          ordre_aleatoire: boolean | null
          section_id: string | null
          seuil_reussite: number | null
          titre: string
          type: string | null
        }
        Insert: {
          course_id?: string | null
          created_at?: string | null
          duree_minutes?: number | null
          id?: string
          ordre_aleatoire?: boolean | null
          section_id?: string | null
          seuil_reussite?: number | null
          titre: string
          type?: string | null
        }
        Update: {
          course_id?: string | null
          created_at?: string | null
          duree_minutes?: number | null
          id?: string
          ordre_aleatoire?: boolean | null
          section_id?: string | null
          seuil_reussite?: number | null
          titre?: string
          type?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "quizzes_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "quizzes_section_id_fkey"
            columns: ["section_id"]
            isOneToOne: false
            referencedRelation: "sections"
            referencedColumns: ["id"]
          },
        ]
      }
      recommendations: {
        Row: {
          course_id: string | null
          generated_at: string | null
          id: string
          is_clicked: boolean | null
          is_dismissed: boolean | null
          reason: string | null
          score_confiance: number | null
          user_id: string | null
        }
        Insert: {
          course_id?: string | null
          generated_at?: string | null
          id?: string
          is_clicked?: boolean | null
          is_dismissed?: boolean | null
          reason?: string | null
          score_confiance?: number | null
          user_id?: string | null
        }
        Update: {
          course_id?: string | null
          generated_at?: string | null
          id?: string
          is_clicked?: boolean | null
          is_dismissed?: boolean | null
          reason?: string | null
          score_confiance?: number | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "recommendations_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "recommendations_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      sections: {
        Row: {
          contenu_texte: string | null
          contenu_url: string | null
          created_at: string | null
          duree_minutes: number | null
          id: string
          module_id: string | null
          ordre: number
          titre: string
          type: string | null
        }
        Insert: {
          contenu_texte?: string | null
          contenu_url?: string | null
          created_at?: string | null
          duree_minutes?: number | null
          id?: string
          module_id?: string | null
          ordre: number
          titre: string
          type?: string | null
        }
        Update: {
          contenu_texte?: string | null
          contenu_url?: string | null
          created_at?: string | null
          duree_minutes?: number | null
          id?: string
          module_id?: string | null
          ordre?: number
          titre?: string
          type?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "sections_module_id_fkey"
            columns: ["module_id"]
            isOneToOne: false
            referencedRelation: "modules"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      complete_onboarding: { Args: { _role: string }; Returns: Json }
      create_audit_log: {
        Args: {
          _action: string
          _resource_id?: string
          _resource_type?: string
        }
        Returns: undefined
      }
      ensure_profile_exists: { Args: never; Returns: Json }
      get_quiz_questions: {
        Args: { _quiz_id: string }
        Returns: {
          id: string
          options: Json
          ordre: number
          points: number
          quiz_id: string
          texte: string
          type: string
        }[]
      }
      get_user_role: { Args: { _user_id: string }; Returns: string }
      validate_quiz_answers: {
        Args: { _answers: Json; _quiz_id: string }
        Returns: Json
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
