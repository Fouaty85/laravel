import { GoogleGenAI } from "@google/genai";
import { awardXP } from "./gamification";

export interface YouTubeCourseContext {
  videoId?: string;
  title: string;
  channelTitle?: string;
  description?: string;
}

export async function askAuralisAIAboutCourse({
  userId,
  userMessage,
  courseContext,
  userRole = "apprenant",
}: {
  userId: string;
  userMessage: string;
  courseContext?: YouTubeCourseContext | null;
  userRole?: string;
}): Promise<{ answer: string; xpAwarded: number }> {
  const apiKey = import.meta.env.VITE_GEMINI_API_KEY || (typeof process !== "undefined" ? process.env.GEMINI_API_KEY : undefined);

  // Construct pedagogical prompt
  const contextHeader = courseContext
    ? `CONTEXTE DU COURS YOUTUBE RECHERCHÉ PAR AURALIS :
Titre : "${courseContext.title}"
Chaîne : "${courseContext.channelTitle || "Inconnue"}"
Description : "${courseContext.description || "Aucune description"}"`
    : `CONTEXTE GÉNÉRAL : L'apprenant échange directement avec Auralis, l'IA pédagogique universelle de la plateforme.`;

  const systemInstruction = `Tu es Auralis, l'Avatar Pédagogique et l'IA tuteur officielle de la plateforme Auralis.
${contextHeader}

Consignes :
1. Réponds en français de manière très pédagogique, encourageante, claire, avec des exemples conccrets et un ton motivant.
2. Si la question de l'étudiant porte sur le cours YouTube recherché, explique les concepts clés avec bienveillance.
3. Garde tes réponses synthétiques (entre 2 et 4 paragraphes courts), bien structurées avec des puces si nécessaire.
4. Termine en encourageant l'étudiant à continuer sa progression pour gagner de l'expérience XP.`;

  let responseText = "";
  let xpAwarded = 25; // Default positive XP for active learning

  try {
    if (apiKey) {
      const ai = new GoogleGenAI({ apiKey });
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [
          { role: "user", parts: [{ text: `${systemInstruction}\n\nQuestion de l'apprenant : "${userMessage}"` }] },
        ],
      });
      responseText = response.text || "";
    }
  } catch (err) {
    console.warn("Gemini API call failed, using fallback pedagogical response:", err);
  }

  // Fallback response if API key wasn't available or errored
  if (!responseText) {
    if (courseContext) {
      responseText = `Excellente question sur le cours **"${courseContext.title}"** ! 🎓\n\nEn tant qu'IA Auralis, j'ai sélectionné cette vidéo pour toi car elle couvre parfaitement les fondements indispensables.\n\nPour répondre à ta question sur *"_${userMessage}_"* : Ce concept repose sur une démarche progressive. Je te conseille d'observer attentivement la démonstration dans la vidéo, puis d'essayer un exercice pratique.\n\nDes XP viennent de t'être attribués pour ta curiosité intellectuelle ! continue ainsi !`;
    } else {
      responseText = `C'est un plaisir de t'aider ! 🌟\n\nConcernant ta question *"_${userMessage}_"*, c'est un point clé de ton parcours d'apprentissage. En posant des questions précises et en effectuant les quiz interactifs, ton niveau global et ta compréhension vont continuer à augmenter en temps réel !\n\nN'hésite pas à me poser d'autres questions !`;
    }
  }

  // Dynamic XP Evaluation Policy:
  // Short spam (<4 chars) => Penalty -10 XP
  // Well articulated question (>35 chars) with YouTube context => +35 XP
  // Normal question (>15 chars) => +25 XP
  // Short message => +10 XP
  if (userMessage.trim().length < 4) {
    xpAwarded = -10;
  } else if (userMessage.trim().length > 35 && courseContext) {
    xpAwarded = 35;
  } else if (userMessage.trim().length > 15) {
    xpAwarded = 25;
  } else {
    xpAwarded = 10;
  }

  // Award or deduct XP in Supabase
  if (userId) {
    await awardXP({
      userId,
      amount: xpAwarded,
      actionName: xpAwarded > 0 
        ? `Question posée à Auralis${courseContext ? ` sur "${courseContext.title.slice(0, 25)}..."` : ""}`
        : "Message trop succinct adressé à l'IA (-10 XP)",
      userRole,
    });
  }

  return { answer: responseText, xpAwarded };
}
