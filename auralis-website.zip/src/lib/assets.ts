import auralisLogoImg from "@/assets/auralis-logo.png";

// Shared vector and image assets to avoid missing file errors during migration
export const auralisLogo = auralisLogoImg;

