import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

/**
 * Calculates user level (1 to 500) based on accumulated XP points
 */
export function calculateLevelFromXP(points: number): number {
  if (!points || points <= 0) return 1;
  // Smooth curve designed to reach Level 500 at ~320,000 XP
  const level = Math.floor(1 + Math.pow(points / 20, 0.65));
  return Math.min(500, Math.max(1, level));
}

/**
 * Calculates XP required to reach a specific level
 */
export function getXPForLevel(level: number): number {
  if (level <= 1) return 0;
  return Math.floor(20 * Math.pow(level - 1, 1 / 0.65));
}

/**
 * Returns title based on Level and Role
 */
export function getRoleTitle(level: number, role: string = "apprenant"): string {
  if (role === "formateur") {
    if (level >= 400) return "Professeur Certifié par la Plateforme";
    if (level >= 151) return "Instructeur Master";
    if (level >= 51) return "Formateur Expérimenté";
    return "Formateur Initié";
  }

  // Apprenant titles
  if (level >= 500) return "Expert Confirmé (Niveau Max)";
  if (level >= 351) return "Mentor Virtuose";
  if (level >= 201) return "Spécialiste Maître";
  if (level >= 101) return "Analyste Avancé";
  if (level >= 51) return "Praticien Compétent";
  if (level >= 21) return "Apprenant Assidu";
  return "Apprenant Initié";
}

/**
 * Formats the full level label (e.g., "Niveau 14 - Apprenant Assidu")
 */
export function formatFullLevelLabel(level: number, role: string = "apprenant"): string {
  const title = getRoleTitle(level, role);
  return `Niveau ${level} - ${title}`;
}

/**
 * Calculates dynamic comprehension level percentage & description
 */
export function calculateComprehensionLevel(points: number, accuracyPercentage: number = 85): string {
  const level = calculateLevelFromXP(points);
  // Base comprehension score derived from accuracy and level progression
  const baseScore = Math.min(99, Math.max(60, Math.round(accuracyPercentage * 0.7 + Math.min(30, level * 0.15))));

  if (baseScore >= 95) return `${baseScore}% - Compréhension Parfaite`;
  if (baseScore >= 88) return `${baseScore}% - Compréhension Approfondie`;
  if (baseScore >= 80) return `${baseScore}% - Bonne Maîtrise`;
  if (baseScore >= 70) return `${baseScore}% - Notion Assimilée`;
  return `${baseScore}% - En Progression`;
}

export interface AwardXPAptions {
  userId: string;
  amount: number;
  actionName: string;
  userRole?: string;
  accuracyScore?: number;
}

/**
 * Awards or deducts XP for a user, recalculates level and comprehension, and syncs to Supabase.
 * Dispatches window event "profile-updated" for immediate UI reactions.
 */
export async function awardXP({
  userId,
  amount,
  actionName,
  userRole = "apprenant",
  accuracyScore = 88,
}: AwardXPAptions) {
  if (!userId || userId === "auralis-ai-avatar" || userId.startsWith("auralis") || amount === 0) return null;

  try {
    // 1. Fetch current profile safely selecting standard guaranteed columns
    const { data: profile } = await supabase
      .from("profiles")
      .select("points, role, prenom")
      .eq("id", userId)
      .maybeSingle();

    const currentPoints = profile?.points || 0;
    const oldLevel = calculateLevelFromXP(currentPoints);
    const newPoints = Math.max(0, currentPoints + amount);
    const newLevel = calculateLevelFromXP(newPoints);
    const effectiveRole = userRole || profile?.role || "apprenant";

    const newTitle = getRoleTitle(newLevel, effectiveRole);
    const newNiveauGlobal = `Niveau ${newLevel} - ${newTitle}`;
    const newNiveauComprehension = calculateComprehensionLevel(newPoints, accuracyScore);

    const levelUp = newLevel > oldLevel;
    const levelDown = newLevel < oldLevel;

    const newStreak = 1;

    // 2. Update or upsert profile standard points column
    if (profile) {
      const { error: updateErr } = await supabase
        .from("profiles")
        .update({
          points: newPoints,
        })
        .eq("id", userId);

      if (updateErr) {
        console.warn("Could not update profile points:", updateErr.message);
      }
    } else {
      const { error: upsertErr } = await supabase
        .from("profiles")
        .upsert({
          id: userId,
          points: newPoints,
          role: effectiveRole,
          prenom: "Apprenant",
          nom: "Auralis",
          pseudo: `user_${userId.slice(0, 6)}`,
        });

      if (upsertErr) {
        console.warn("Could not upsert profile points:", upsertErr.message);
      }
    }

    // 2a. Attempt to update optional extended columns if present in schema
    try {
      await supabase
        .from("profiles")
        .update({
          niveau_global: newNiveauGlobal,
          niveau_comprehension: newNiveauComprehension,
          streak_jours: newStreak,
        })
        .eq("id", userId);
    } catch {
      // Ignore if optional columns don't exist in Supabase schema
    }

    // 2b. Dispatch window event for immediate UI reaction
    if (typeof window !== "undefined") {
      window.dispatchEvent(
        new CustomEvent("profile-updated", {
          detail: {
            userId,
            points: newPoints,
            oldLevel,
            newLevel,
            amount,
            actionName,
            niveau_global: newNiveauGlobal,
            niveau_comprehension: newNiveauComprehension,
            streak_jours: newStreak,
          },
        })
      );
    }

    // 3. Trigger Toast notification
    if (amount > 0) {
      if (levelUp) {
        toast.success(`🎉 MONTÉE DE NIVEAU !`, {
          description: `Félicitations ! Vous êtes passé au Niveau ${newLevel} (${newTitle}) ! +${amount} XP (${actionName})`,
          duration: 5000,
        });
      } else {
        toast.info(`⭐ +${amount} XP Gagnés !`, {
          description: `${actionName} • Total : ${newPoints} XP (Niveau ${newLevel})`,
          duration: 3500,
        });
      }
    } else {
      const absAmount = Math.abs(amount);
      if (levelDown) {
        toast.error(`📉 RÉDUCTION DE NIVEAU !`, {
          description: `Attention : Votre niveau est repassé au Niveau ${newLevel} (${newTitle}). -${absAmount} XP (${actionName})`,
          duration: 5000,
        });
      } else {
        toast.warning(`⚠️ -${absAmount} XP Pénalité !`, {
          description: `${actionName} • Total : ${newPoints} XP (Niveau ${newLevel})`,
          duration: 3500,
        });
      }
    }

    return {
      newPoints,
      newLevel,
      oldLevel,
      levelUp,
      newTitle,
      newNiveauGlobal,
      newNiveauComprehension,
    };
  } catch (err) {
    console.error("awardXP exception:", err);
    return null;
  }
}

/**
 * Refactored Quiz XP calculator & persistent attempt logger
 */
export async function trackQuizXP({
  userId,
  quizId,
  score,
  maxScore = 100,
  durationSeconds = 60,
  userRole = "apprenant",
}: {
  userId: string;
  quizId?: string;
  score: number;
  maxScore?: number;
  durationSeconds?: number;
  userRole?: string;
}) {
  const percentage = Math.round((score / Math.max(1, maxScore)) * 100);
  const passed = percentage >= 50;

  let xpAmount = 0;
  let actionName = "";

  if (percentage >= 90) {
    xpAmount = 100;
    actionName = `Quiz Réussi avec Excellence (${percentage}%)`;
  } else if (percentage >= 75) {
    xpAmount = 70;
    actionName = `Très Bon Résultat au Quiz (${percentage}%)`;
  } else if (percentage >= 50) {
    xpAmount = 40;
    actionName = `Quiz Validé (${percentage}%)`;
  } else {
    xpAmount = -10;
    actionName = `Performance à Améliorer au Quiz (${percentage}%)`;
  }

  // Persist attempt to Supabase quiz_attempts table if user is logged in
  if (userId && !userId.startsWith("auralis")) {
    try {
      await supabase.from("quiz_attempts").insert({
        user_id: userId,
        quiz_id: quizId || null,
        score,
        max_score: maxScore,
        passed,
        duration_seconds: durationSeconds,
        attempted_at: new Date().toISOString(),
      });
    } catch (e) {
      console.warn("Could not save quiz attempt:", e);
    }
  }

  return await awardXP({
    userId,
    amount: xpAmount,
    actionName,
    userRole,
    accuracyScore: percentage,
  });
}

/**
 * Refactored Course Completion XP tracker
 */
export async function trackCourseCompletionXP({
  userId,
  courseId,
  courseTitle,
  userRole = "apprenant",
}: {
  userId: string;
  courseId?: string;
  courseTitle?: string;
  userRole?: string;
}) {
  const xpAmount = 250;
  const actionName = `Formation Complétée avec Succès${courseTitle ? ` : "${courseTitle}"` : ""}`;

  // Update enrollment state in Supabase
  if (userId && courseId) {
    try {
      await supabase
        .from("enrollments")
        .update({
          completed_at: new Date().toISOString(),
          progression: 100,
        })
        .eq("user_id", userId)
        .eq("course_id", courseId);
    } catch (e) {
      console.warn("Could not mark enrollment as completed:", e);
    }
  }

  return await awardXP({
    userId,
    amount: xpAmount,
    actionName,
    userRole,
    accuracyScore: 95,
  });
}

/**
 * Refactored Study Time XP tracker
 */
export async function trackStudyTimeXP({
  userId,
  sectionId,
  minutesWatched,
  userRole = "apprenant",
}: {
  userId: string;
  sectionId?: string;
  minutesWatched: number;
  userRole?: string;
}) {
  const xpAmount = Math.min(120, Math.round(minutesWatched * 4)); // 4 XP per minute
  const actionName = `Temps d'étude actif (${minutesWatched} min)`;

  // Save or update section progress in Supabase progress table
  if (userId && sectionId) {
    try {
      await supabase.from("progress").upsert({
        user_id: userId,
        section_id: sectionId,
        time_spent_seconds: Math.round(minutesWatched * 60),
        is_completed: true,
        last_accessed_at: new Date().toISOString(),
      });
    } catch (e) {
      console.warn("Could not save study progress:", e);
    }
  }

  return await awardXP({
    userId,
    amount: xpAmount,
    actionName,
    userRole,
    accuracyScore: 88,
  });
}

/**
 * Legacy compatibility wrapper for trackActivityXP
 */
export async function trackActivityXP({
  userId,
  type,
  value,
  title,
  userRole = "apprenant",
}: {
  userId: string;
  type: "quiz" | "watch_time" | "course_completed" | "question_asked";
  value: number;
  title?: string;
  userRole?: string;
}) {
  if (type === "quiz") {
    return trackQuizXP({ userId, score: value, maxScore: 100, userRole });
  } else if (type === "watch_time") {
    return trackStudyTimeXP({ userId, minutesWatched: value, userRole });
  } else if (type === "course_completed") {
    return trackCourseCompletionXP({ userId, courseTitle: title, userRole });
  } else {
    return awardXP({
      userId,
      amount: 20,
      actionName: "Interrogation pédagogique adressée à Auralis",
      userRole,
      accuracyScore: 88,
    });
  }
}
