import type { Tables } from "@/integrations/supabase/types";

// ─── Enums ──────────────────────────────────────────────────

export type UserRole = "apprenant" | "formateur" | "admin";

// ─── Domain types mapped to Supabase Row types ─────────────

export type Profile = Tables<"profiles">;
export type Course = Tables<"courses">;
export type Module = Tables<"modules">;
export type Section = Tables<"sections">;
export type Enrollment = Tables<"enrollments">;
export type Quiz = Tables<"quizzes">;
export type Question = Tables<"questions">;
export type QuizAttempt = Tables<"quiz_attempts">;
export type ForumPost = Tables<"forum_posts">;
export type Notification = Tables<"notifications">;
export type Message = Tables<"messages">;
export type Progress = Tables<"progress">;
export type Recommendation = Tables<"recommendations">;
export type LevelAssessment = Tables<"level_assessments">;
export type AuditLog = Tables<"audit_logs">;
