
-- Add unique constraint on pseudo to prevent duplicates
ALTER TABLE public.profiles ADD CONSTRAINT profiles_pseudo_unique UNIQUE (pseudo);

-- Update handle_new_user to use ON CONFLICT so re-login after profile deletion works
-- The trigger fires only on INSERT to auth.users, but we make it safe with ON CONFLICT
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
declare
  _role text;
  _has_explicit_role boolean;
  _pseudo text;
begin
  _has_explicit_role := (new.raw_user_meta_data->>'role') IS NOT NULL 
                        AND (new.raw_user_meta_data->>'role') IN ('apprenant', 'formateur');
  
  _role := CASE WHEN _has_explicit_role THEN new.raw_user_meta_data->>'role' ELSE 'apprenant' END;

  _pseudo := coalesce(
    new.raw_user_meta_data->>'pseudo',
    coalesce(new.raw_user_meta_data->>'name', split_part(new.email, '@', 1))
  );

  -- Ensure pseudo uniqueness by appending random suffix if needed
  WHILE EXISTS (SELECT 1 FROM public.profiles WHERE pseudo = _pseudo AND id != new.id) LOOP
    _pseudo := _pseudo || '_' || substr(gen_random_uuid()::text, 1, 4);
  END LOOP;

  INSERT INTO public.profiles (id, pseudo, prenom, nom, role, is_onboarded)
  VALUES (
    new.id,
    _pseudo,
    coalesce(new.raw_user_meta_data->>'prenom', coalesce(new.raw_user_meta_data->>'given_name', '')),
    coalesce(new.raw_user_meta_data->>'nom', coalesce(new.raw_user_meta_data->>'family_name', '')),
    _role,
    _has_explicit_role
  )
  ON CONFLICT (id) DO NOTHING;

  return new;
end;
$$;

-- Create a function to ensure profile exists (callable from client via RPC)
-- This handles the case where profile was deleted but auth.users still exists
CREATE OR REPLACE FUNCTION public.ensure_profile_exists()
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
declare
  _user_id uuid;
  _email text;
  _meta jsonb;
  _pseudo text;
  _profile public.profiles%ROWTYPE;
begin
  _user_id := auth.uid();
  IF _user_id IS NULL THEN
    RETURN json_build_object('error', 'Not authenticated');
  END IF;

  -- Check if profile already exists
  SELECT * INTO _profile FROM public.profiles WHERE id = _user_id;
  IF FOUND THEN
    RETURN json_build_object(
      'id', _profile.id,
      'role', _profile.role,
      'is_onboarded', _profile.is_onboarded,
      'exists', true
    );
  END IF;

  -- Profile doesn't exist, create it from auth.users metadata
  SELECT email, raw_user_meta_data INTO _email, _meta
  FROM auth.users WHERE id = _user_id;

  _pseudo := coalesce(
    _meta->>'pseudo',
    coalesce(_meta->>'name', split_part(_email, '@', 1))
  );

  -- Ensure pseudo uniqueness
  WHILE EXISTS (SELECT 1 FROM public.profiles WHERE pseudo = _pseudo) LOOP
    _pseudo := _pseudo || '_' || substr(gen_random_uuid()::text, 1, 4);
  END LOOP;

  INSERT INTO public.profiles (id, pseudo, prenom, nom, role, is_onboarded)
  VALUES (
    _user_id,
    _pseudo,
    coalesce(_meta->>'prenom', coalesce(_meta->>'given_name', '')),
    coalesce(_meta->>'nom', coalesce(_meta->>'family_name', '')),
    CASE 
      WHEN (_meta->>'role') IN ('apprenant', 'formateur') THEN _meta->>'role'
      ELSE 'apprenant'
    END,
    CASE 
      WHEN (_meta->>'role') IN ('apprenant', 'formateur') THEN true
      ELSE false
    END
  );

  SELECT * INTO _profile FROM public.profiles WHERE id = _user_id;
  
  RETURN json_build_object(
    'id', _profile.id,
    'role', _profile.role,
    'is_onboarded', _profile.is_onboarded,
    'exists', false
  );
end;
$$;
