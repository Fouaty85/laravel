
CREATE OR REPLACE FUNCTION public.complete_onboarding(_role text)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  _user_id uuid;
  _profile public.profiles%ROWTYPE;
BEGIN
  _user_id := auth.uid();
  IF _user_id IS NULL THEN
    RETURN json_build_object('error', 'Not authenticated');
  END IF;

  -- Validate role
  IF _role NOT IN ('apprenant', 'formateur') THEN
    RETURN json_build_object('error', 'Invalid role');
  END IF;

  -- Check profile exists
  SELECT * INTO _profile FROM public.profiles WHERE id = _user_id;
  IF NOT FOUND THEN
    RETURN json_build_object('error', 'Profile not found');
  END IF;

  -- Only allow if not yet onboarded
  IF _profile.is_onboarded THEN
    RETURN json_build_object('error', 'Already onboarded', 'role', _profile.role);
  END IF;

  -- Update role and mark as onboarded
  UPDATE public.profiles
  SET role = _role, is_onboarded = true
  WHERE id = _user_id;

  RETURN json_build_object(
    'id', _user_id,
    'role', _role,
    'is_onboarded', true
  );
END;
$$;
