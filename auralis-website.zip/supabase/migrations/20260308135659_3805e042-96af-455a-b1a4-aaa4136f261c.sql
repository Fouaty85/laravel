CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
begin
  insert into public.profiles (id, pseudo, prenom, nom, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'pseudo', coalesce(new.raw_user_meta_data->>'name', split_part(new.email, '@', 1))),
    coalesce(new.raw_user_meta_data->>'prenom', coalesce(new.raw_user_meta_data->>'given_name', '')),
    coalesce(new.raw_user_meta_data->>'nom', coalesce(new.raw_user_meta_data->>'family_name', '')),
    coalesce(new.raw_user_meta_data->>'role', 'apprenant')
  );
  return new;
end;
$$;