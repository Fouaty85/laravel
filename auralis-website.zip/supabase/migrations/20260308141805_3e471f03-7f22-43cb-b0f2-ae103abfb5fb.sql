
-- ═══ 1. MODULES: restrict SELECT to enrolled users or course formateur ═══
DROP POLICY IF EXISTS "Authenticated can view modules" ON public.modules;
CREATE POLICY "Enrolled or formateur can view modules"
  ON public.modules FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.courses c
      WHERE c.id = modules.course_id
        AND c.is_published = true
        AND (
          c.formateur_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM public.enrollments e
            WHERE e.course_id = c.id AND e.user_id = auth.uid()
          )
        )
    )
  );

-- ═══ 2. SECTIONS: restrict SELECT to enrolled users or course formateur ═══
DROP POLICY IF EXISTS "Authenticated can view sections" ON public.sections;
CREATE POLICY "Enrolled or formateur can view sections"
  ON public.sections FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.modules m
      JOIN public.courses c ON c.id = m.course_id
      WHERE m.id = sections.module_id
        AND c.is_published = true
        AND (
          c.formateur_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM public.enrollments e
            WHERE e.course_id = c.id AND e.user_id = auth.uid()
          )
        )
    )
  );

-- ═══ 3. QUIZZES: restrict SELECT to enrolled users or course formateur ═══
DROP POLICY IF EXISTS "Authenticated can view quizzes" ON public.quizzes;
CREATE POLICY "Enrolled or formateur can view quizzes"
  ON public.quizzes FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.courses c
      WHERE c.id = quizzes.course_id
        AND c.is_published = true
        AND (
          c.formateur_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM public.enrollments e
            WHERE e.course_id = c.id AND e.user_id = auth.uid()
          )
        )
    )
  );

-- ═══ 4. PROFILES: restrict formateur visibility to authenticated only ═══
DROP POLICY IF EXISTS "Voir profils formateurs" ON public.profiles;
CREATE POLICY "Voir profils formateurs"
  ON public.profiles FOR SELECT TO authenticated
  USING (role = 'formateur');

-- ═══ 5. AUDIT_LOGS: remove direct INSERT, create SECURITY DEFINER function ═══
DROP POLICY IF EXISTS "Authenticated users can insert audit logs" ON public.audit_logs;

CREATE OR REPLACE FUNCTION public.create_audit_log(
  _action text,
  _resource_type text DEFAULT NULL,
  _resource_id uuid DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.audit_logs (user_id, action, resource_type, resource_id)
  VALUES (auth.uid(), _action, _resource_type, _resource_id);
END;
$$;

-- ═══ 6. Harden quiz RPC functions with enrollment checks ═══
CREATE OR REPLACE FUNCTION public.get_quiz_questions(_quiz_id uuid)
RETURNS TABLE (
  id uuid,
  quiz_id uuid,
  texte text,
  type text,
  ordre integer,
  points integer,
  options jsonb
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _course_id uuid;
BEGIN
  -- Get course_id for this quiz
  SELECT q.course_id INTO _course_id FROM public.quizzes q WHERE q.id = _quiz_id;

  -- Check: user must be enrolled OR be the formateur, AND course must be published
  IF NOT EXISTS (
    SELECT 1 FROM public.courses c
    WHERE c.id = _course_id
      AND c.is_published = true
      AND (
        c.formateur_id = auth.uid()
        OR EXISTS (SELECT 1 FROM public.enrollments e WHERE e.course_id = c.id AND e.user_id = auth.uid())
      )
  ) THEN
    RAISE EXCEPTION 'Access denied: not enrolled or course not published';
  END IF;

  RETURN QUERY
    SELECT q.id, q.quiz_id, q.texte, q.type, q.ordre, q.points, q.options
    FROM public.questions q
    WHERE q.quiz_id = _quiz_id
    ORDER BY q.ordre;
END;
$$;

CREATE OR REPLACE FUNCTION public.validate_quiz_answers(
  _quiz_id uuid,
  _answers jsonb
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _course_id uuid;
  _score integer := 0;
  _max_score integer := 0;
  _seuil integer;
  _results jsonb := '[]'::jsonb;
  _item jsonb;
  _q record;
  _user_answer text;
  _is_correct boolean;
BEGIN
  -- Get course_id
  SELECT q.course_id INTO _course_id FROM public.quizzes q WHERE q.id = _quiz_id;

  -- Enrollment / publication check
  IF NOT EXISTS (
    SELECT 1 FROM public.courses c
    WHERE c.id = _course_id
      AND c.is_published = true
      AND (
        c.formateur_id = auth.uid()
        OR EXISTS (SELECT 1 FROM public.enrollments e WHERE e.course_id = c.id AND e.user_id = auth.uid())
      )
  ) THEN
    RAISE EXCEPTION 'Access denied: not enrolled or course not published';
  END IF;

  SELECT coalesce(seuil_reussite, 60) INTO _seuil FROM public.quizzes WHERE id = _quiz_id;

  FOR _item IN SELECT * FROM jsonb_array_elements(_answers)
  LOOP
    SELECT * INTO _q FROM public.questions
    WHERE questions.id = (_item->>'question_id')::uuid AND questions.quiz_id = _quiz_id;

    IF _q IS NULL THEN CONTINUE; END IF;

    _user_answer := _item->>'answer';
    _is_correct := lower(trim(_user_answer)) = lower(trim(_q.correct_answer));
    _max_score := _max_score + coalesce(_q.points, 1);

    IF _is_correct THEN
      _score := _score + coalesce(_q.points, 1);
    END IF;

    _results := _results || jsonb_build_object(
      'question_id', _q.id,
      'correct', _is_correct,
      'explication', _q.explication
    );
  END LOOP;

  RETURN jsonb_build_object(
    'score', _score,
    'max_score', _max_score,
    'passed', CASE WHEN _max_score > 0 THEN (_score * 100 / _max_score) >= _seuil ELSE false END,
    'results', _results
  );
END;
$$;
