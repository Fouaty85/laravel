
-- Add is_onboarded flag to profiles
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_onboarded boolean NOT NULL DEFAULT false;

-- Update existing profiles to be onboarded (they already have roles)
UPDATE public.profiles SET is_onboarded = true;

-- Update the trigger to set is_onboarded = true when role is explicitly provided via metadata
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
declare
  _role text;
  _has_explicit_role boolean;
begin
  _has_explicit_role := (new.raw_user_meta_data->>'role') IS NOT NULL 
                        AND (new.raw_user_meta_data->>'role') IN ('apprenant', 'formateur');
  
  _role := CASE WHEN _has_explicit_role THEN new.raw_user_meta_data->>'role' ELSE 'apprenant' END;

  insert into public.profiles (id, pseudo, prenom, nom, role, is_onboarded)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'pseudo', coalesce(new.raw_user_meta_data->>'name', split_part(new.email, '@', 1))),
    coalesce(new.raw_user_meta_data->>'prenom', coalesce(new.raw_user_meta_data->>'given_name', '')),
    coalesce(new.raw_user_meta_data->>'nom', coalesce(new.raw_user_meta_data->>'family_name', '')),
    _role,
    _has_explicit_role
  );
  return new;
end;
$function$;
