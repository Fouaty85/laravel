
-- 1. Harden handle_new_user trigger: validate role server-side
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
declare
  _role text;
begin
  -- Only allow known roles; default to 'apprenant'
  _role := coalesce(new.raw_user_meta_data->>'role', 'apprenant');
  if _role not in ('apprenant', 'formateur') then
    _role := 'apprenant';
  end if;

  insert into public.profiles (id, pseudo, prenom, nom, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'pseudo', coalesce(new.raw_user_meta_data->>'name', split_part(new.email, '@', 1))),
    coalesce(new.raw_user_meta_data->>'prenom', coalesce(new.raw_user_meta_data->>'given_name', '')),
    coalesce(new.raw_user_meta_data->>'nom', coalesce(new.raw_user_meta_data->>'family_name', '')),
    _role
  );
  return new;
end;
$$;

-- 2. Replace the profile UPDATE policy to prevent role self-modification
DROP POLICY IF EXISTS "Modifier son propre profil" ON public.profiles;

CREATE POLICY "Modifier son propre profil"
  ON public.profiles FOR UPDATE TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id AND role = (SELECT p.role FROM public.profiles p WHERE p.id = auth.uid()));
