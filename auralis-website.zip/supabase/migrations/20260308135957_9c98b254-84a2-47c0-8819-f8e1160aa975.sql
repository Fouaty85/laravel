-- Helper function: get role without recursive RLS
CREATE OR REPLACE FUNCTION public.get_user_role(_user_id uuid)
RETURNS text
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role FROM public.profiles WHERE id = _user_id LIMIT 1;
$$;

-- ═══ AUDIT_LOGS: only admins read, system inserts ═══
CREATE POLICY "Authenticated users can insert audit logs"
  ON public.audit_logs FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view own audit logs"
  ON public.audit_logs FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

-- ═══ FORUM_POSTS ═══
CREATE POLICY "Authenticated can view forum posts"
  ON public.forum_posts FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Authenticated can create forum posts"
  ON public.forum_posts FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own forum posts"
  ON public.forum_posts FOR UPDATE TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own forum posts"
  ON public.forum_posts FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

-- ═══ LEVEL_ASSESSMENTS ═══
CREATE POLICY "Users can view own assessments"
  ON public.level_assessments FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own assessments"
  ON public.level_assessments FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- ═══ MODULES: readable by authenticated, managed by course formateur ═══
CREATE POLICY "Authenticated can view modules"
  ON public.modules FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Formateur can manage own course modules"
  ON public.modules FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.courses
      WHERE courses.id = modules.course_id
        AND courses.formateur_id = auth.uid()
    )
  );

-- ═══ SECTIONS: readable by authenticated, managed by course formateur ═══
CREATE POLICY "Authenticated can view sections"
  ON public.sections FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Formateur can manage own course sections"
  ON public.sections FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.modules
      JOIN public.courses ON courses.id = modules.course_id
      WHERE modules.id = sections.module_id
        AND courses.formateur_id = auth.uid()
    )
  );

-- ═══ QUIZZES: readable by authenticated, managed by course formateur ═══
CREATE POLICY "Authenticated can view quizzes"
  ON public.quizzes FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Formateur can manage own course quizzes"
  ON public.quizzes FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.courses
      WHERE courses.id = quizzes.course_id
        AND courses.formateur_id = auth.uid()
    )
  );

-- ═══ QUESTIONS: readable by authenticated, managed by quiz owner ═══
CREATE POLICY "Authenticated can view questions"
  ON public.questions FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Formateur can manage own quiz questions"
  ON public.questions FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.quizzes
      JOIN public.courses ON courses.id = quizzes.course_id
      WHERE quizzes.id = questions.quiz_id
        AND courses.formateur_id = auth.uid()
    )
  );

-- ═══ QUIZ_ATTEMPTS ═══
CREATE POLICY "Users can view own quiz attempts"
  ON public.quiz_attempts FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own quiz attempts"
  ON public.quiz_attempts FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- ═══ RECOMMENDATIONS ═══
CREATE POLICY "Users can view own recommendations"
  ON public.recommendations FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own recommendations"
  ON public.recommendations FOR UPDATE TO authenticated
  USING (auth.uid() = user_id);

-- ═══ ENROLLMENTS: add missing UPDATE policy ═══
CREATE POLICY "Mettre à jour ses inscriptions"
  ON public.enrollments FOR UPDATE TO authenticated
  USING (auth.uid() = user_id);

-- ═══ MESSAGES: add UPDATE for marking as read ═══
CREATE POLICY "Marquer messages comme lus"
  ON public.messages FOR UPDATE TO authenticated
  USING (auth.uid() = receiver_id);