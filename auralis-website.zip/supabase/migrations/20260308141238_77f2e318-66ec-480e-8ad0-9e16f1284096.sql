
-- 1. Drop the overly permissive SELECT policy on questions
DROP POLICY IF EXISTS "Authenticated can view questions" ON public.questions;

-- 2. Create a SELECT policy that only lets the course formateur see all columns (including correct_answer)
CREATE POLICY "Formateur can view all question data"
  ON public.questions FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.quizzes
      JOIN public.courses ON courses.id = quizzes.course_id
      WHERE quizzes.id = questions.quiz_id
        AND courses.formateur_id = auth.uid()
    )
  );

-- 3. Create a SECURITY DEFINER function to get questions WITHOUT correct answers
CREATE OR REPLACE FUNCTION public.get_quiz_questions(_quiz_id uuid)
RETURNS TABLE (
  id uuid,
  quiz_id uuid,
  texte text,
  type text,
  ordre integer,
  points integer,
  options jsonb
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT q.id, q.quiz_id, q.texte, q.type, q.ordre, q.points, q.options
  FROM public.questions q
  WHERE q.quiz_id = _quiz_id
  ORDER BY q.ordre;
$$;

-- 4. Create a SECURITY DEFINER function to validate answers server-side
CREATE OR REPLACE FUNCTION public.validate_quiz_answers(
  _quiz_id uuid,
  _answers jsonb -- expects: [{"question_id": "uuid", "answer": "text"}, ...]
)
RETURNS jsonb -- returns: {"score": N, "max_score": N, "passed": bool, "results": [...]}
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _score integer := 0;
  _max_score integer := 0;
  _seuil integer;
  _results jsonb := '[]'::jsonb;
  _item jsonb;
  _q record;
  _user_answer text;
  _is_correct boolean;
BEGIN
  -- Get passing threshold
  SELECT coalesce(seuil_reussite, 60) INTO _seuil FROM public.quizzes WHERE id = _quiz_id;

  -- Iterate over submitted answers
  FOR _item IN SELECT * FROM jsonb_array_elements(_answers)
  LOOP
    SELECT * INTO _q FROM public.questions
    WHERE id = (_item->>'question_id')::uuid AND quiz_id = _quiz_id;

    IF _q IS NULL THEN CONTINUE; END IF;

    _user_answer := _item->>'answer';
    _is_correct := lower(trim(_user_answer)) = lower(trim(_q.correct_answer));
    _max_score := _max_score + coalesce(_q.points, 1);

    IF _is_correct THEN
      _score := _score + coalesce(_q.points, 1);
    END IF;

    _results := _results || jsonb_build_object(
      'question_id', _q.id,
      'correct', _is_correct,
      'explication', _q.explication
    );
  END LOOP;

  RETURN jsonb_build_object(
    'score', _score,
    'max_score', _max_score,
    'passed', CASE WHEN _max_score > 0 THEN (_score * 100 / _max_score) >= _seuil ELSE false END,
    'results', _results
  );
END;
$$;
