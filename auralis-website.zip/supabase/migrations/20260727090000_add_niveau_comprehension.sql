-- Add niveau_comprehension column to profiles table if it doesn't exist
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS niveau_comprehension text DEFAULT '75% - Notion Assimilée';

-- Ensure default values
ALTER TABLE public.profiles ALTER COLUMN points SET DEFAULT 0;

UPDATE public.profiles SET niveau_global = 'Niveau 1' WHERE niveau_global IS NULL;
UPDATE public.profiles SET niveau_comprehension = '75% - Notion Assimilée' WHERE niveau_comprehension IS NULL;

-- Enable Realtime for profiles table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables 
    WHERE pubname = 'supabase_realtime' AND tablename = 'profiles'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.profiles;
  END IF;
END $$;
