import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";

export { supabase };

// ─── Auth Helpers ───────────────────────────────────────────

export async function signUpWithEmail({
  email,
  password,
  pseudo,
  prenom,
  nom,
  role,
}: {
  email: string;
  password: string;
  pseudo: string;
  prenom: string;
  nom: string;
  role: "apprenant" | "formateur";
}) {
  return supabase.auth.signUp({
    email,
    password,
    options: {
      data: { pseudo, prenom, nom, role },
      emailRedirectTo: window.location.origin,
    },
  });
}

export async function signInWithEmail(email: string, password: string) {
  return supabase.auth.signInWithPassword({ email, password });
}

function isEmbeddedPreview() {
  try {
    return window.self !== window.top;
  } catch {
    return true;
  }
}

function isTrustedOAuthOrigin(origin: string) {
  if (origin === window.location.origin) return true;
  try {
    const host = new URL(origin).hostname;
    return host.endsWith("lovable.app") || host.endsWith("lovableproject.com");
  } catch {
    return false;
  }
}

async function oauthWithPopup(provider: "google" | "azure", scopes?: string) {
  const callbackUrl = `${window.location.origin}/oauth-callback.html`;
  const options: Record<string, unknown> = {
    redirectTo: callbackUrl,
    skipBrowserRedirect: true,
  };
  if (scopes) options.scopes = scopes;

  const { data, error } = await supabase.auth.signInWithOAuth({
    provider,
    options,
  });

  if (error) return { data: null, error };

  if (data?.url) {
    const popup = window.open(data.url, "oauth-popup", "width=500,height=650");
    if (!popup) {
      return {
        data: null,
        error: { message: "Veuillez autoriser les popups pour ce site puis réessayez." } as unknown as { message: string },
      };
    }

    return new Promise<{ data: { url: string | null } | null; error: { message: string } | null }>((resolve) => {
      let resolved = false;

      const cleanup = () => {
        window.removeEventListener("message", messageHandler);
        clearInterval(interval);
      };

      const finalize = async (params: { oauthCode?: string | null; hash?: string | null }) => {
        if (resolved) return;
        resolved = true;

        const oauthCode = params.oauthCode ?? null;
        const hash = params.hash ?? "";

        if (oauthCode) {
          const { error: exchangeError } = await supabase.auth.exchangeCodeForSession(oauthCode);
          if (exchangeError) {
            cleanup();
            resolve({ data: null, error: exchangeError });
            return;
          }
        } else if (hash.includes("access_token=") && hash.includes("refresh_token=")) {
          const hashParams = new URLSearchParams(hash.replace(/^#/, ""));
          const access_token = hashParams.get("access_token");
          const refresh_token = hashParams.get("refresh_token");

          if (access_token && refresh_token) {
            const { error: setSessionError } = await supabase.auth.setSession({ access_token, refresh_token });
            if (setSessionError) {
              cleanup();
              resolve({ data: null, error: setSessionError });
              return;
            }
          }
        }

        cleanup();
        try {
          popup.close();
        } catch (err) {
          console.debug("Popup close error", err);
        }

        resolve({ data: { url: null }, error: null });
      };

      const messageHandler = (event: MessageEvent) => {
        if (!isTrustedOAuthOrigin(event.origin)) return;
        if (event.data?.type !== "oauth-complete") return;

        const oauthError = event.data?.error || event.data?.errorDescription;
        if (oauthError) {
          cleanup();
          resolve({ data: null, error: { message: String(oauthError) } });
          return;
        }

        void finalize({ oauthCode: event.data?.code ?? null, hash: event.data?.hash ?? "" });
      };

      window.addEventListener("message", messageHandler);

      // Fallback if message is blocked: try reading current session once popup closes
      const interval = setInterval(async () => {
        if (!popup.closed || resolved) return;
        const { data: sessionData } = await supabase.auth.getSession();
        cleanup();
        if (sessionData.session) {
          resolve({ data: { url: null }, error: null });
          return;
        }
        resolve({ data: null, error: { message: "Authentification OAuth incomplète. Réessayez." } as unknown as { message: string } });
      }, 500);
    });
  }

  return { data, error: null };
}

export async function signInWithGoogle() {
  if (isEmbeddedPreview()) {
    return oauthWithPopup("google");
  }
  return supabase.auth.signInWithOAuth({
    provider: "google",
    options: { redirectTo: window.location.origin },
  });
}

export async function signInWithMicrosoft() {
  if (isEmbeddedPreview()) {
    return oauthWithPopup("azure", "email profile openid");
  }
  return supabase.auth.signInWithOAuth({
    provider: "azure",
    options: {
      redirectTo: window.location.origin,
      scopes: "email profile openid",
    },
  });
}

export async function signOut() {
  return supabase.auth.signOut();
}

export async function getUserProfile(userId: string) {
  return supabase
    .from("profiles")
    .select("*")
    .eq("id", userId)
    .single();
}

// ─── Error message mapping (FR) ────────────────────────────

const ERROR_MESSAGES: Record<string, string> = {
  "Invalid login credentials": "Email ou mot de passe incorrect.",
  "Email not confirmed": "Veuillez confirmer votre email avant de vous connecter.",
  "User already registered": "Un compte avec cet email existe déjà.",
  "Password should be at least 6 characters": "Le mot de passe doit contenir au moins 6 caractères.",
  "Email rate limit exceeded": "Trop de tentatives. Réessayez dans quelques minutes.",
  "Signup requires a valid password": "Veuillez entrer un mot de passe valide.",
};

export function translateAuthError(message: string): string {
  const normalized = message.toLowerCase();
  for (const [key, value] of Object.entries(ERROR_MESSAGES)) {
    if (key.toLowerCase() === normalized) return value;
  }
  return message;
}
