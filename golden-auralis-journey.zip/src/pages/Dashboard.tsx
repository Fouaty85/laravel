import { useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { BookOpen, Clock, Trophy, Flame, Star, TrendingUp, Sparkles } from "lucide-react";
import { motion } from "framer-motion";
import StatCard from "@/components/dashboard/StatCard";
import CourseCard from "@/components/dashboard/CourseCard";
import RecommendationCard from "@/components/dashboard/RecommendationCard";
import { useAvatarScenario } from "@/hooks/useAvatarScenario";

interface CourseType {
  titre?: string | null;
  image_url?: string | null;
  niveau?: string | null;
  duree_minutes?: number | null;
  description?: string | null;
}

export default function Dashboard() {
  const { profile, user } = useAuth();
  const { scenarioDashboardApprenant } = useAvatarScenario();

  const { data: enrollments } = useQuery({
    queryKey: ["enrollments", user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("enrollments")
        .select("*, courses(*)")
        .eq("user_id", user!.id)
        .order("enrolled_at", { ascending: false });
      return data ?? [];
    },
    enabled: !!user,
  });

  const { data: recommendations } = useQuery({
    queryKey: ["recommendations", user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("recommendations")
        .select("*, courses(*)")
        .eq("user_id", user!.id)
        .eq("is_dismissed", false)
        .order("score_confiance", { ascending: false })
        .limit(6);
      return data ?? [];
    },
    enabled: !!user,
  });

  const { data: progressData } = useQuery({
    queryKey: ["progress-stats", user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("progress")
        .select("*")
        .eq("user_id", user!.id);
      return data ?? [];
    },
    enabled: !!user,
  });

  const completedSections = progressData?.filter((p) => p.is_completed).length ?? 0;
  const totalTimeMinutes = Math.round(
    (progressData?.reduce((sum, p) => sum + (p.time_spent_seconds ?? 0), 0) ?? 0) / 60
  );
  const coursesInProgress = enrollments?.filter((e) => !e.completed_at) ?? [];
  const coursesCompleted = enrollments?.filter((e) => e.completed_at).length ?? 0;

  const levelLabel: Record<string, string> = {
    debutant: "Débutant",
    intermediaire: "Intermédiaire",
    avance: "Avancé",
    expert: "Expert",
  };

  // Play Auralis scenario on mount
  useEffect(() => {
    if (profile?.prenom) {
      const alreadyGreeted = localStorage.getItem("auralis_dashboard_greeted");
      if (alreadyGreeted === "true") return;

      // Little delay to let the app finish loading
      const t = setTimeout(() => {
        scenarioDashboardApprenant(profile.prenom, coursesInProgress.length);
        localStorage.setItem("auralis_dashboard_greeted", "true");
      }, 1200);
      return () => clearTimeout(t);
    }
  }, [profile?.prenom, coursesInProgress.length, scenarioDashboardApprenant]);

  return (
    <div className="w-full min-h-screen pb-16">
      {/* Top bar (Sticky) */}
      <header className="sticky top-0 z-40 h-16 border-b border-border/50 bg-background/80 backdrop-blur-md flex items-center px-8 justify-between">
        <div>
          <h1 className="text-lg font-semibold text-foreground font-[Space_Grotesk]">
            Tableau de bord
          </h1>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <p className="text-sm font-medium text-foreground">
              {profile?.prenom} {profile?.nom}
            </p>
            <p className="text-[11px] text-muted-foreground">
              {levelLabel[profile?.niveau_global ?? "debutant"] ?? "Débutant"}
            </p>
          </div>
          <div className="w-9 h-9 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-sm">
            {profile?.prenom?.charAt(0)?.toUpperCase() ?? "A"}
          </div>
        </div>
      </header>

      <div className="p-8 space-y-8 max-w-7xl mx-auto">
        {/* Welcome message */}
        <motion.section
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <h2 className="text-3xl font-bold text-foreground font-[Space_Grotesk]">
            Bonjour, <span className="text-primary">{profile?.prenom ?? "Apprenant"}</span> 👋
          </h2>
          <p className="text-muted-foreground mt-1">
            Continuez votre apprentissage là où vous l'avez laissé.
          </p>
        </motion.section>

        {/* Stats Grid */}
        <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            icon={<BookOpen size={20} />}
            label="Cours en cours"
            value={coursesInProgress.length}
            delay={0}
          />
          <StatCard
            icon={<Trophy size={20} />}
            label="Cours terminés"
            value={coursesCompleted}
            delay={0.05}
          />
          <StatCard
            icon={<Clock size={20} />}
            label="Temps d'étude"
            value={totalTimeMinutes > 60 ? `${Math.floor(totalTimeMinutes / 60)}h${totalTimeMinutes % 60}` : `${totalTimeMinutes}min`}
            subtitle={`${completedSections} sections complétées`}
            delay={0.1}
          />
          <StatCard
            icon={<Flame size={20} />}
            label="Streak"
            value={`${profile?.streak_jours ?? 0} jours`}
            subtitle={`${profile?.points ?? 0} points`}
            delay={0.15}
          />
        </section>

        {/* Level & Points Banner */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.2 }}
          className="glass-card rounded-2xl p-6"
        >
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
            <div className="flex items-center gap-4 flex-1">
              <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center">
                <Star size={28} className="text-primary" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider">Niveau global</p>
                <p className="text-xl font-bold text-foreground font-[Space_Grotesk]">
                  {levelLabel[profile?.niveau_global ?? "debutant"] ?? profile?.niveau_global}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4 flex-1">
              <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center">
                <TrendingUp size={28} className="text-primary" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider">Points totaux</p>
                <p className="text-xl font-bold text-foreground font-[Space_Grotesk]">
                  {profile?.points ?? 0}
                  <span className="text-sm text-muted-foreground ml-1">pts</span>
                </p>
              </div>
            </div>
          </div>
        </motion.section>

        {/* Active courses */}
        <section>
          <div className="flex items-center justify-between mb-5">
            <h3 className="text-xl font-semibold text-foreground font-[Space_Grotesk]">
              Mes cours en cours
            </h3>
            {coursesInProgress.length > 0 && (
              <span className="text-xs text-muted-foreground">
                {coursesInProgress.length} cours
              </span>
            )}
          </div>
          {coursesInProgress.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="glass-card rounded-2xl p-10 text-center"
            >
              <BookOpen size={44} className="mx-auto text-muted-foreground/40 mb-4" />
              <p className="text-foreground font-medium">Aucun cours en cours</p>
              <p className="text-sm text-muted-foreground mt-1">
                Explorez les recommandations ci-dessous pour commencer.
              </p>
            </motion.div>
          ) : (
            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-5">
              {coursesInProgress.map((enrollment, i) => {
                const course = enrollment.courses as unknown as CourseType;
                return (
                  <CourseCard
                    key={enrollment.id}
                    title={course?.titre ?? "Cours"}
                    imageUrl={course?.image_url}
                    niveau={course?.niveau}
                    progression={enrollment.progression ?? 0}
                    adjustedLevel={enrollment.adjusted_level}
                    dureeMinutes={course?.duree_minutes}
                    delay={i * 0.05}
                  />
                );
              })}
            </div>
          )}
        </section>

        {/* Personalized recommendations */}
        <section>
          <div className="flex items-center gap-2 mb-5">
            <Sparkles size={18} className="text-primary" />
            <h3 className="text-xl font-semibold text-foreground font-[Space_Grotesk]">
              Recommandés pour vous
            </h3>
          </div>
          {recommendations?.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="glass-card rounded-2xl p-10 text-center"
            >
              <Sparkles size={44} className="mx-auto text-muted-foreground/40 mb-4" />
              <p className="text-foreground font-medium">Aucune recommandation</p>
              <p className="text-sm text-muted-foreground mt-1">
                Les recommandations apparaîtront au fur et à mesure de votre apprentissage.
              </p>
            </motion.div>
          ) : (
            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-5">
              {recommendations?.map((rec, i) => {
                const course = rec.courses as unknown as CourseType;
                return (
                  <RecommendationCard
                    key={rec.id}
                    title={course?.titre ?? "Cours"}
                    description={course?.description}
                    imageUrl={course?.image_url}
                    niveau={course?.niveau}
                    scoreConfiance={rec.score_confiance}
                    reason={rec.reason}
                    delay={i * 0.05}
                  />
                );
              })}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
