import { useState, useEffect, useCallback } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { motion } from "framer-motion";
import {
  BookOpen,
  Trophy,
  MessageSquare,
  Bell,
  PlusCircle,
  Play,
  Sparkles,
  Send,
  Check,
  ChevronRight,
  Flame,
  Search,
  BookMarked,
  Users
} from "lucide-react";
import { toast } from "sonner";
import type { Profile, Course, Enrollment } from "@/types";

type EnrollmentWithCourse = Enrollment & { courses: Course | null };

interface LocalMessage {
  id: string;
  sender_id: string | undefined;
  sender_name: string;
  content: string;
  created_at: string;
}

interface LocalNotification {
  id: string;
  title: string;
  message: string;
  date: string;
  unread: boolean;
}

// ============================================================================
// 1. MES COURS (Learner / Apprenant Course Browser & Enrollments)
// ============================================================================
export function MesCours() {
  const { user } = useAuth();
  const [enrolled, setEnrolled] = useState<EnrollmentWithCourse[]>([]);
  const [allCourses, setAllCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");

  const fetchCourses = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      // 1. Fetch current enrollments
      const { data: enrollData } = await supabase
        .from("enrollments")
        .select("*, courses(*)")
        .eq("profile_id", user.id);

      // 2. Fetch all available courses
      const { data: courseData } = await supabase
        .from("courses")
        .select("*");

      if (enrollData) {
        setEnrolled(enrollData as EnrollmentWithCourse[]);
      }
      if (courseData) {
        setAllCourses(courseData as Course[]);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    fetchCourses();
  }, [fetchCourses]);

  const handleEnroll = async (courseId: string) => {
    if (!user) return;
    try {
      const { error } = await supabase
        .from("enrollments")
        .insert([{ profile_id: user.id, course_id: courseId, progression: 0 }]);

      if (error) throw error;
      toast.success("Inscription au cours réussie !");
      fetchCourses();
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : String(err);
      toast.error("Erreur lors de l'inscription: " + errorMsg);
    }
  };

  const filteredAllCourses = allCourses.filter(c =>
    c.titre.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-7xl mx-auto text-white">
      <div>
        <h1 className="text-3xl font-extrabold text-white tracking-tight font-[Space_Grotesk]">
          Espace d'Apprentissage
        </h1>
        <p className="text-gray-400 text-sm mt-1">
          Explorez nos cours ou continuez vos apprentissages en cours.
        </p>
      </div>

      {/* Mes Cours en Cours */}
      {enrolled.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-xl font-bold flex items-center gap-2 text-[#D4AF37]">
            <BookMarked size={20} /> Vos cours en cours
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {enrolled.map((enroll) => (
              <motion.div
                key={enroll.id}
                whileHover={{ y: -4 }}
                className="bg-[#161616] border border-white/5 rounded-2xl overflow-hidden shadow-lg p-5 flex flex-col justify-between"
              >
                <div>
                  <span className="text-[10px] uppercase font-bold text-[#D4AF37] px-2 py-1 bg-[#D4AF37]/10 rounded-full">
                    {enroll.courses?.langue || "Général"}
                  </span>
                  <h3 className="font-bold text-lg text-white mt-3 line-clamp-1">
                    {enroll.courses?.titre}
                  </h3>
                  <p className="text-gray-400 text-xs mt-1.5 line-clamp-2">
                    {enroll.courses?.description}
                  </p>
                </div>
                <div className="mt-5 space-y-3">
                  <div className="flex items-center justify-between text-xs text-gray-400">
                    <span>Progression</span>
                    <span className="font-semibold text-white">{enroll.progression}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-[#D4AF37] to-[#F0C940] rounded-full transition-all duration-500"
                      style={{ width: `${enroll.progression}%` }}
                    />
                  </div>
                  <button className="w-full flex items-center justify-center gap-2 py-2 bg-white/5 hover:bg-white/10 rounded-xl text-xs font-semibold text-white border border-white/10 transition-colors">
                    <Play size={12} className="fill-white" /> Continuer l'apprentissage
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* Catalogue des Cours */}
      <div className="space-y-6 pt-4 border-t border-white/5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <BookOpen size={20} className="text-[#D4AF37]" /> Catalogue de cours
          </h2>
          <div className="relative w-full md:w-80">
            <Search className="absolute left-3 top-2.5 text-gray-500" size={16} />
            <input
              type="text"
              placeholder="Rechercher un cours..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#111] border border-white/10 focus:border-[#D4AF37]/40 rounded-xl py-2 pl-9 pr-4 text-xs text-white placeholder-gray-500 outline-none transition-all"
            />
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-2 border-[#D4AF37]/20 border-t-[#D4AF37] animate-spin rounded-full" />
          </div>
        ) : filteredAllCourses.length === 0 ? (
          <div className="text-center py-16 bg-[#111] rounded-2xl border border-white/5">
            <p className="text-gray-500 text-sm">Aucun cours disponible.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAllCourses.map((course) => {
              const isEnrolled = enrolled.some(e => e.course_id === course.id);
              return (
                <div
                  key={course.id}
                  className="bg-[#111] border border-white/5 rounded-2xl p-5 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] uppercase font-bold text-[#D4AF37] px-2.5 py-1 bg-[#D4AF37]/10 rounded-full">
                        {course.langue}
                      </span>
                      <span className="text-[11px] text-gray-500 font-medium">
                        Niveau: {course.niveau_cible}
                      </span>
                    </div>
                    <h3 className="font-bold text-lg text-white mt-3">{course.titre}</h3>
                    <p className="text-gray-400 text-xs mt-2 line-clamp-3 leading-relaxed">
                      {course.description}
                    </p>
                  </div>
                  <div className="mt-6">
                    {isEnrolled ? (
                      <div className="flex items-center justify-center gap-1.5 py-2.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-xl text-xs font-bold">
                        <Check size={14} /> Déjà inscrit
                      </div>
                    ) : (
                      <button
                        onClick={() => handleEnroll(course.id)}
                        className="w-full py-2.5 bg-gradient-to-r from-[#D4AF37] to-[#F0C940] hover:scale-[1.02] active:scale-[0.98] text-[#0A0A0A] rounded-xl text-xs font-bold transition-all shadow-lg shadow-[#D4AF37]/5"
                      >
                        S'inscrire au cours
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================================================
// 2. CLASSEMENT (Durable leaderboard querying profile table desc)
// ============================================================================
export function Classement() {
  const { profile } = useAuth();
  const [leaders, setLeaders] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLeaderboard = async () => {
      try {
        const { data } = await supabase
          .from("profiles")
          .select("*")
          .order("points", { ascending: false })
          .limit(10);
        if (data) {
          setLeaders(data as Profile[]);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchLeaderboard();
  }, []);

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-4xl mx-auto text-white">
      <div>
        <h1 className="text-3xl font-extrabold tracking-tight font-[Space_Grotesk]">
          Classement de l'Académie
        </h1>
        <p className="text-gray-400 text-sm mt-1">
          Mesurez-vous aux meilleurs apprenants d'Auralis. Accumulez des points pour grimper !
        </p>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-2 border-[#D4AF37]/20 border-t-[#D4AF37] animate-spin rounded-full" />
        </div>
      ) : (
        <div className="space-y-4">
          {/* Top 3 Cards visual podium */}
          <div className="grid grid-cols-3 gap-4 items-end pb-4 pt-2">
            {/* 2nd Place */}
            {leaders[1] && (
              <div className="bg-[#111]/80 border border-white/5 rounded-2xl p-4 flex flex-col items-center justify-center text-center h-[160px] relative">
                <div className="absolute -top-4 w-8 h-8 rounded-full bg-slate-300 text-black font-bold flex items-center justify-center text-sm shadow-md">2</div>
                <div className="w-10 h-10 rounded-full bg-slate-300/20 text-slate-300 flex items-center justify-center text-base font-bold">
                  {leaders[1].prenom?.charAt(0) || "U"}
                </div>
                <span className="font-bold text-xs mt-2 text-white truncate max-w-full">{leaders[1].prenom}</span>
                <span className="text-[10px] text-[#D4AF37] font-semibold mt-1">{leaders[1].points || 0} pts</span>
              </div>
            )}

            {/* 1st Place */}
            {leaders[0] && (
              <div className="bg-[#161616] border border-[#D4AF37]/30 rounded-2xl p-4 flex flex-col items-center justify-center text-center h-[180px] relative shadow-xl shadow-[#D4AF37]/5">
                <div className="absolute -top-5 w-10 h-10 rounded-full bg-[#D4AF37] text-black font-bold flex items-center justify-center text-base shadow-lg animate-bounce">👑</div>
                <div className="w-12 h-12 rounded-full bg-[#D4AF37]/20 text-[#D4AF37] flex items-center justify-center text-lg font-bold border border-[#D4AF37]/40">
                  {leaders[0].prenom?.charAt(0) || "U"}
                </div>
                <span className="font-bold text-sm mt-2 text-white truncate max-w-full">{leaders[0].prenom}</span>
                <span className="text-xs text-[#D4AF37] font-bold mt-1 flex items-center gap-1">
                  <Sparkles size={12} /> {leaders[0].points || 0} pts
                </span>
              </div>
            )}

            {/* 3rd Place */}
            {leaders[2] && (
              <div className="bg-[#111]/80 border border-white/5 rounded-2xl p-4 flex flex-col items-center justify-center text-center h-[140px] relative">
                <div className="absolute -top-4 w-8 h-8 rounded-full bg-amber-700 text-white font-bold flex items-center justify-center text-sm shadow-md">3</div>
                <div className="w-10 h-10 rounded-full bg-amber-700/20 text-amber-500 flex items-center justify-center text-base font-bold">
                  {leaders[2].prenom?.charAt(0) || "U"}
                </div>
                <span className="font-bold text-xs mt-2 text-white truncate max-w-full">{leaders[2].prenom}</span>
                <span className="text-[10px] text-[#D4AF37] font-semibold mt-1">{leaders[2].points || 0} pts</span>
              </div>
            )}
          </div>

          {/* Ranking List */}
          <div className="bg-[#111] border border-white/5 rounded-2xl overflow-hidden divide-y divide-white/5">
            {leaders.map((leader, idx) => {
              const isMe = leader.id === profile?.id;
              return (
                <div
                  key={leader.id}
                  className={`flex items-center justify-between p-4 transition-colors ${
                    isMe ? "bg-[#D4AF37]/10" : "hover:bg-white/[0.02]"
                  }`}
                >
                  <div className="flex items-center gap-4">
                    <span className="w-6 text-center font-bold text-sm text-gray-500">
                      {idx + 1}
                    </span>
                    <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-white font-bold border border-white/10 text-sm">
                      {leader.prenom?.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <div className="font-bold text-sm flex items-center gap-2 text-white">
                        {leader.prenom} {leader.nom}
                        {isMe && <span className="text-[9px] bg-[#D4AF37] text-black px-1.5 py-0.5 rounded-md font-bold uppercase">Vous</span>}
                      </div>
                      <div className="text-gray-500 text-xs">Niveau Global: {leader.niveau_global || "Débutant"}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-6">
                    {leader.streak_jours && leader.streak_jours > 0 ? (
                      <div className="flex items-center gap-1 text-orange-500 font-bold text-xs bg-orange-500/10 px-2 py-1 rounded-full">
                        <Flame size={12} className="fill-orange-500" /> {leader.streak_jours}j
                      </div>
                    ) : null}
                    <span className="font-bold text-[#D4AF37] text-sm">
                      {leader.points || 0} XP
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================================
// 3. MESSAGES (Discussion space)
// ============================================================================
export function Messages() {
  const { profile } = useAuth();
  const [messages, setMessages] = useState<LocalMessage[]>([]);
  const [inputText, setInputText] = useState("");

  const simulatedResponses: Record<string, string> = {
    bonjour: "Bonjour ! Comment puis-je vous aider dans votre apprentissage aujourd'hui ?",
    cours: "Vous pouvez parcourir les cours disponibles dans l'onglet 'Mes cours'. Il y en a pour tous les niveaux !",
    aide: "Je suis là pour vous guider. Posez-moi des questions sur les cours, les exercices ou la prononciation.",
    default: "C'est noté ! Je continue d'analyser vos progrès pour vous offrir la meilleure expérience possible."
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const userMsg: LocalMessage = {
      id: Date.now().toString(),
      sender_id: profile?.id,
      sender_name: "Vous",
      content: inputText,
      created_at: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMsg]);
    const inputCleaned = inputText.toLowerCase().trim();
    setInputText("");

    // Simulate response from Auralis companion
    setTimeout(() => {
      let responseText = simulatedResponses.default;
      if (inputCleaned.includes("bonjour") || inputCleaned.includes("salut")) {
        responseText = simulatedResponses.bonjour;
      } else if (inputCleaned.includes("cours") || inputCleaned.includes("apprendre")) {
        responseText = simulatedResponses.cours;
      } else if (inputCleaned.includes("aide") || inputCleaned.includes("comment")) {
        responseText = simulatedResponses.aide;
      }

      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        sender_id: "auralis",
        sender_name: "Auralis IA",
        content: responseText,
        created_at: new Date().toISOString()
      }]);
    }, 1200);
  };

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-4xl mx-auto text-white flex flex-col h-[calc(100vh-2rem)]">
      <div>
        <h1 className="text-3xl font-extrabold tracking-tight font-[Space_Grotesk]">
          Messagerie Intelligente
        </h1>
        <p className="text-gray-400 text-sm mt-1">
          Échangez avec Auralis et vos tuteurs académiques.
        </p>
      </div>

      <div className="flex-1 bg-[#111] border border-white/5 rounded-2xl p-4 flex flex-col justify-between h-[450px]">
        {/* Chats stream */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-2">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center text-gray-500 space-y-2 py-20">
              <MessageSquare size={32} className="text-[#D4AF37]/50" />
              <p className="text-sm">Démarrez la discussion avec Auralis IA.</p>
              <p className="text-[11px] text-gray-600">Essayez de dire "Bonjour" ou demandez de l'aide.</p>
            </div>
          ) : (
            messages.map((msg) => {
              const isMe = msg.sender_id !== "auralis";
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isMe ? "items-end" : "items-start"}`}
                >
                  <span className="text-[10px] text-gray-500 mb-1 px-1">
                    {msg.sender_name}
                  </span>
                  <div
                    className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-xs font-medium leading-relaxed ${
                      isMe
                        ? "bg-gradient-to-r from-[#D4AF37] to-[#F0C940] text-[#0A0A0A] rounded-tr-none"
                        : "bg-[#1d1d1d] text-white border border-white/5 rounded-tl-none"
                    }`}
                  >
                    {msg.content}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Input area */}
        <form onSubmit={handleSendMessage} className="flex gap-2 mt-4 border-t border-white/5 pt-4">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Écrivez un message..."
            className="flex-1 bg-[#1c1c1c] border border-white/10 focus:border-[#D4AF37]/40 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-500 outline-none transition-all"
          />
          <button
            type="submit"
            className="p-3 bg-[#D4AF37] hover:scale-105 active:scale-95 text-black rounded-xl transition-all"
          >
            <Send size={14} />
          </button>
        </form>
      </div>
    </div>
  );
}

// ============================================================================
// 4. NOTIFICATIONS
// ============================================================================
export function NotificationsPage() {
  const [notifications, setNotifications] = useState<LocalNotification[]>([]);

  useEffect(() => {
    // Standard system notifications helper
    setNotifications([
      {
        id: "1",
        title: "Bienvenue à bord !",
        message: "Votre compte Auralis a été créé avec succès. Bienvenue dans l'aventure !",
        date: "Aujourd'hui",
        unread: true
      },
      {
        id: "2",
        title: "Objectif quotidien !",
        message: "Auralis vous attend pour votre test d'aujourd'hui. Ne perdez pas votre série !",
        date: "Hier",
        unread: false
      }
    ]);
  }, []);

  const markAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, unread: false })));
    toast.success("Toutes les notifications ont été marquées comme lues !");
  };

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-3xl mx-auto text-white">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight font-[Space_Grotesk]">
            Vos Notifications
          </h1>
          <p className="text-gray-400 text-sm mt-1">
            Restez informé de vos progressions, messages et nouveautés.
          </p>
        </div>
        <button
          onClick={markAllRead}
          className="text-xs text-[#D4AF37] hover:underline font-semibold"
        >
          Tout marquer comme lu
        </button>
      </div>

      <div className="space-y-4">
        {notifications.map((notif) => (
          <div
            key={notif.id}
            className={`p-5 rounded-2xl border transition-all flex gap-4 ${
              notif.unread
                ? "bg-[#D4AF37]/5 border-[#D4AF37]/20"
                : "bg-[#111] border-white/5"
            }`}
          >
            <div className="p-2.5 bg-black/30 rounded-xl text-[#D4AF37] h-fit">
              <Bell size={18} />
            </div>
            <div className="flex-1 space-y-1">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-sm text-white">{notif.title}</h3>
                <span className="text-[10px] text-gray-500 font-medium">{notif.date}</span>
              </div>
              <p className="text-gray-400 text-xs leading-relaxed">{notif.message}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================================================
// 5. PARAMÈTRES (Durable profile update editor)
// ============================================================================
export function Parametres() {
  const { profile, refreshProfile } = useAuth();
  const [prenom, setPrenom] = useState(profile?.prenom || "");
  const [nom, setNom] = useState(profile?.nom || "");
  const [pseudo, setPseudo] = useState(profile?.pseudo || "");
  const [level, setLevel] = useState(profile?.niveau_global || "Débutant");
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    if (profile) {
      setPrenom(profile.prenom || "");
      setNom(profile.nom || "");
      setPseudo(profile.pseudo || "");
      setLevel(profile.niveau_global || "Débutant");
    }
  }, [profile]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pseudo || !prenom) {
      toast.error("Le prénom et le pseudo sont obligatoires !");
      return;
    }

    setUpdating(true);
    try {
      const { error } = await supabase
        .from("profiles")
        .update({
          prenom,
          nom,
          pseudo,
          niveau_global: level
        })
        .eq("id", profile?.id);

      if (error) throw error;

      await refreshProfile();
      toast.success("Profil mis à jour avec succès !");
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : String(err);
      toast.error("Erreur d'enregistrement: " + errorMsg);
    } finally {
      setUpdating(false);
    }
  };

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-2xl mx-auto text-white">
      <div>
        <h1 className="text-3xl font-extrabold tracking-tight font-[Space_Grotesk]">
          Paramètres du compte
        </h1>
        <p className="text-gray-400 text-sm mt-1">
          Gérez vos détails personnels et objectifs de formation.
        </p>
      </div>

      <form onSubmit={handleSave} className="bg-[#111] border border-white/5 rounded-2xl p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Prénom</label>
            <input
              type="text"
              value={prenom}
              onChange={(e) => setPrenom(e.target.value)}
              className="w-full bg-[#161616] border border-white/10 focus:border-[#D4AF37]/40 rounded-xl px-4 py-2.5 text-xs text-white outline-none transition-all"
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Nom</label>
            <input
              type="text"
              value={nom}
              onChange={(e) => setNom(e.target.value)}
              className="w-full bg-[#161616] border border-white/10 focus:border-[#D4AF37]/40 rounded-xl px-4 py-2.5 text-xs text-white outline-none transition-all"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Pseudo</label>
          <input
            type="text"
            value={pseudo}
            onChange={(e) => setPseudo(e.target.value)}
            className="w-full bg-[#161616] border border-white/10 focus:border-[#D4AF37]/40 rounded-xl px-4 py-2.5 text-xs text-white outline-none transition-all"
          />
        </div>

        <div className="space-y-2">
          <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Objectif de niveau</label>
          <select
            value={level}
            onChange={(e) => setLevel(e.target.value)}
            className="w-full bg-[#161616] border border-white/10 focus:border-[#D4AF37]/40 rounded-xl px-4 py-2.5 text-xs text-white outline-none transition-all"
          >
            <option value="Débutant">Débutant (A1-A2)</option>
            <option value="Intermédiaire">Intermédiaire (B1-B2)</option>
            <option value="Avancé">Avancé (C1-C2)</option>
          </select>
        </div>

        <button
          type="submit"
          disabled={updating}
          className="w-full py-3 bg-gradient-to-r from-[#D4AF37] to-[#F0C940] hover:scale-[1.01] active:scale-95 disabled:opacity-50 text-black font-bold rounded-xl text-xs transition-all shadow-md shadow-[#D4AF37]/10 flex items-center justify-center gap-2"
        >
          {updating ? (
            <div className="w-4 h-4 border-2 border-black/20 border-t-black animate-spin rounded-full" />
          ) : (
            <>Sauvegarder les modifications</>
          )}
        </button>
      </form>
    </div>
  );
}

// ============================================================================
// 6. FORMATEUR: MES COURS
// ============================================================================
export function FormateurCours() {
  const { user } = useAuth();
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCreatedCourses = async () => {
      try {
        const { data } = await supabase
          .from("courses")
          .select("*")
          .eq("createur_id", user?.id);
        if (data) {
          setCourses(data as Course[]);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    if (user) fetchCreatedCourses();
  }, [user]);

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-7xl mx-auto text-white">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight font-[Space_Grotesk]">
            Mes Formations Créées
          </h1>
          <p className="text-gray-400 text-sm mt-1">
            Gérez vos programmes, ajoutez des modules ou créez de nouveaux parcours académiques.
          </p>
        </div>
        <a
          href="/formateur/cours/nouveau"
          className="px-4 py-2.5 bg-gradient-to-r from-[#D4AF37] to-[#F0C940] hover:scale-105 active:scale-95 text-black rounded-xl text-xs font-bold transition-all shadow-md flex items-center gap-2 w-fit"
        >
          <PlusCircle size={14} /> Créer un cours
        </a>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-2 border-[#D4AF37]/20 border-t-[#D4AF37] animate-spin rounded-full" />
        </div>
      ) : courses.length === 0 ? (
        <div className="text-center py-16 bg-[#111] rounded-2xl border border-white/5 flex flex-col items-center justify-center space-y-4">
          <BookOpen size={40} className="text-gray-600" />
          <p className="text-gray-500 text-sm">Vous n'avez créé aucun cours pour le moment.</p>
          <a
            href="/formateur/cours/nouveau"
            className="text-xs text-[#D4AF37] font-semibold hover:underline"
          >
            Créer votre premier cours dès maintenant
          </a>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {courses.map((course) => (
            <div
              key={course.id}
              className="bg-[#111] border border-white/5 rounded-2xl p-5 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase font-bold text-[#D4AF37] px-2 py-0.5 bg-[#D4AF37]/10 rounded-full">
                    {course.langue}
                  </span>
                  <span className="text-[11px] text-gray-500">Niveau: {course.niveau_cible}</span>
                </div>
                <h3 className="font-bold text-lg text-white mt-3">{course.titre}</h3>
                <p className="text-gray-400 text-xs mt-2 line-clamp-3 leading-relaxed">
                  {course.description}
                </p>
              </div>
              <div className="mt-6 flex items-center justify-between border-t border-white/5 pt-4">
                <span className="text-xs text-gray-500 font-semibold">Statut: Publié</span>
                <button className="text-xs text-[#D4AF37] hover:underline font-bold flex items-center gap-1">
                  Éditer <ChevronRight size={12} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ============================================================================
// 7. FORMATEUR: CRÉER UN COURS (Add course insertion form)
// ============================================================================
export function FormateurCoursNouveau() {
  const { user } = useAuth();
  const [titre, setTitre] = useState("");
  const [description, setDescription] = useState("");
  const [langue, setLangue] = useState("Anglais");
  const [niveauCible, setNiveauCible] = useState("Débutant");
  const [inserting, setInserting] = useState(false);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!titre || !description) {
      toast.error("Veuillez remplir tous les champs obligatoires !");
      return;
    }

    setInserting(true);
    try {
      const { error } = await supabase
        .from("courses")
        .insert([{
          titre,
          description,
          langue,
          niveau_cible: niveauCible,
          createur_id: user?.id
        }]);

      if (error) throw error;
      toast.success("Cours créé avec succès !");
      setTitre("");
      setDescription("");
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : String(err);
      toast.error("Erreur de création: " + errorMsg);
    } finally {
      setInserting(false);
    }
  };

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-2xl mx-auto text-white">
      <div>
        <h1 className="text-3xl font-extrabold tracking-tight font-[Space_Grotesk]">
          Créer un Nouveau Cours
        </h1>
        <p className="text-gray-400 text-sm mt-1">
          Formulez un nouveau programme pédagogique immersif.
        </p>
      </div>

      <form onSubmit={handleCreate} className="bg-[#111] border border-white/5 rounded-2xl p-6 space-y-6">
        <div className="space-y-2">
          <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Titre du cours *</label>
          <input
            type="text"
            placeholder="Ex: Maîtriser le vocabulaire des affaires"
            value={titre}
            onChange={(e) => setTitre(e.target.value)}
            className="w-full bg-[#161616] border border-white/10 focus:border-[#D4AF37]/40 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-600 outline-none transition-all"
            required
          />
        </div>

        <div className="space-y-2">
          <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Description de la formation *</label>
          <textarea
            rows={4}
            placeholder="Décrivez brièvement le programme..."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full bg-[#161616] border border-white/10 focus:border-[#D4AF37]/40 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-600 outline-none transition-all"
            required
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Langue d'apprentissage</label>
            <select
              value={langue}
              onChange={(e) => setLangue(e.target.value)}
              className="w-full bg-[#161616] border border-white/10 focus:border-[#D4AF37]/40 rounded-xl px-4 py-2.5 text-xs text-white outline-none transition-all"
            >
              <option value="Anglais">Anglais</option>
              <option value="Espagnol">Espagnol</option>
              <option value="Allemand">Allemand</option>
              <option value="Français">Français</option>
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Niveau ciblé</label>
            <select
              value={niveauCible}
              onChange={(e) => setNiveauCible(e.target.value)}
              className="w-full bg-[#161616] border border-white/10 focus:border-[#D4AF37]/40 rounded-xl px-4 py-2.5 text-xs text-white outline-none transition-all"
            >
              <option value="Débutant">Débutant (A1-A2)</option>
              <option value="Intermédiaire">Intermédiaire (B1-B2)</option>
              <option value="Avancé">Avancé (C1-C2)</option>
            </select>
          </div>
        </div>

        <button
          type="submit"
          disabled={inserting}
          className="w-full py-3 bg-gradient-to-r from-[#D4AF37] to-[#F0C940] hover:scale-[1.01] active:scale-95 disabled:opacity-50 text-black font-bold rounded-xl text-xs transition-all shadow-md flex items-center justify-center gap-2"
        >
          {inserting ? (
            <div className="w-4 h-4 border-2 border-black/20 border-t-black animate-spin rounded-full" />
          ) : (
            <>Créer et publier le cours</>
          )}
        </button>
      </form>
    </div>
  );
}

// ============================================================================
// 8. FORMATEUR: APPRENANTS
// ============================================================================
export function FormateurApprenants() {
  const [learners, setLearners] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchApprenants = async () => {
      try {
        const { data } = await supabase
          .from("profiles")
          .select("*")
          .eq("role", "apprenant")
          .limit(10);
        if (data) {
          setLearners(data as Profile[]);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchApprenants();
  }, []);

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-5xl mx-auto text-white">
      <div>
        <h1 className="text-3xl font-extrabold tracking-tight font-[Space_Grotesk]">
          Suivi des Apprenants
        </h1>
        <p className="text-gray-400 text-sm mt-1">
          Visualisez les progrès, scores et assiduités des apprenants inscrits à vos cours.
        </p>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-2 border-[#D4AF37]/20 border-t-[#D4AF37] animate-spin rounded-full" />
        </div>
      ) : learners.length === 0 ? (
        <div className="text-center py-16 bg-[#111] rounded-2xl border border-white/5 flex flex-col items-center justify-center space-y-2">
          <Users size={32} className="text-gray-600" />
          <p className="text-gray-500 text-sm">Aucun apprenant enregistré pour le moment.</p>
        </div>
      ) : (
        <div className="bg-[#111] border border-white/5 rounded-2xl overflow-hidden divide-y divide-white/5">
          {learners.map((learner) => (
            <div
              key={learner.id}
              className="flex flex-col sm:flex-row sm:items-center justify-between p-5 hover:bg-white/[0.01] transition-all gap-4"
            >
              <div className="flex items-center gap-4">
                <div className="w-11 h-11 rounded-full bg-gradient-to-br from-white/5 to-white/10 flex items-center justify-center text-white font-bold text-sm border border-white/10">
                  {learner.prenom?.charAt(0).toUpperCase()}
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white flex items-center gap-2">
                    {learner.prenom} {learner.nom}
                  </h3>
                  <span className="text-[10px] text-[#D4AF37] font-semibold bg-[#D4AF37]/10 px-2 py-0.5 rounded-full">
                    {learner.niveau_global || "A1 - Débutant"}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-6 justify-between sm:justify-end">
                <div className="text-left sm:text-right">
                  <div className="text-[10px] text-gray-500 uppercase font-bold tracking-wider">Score Global</div>
                  <div className="font-extrabold text-[#D4AF37] text-sm">{learner.points || 0} XP</div>
                </div>

                <div className="text-left sm:text-right">
                  <div className="text-[10px] text-gray-500 uppercase font-bold tracking-wider">Série de Jours</div>
                  <div className="font-bold text-orange-500 text-sm flex items-center gap-1 justify-end">
                    <Flame size={12} className="fill-orange-500" /> {learner.streak_jours || 0} jours
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
