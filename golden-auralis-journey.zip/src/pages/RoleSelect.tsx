import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { GraduationCap, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { auralisLogo } from "@/lib/assets";

export default function RoleSelect() {
  const navigate = useNavigate();
  const { user, profile, refreshProfile, loading: authLoading } = useAuth();
  const [role, setRole] = useState<"apprenant" | "formateur">("apprenant");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // If profile already onboarded, redirect immediately
  useEffect(() => {
    if (!authLoading && profile?.is_onboarded) {
      navigate(
        profile.role === "formateur" ? "/loading-formateur" : "/loading-apprenant",
        { replace: true }
      );
    }
  }, [authLoading, profile, navigate]);

  const handleConfirm = async () => {
    if (!user) return;
    setLoading(true);
    setError("");

    try {
      // Use SECURITY DEFINER RPC to set role and mark as onboarded
      const { data: result, error: rpcError } = await supabase.rpc("complete_onboarding", { _role: role });

      if (rpcError) {
        console.error("RoleSelect RPC error:", rpcError);
        setError("Une erreur est survenue. Réessayez.");
        setLoading(false);
        return;
      }

      const profile = result as { id?: string; role?: string; is_onboarded?: boolean; error?: string };
      if (profile.error) {
        console.error("RoleSelect profile error:", profile.error);
        setError("Une erreur est survenue. Réessayez.");
        setLoading(false);
        return;
      }

      await refreshProfile();

      navigate(
        role === "formateur" ? "/loading-formateur" : "/loading-apprenant",
        { replace: true }
      );
    } catch (err) {
      console.error("RoleSelect error:", err);
      setError("Une erreur inattendue. Réessayez.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Golden particles */}
      <div className="particles-container absolute inset-0 pointer-events-none" aria-hidden>
        {Array.from({ length: 20 }).map((_, i) => (
          <span key={i} className="particle" style={{ "--i": i } as React.CSSProperties} />
        ))}
      </div>

      <div className="relative z-10 w-full max-w-md mx-4">
        <div className="text-center mb-8">
          <img src={auralisLogo} alt="AURALIS" className="w-32 h-32 mx-auto rounded-full object-cover" />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card rounded-2xl p-8"
        >
          <h1
            className="text-xl font-bold text-gold text-center mb-2"
            style={{ fontFamily: "'Space Grotesk', sans-serif" }}
          >
            Bienvenue sur AURALIS
          </h1>
          <p className="text-gold-muted text-sm text-center mb-6">
            Choisissez votre profil pour personnaliser votre expérience
          </p>

          <div className="grid grid-cols-2 gap-4 mb-6">
            <RoleOption
              selected={role === "apprenant"}
              onClick={() => setRole("apprenant")}
              icon={<GraduationCap size={32} />}
              label="Apprenant"
              desc="Je veux apprendre et progresser"
            />
            <RoleOption
              selected={role === "formateur"}
              onClick={() => setRole("formateur")}
              icon={<BookOpen size={32} />}
              label="Formateur"
              desc="Je veux créer et enseigner"
            />
          </div>

          {error && (
            <p className="text-sm text-red-400 bg-red-400/10 rounded-lg p-3 mb-4">{error}</p>
          )}

          <Button
            onClick={handleConfirm}
            disabled={loading}
            className="w-full gold-button h-11 font-semibold"
          >
            {loading ? "Chargement..." : "Continuer"}
          </Button>
        </motion.div>
      </div>
    </div>
  );
}

function RoleOption({
  selected,
  onClick,
  icon,
  label,
  desc,
}: {
  selected: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
  desc: string;
}) {
  return (
    <motion.button
      type="button"
      onClick={onClick}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className={`role-card rounded-xl p-5 text-center transition-all ${
        selected ? "role-card-active" : ""
      }`}
    >
      <div className={`mb-2 flex justify-center ${selected ? "text-gold" : "text-gold-muted"}`}>
        {icon}
      </div>
      <div className={`text-sm font-semibold ${selected ? "text-gold" : "text-gold-muted"}`}>
        {label}
      </div>
      <div className="text-[11px] text-gold-muted/60 mt-1">{desc}</div>
    </motion.button>
  );
}
