import { useAuth } from "@/contexts/AuthContext";
import { Navigate } from "react-router-dom";
import { auralisLogo } from "@/lib/assets";

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRole?: string;
  /** If true, redirect to loading page if not yet seen this session */
  requireLoading?: boolean;
}

export default function ProtectedRoute({ children, requiredRole, requireLoading }: ProtectedRouteProps) {
  const { user, profile, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <img src={auralisLogo} alt="AURALIS" className="w-20 h-20 rounded-full object-cover animate-pulse" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  // Force loading page on every new session for main routes
  if (requireLoading) {
    // Wait for profile to load before deciding — prevents dashboard flash
    if (!profile) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <img src={auralisLogo} alt="AURALIS" className="w-20 h-20 rounded-full object-cover animate-pulse" />
        </div>
      );
    }

    const loadingKey = `auralis_loading_seen_${user.id}`;
    const alreadySeen = sessionStorage.getItem(loadingKey);

    if (!alreadySeen) {
      const loadingRoute = profile.role === "formateur" ? "/loading-formateur" : "/loading-apprenant";
      return <Navigate to={loadingRoute} replace />;
    }
  }

  // Role guard: redirect if profile loaded and role doesn't match
  if (requiredRole && profile && profile.role !== requiredRole) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
}
