import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { motion } from "framer-motion";
import { BookOpen, Sparkles } from "lucide-react";

const DURATION = 4000;

export default function LoadingApprenant() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const start = Date.now();
    const frame = () => {
      const elapsed = Date.now() - start;
      const pct = Math.min(elapsed / DURATION, 1);
      setProgress(pct);
      if (pct < 1) requestAnimationFrame(frame);
    };
    requestAnimationFrame(frame);

    const timeout = setTimeout(() => {
      if (user) {
        sessionStorage.setItem(`auralis_loading_seen_${user.id}`, "1");
        // Trigger student tutorial state
        sessionStorage.setItem("show_apprenant_tutorial", "true");
      }
      navigate("/", { replace: true });
    }, DURATION);
    return () => clearTimeout(timeout);
  }, [navigate, user]);

  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center bg-[#060606] text-white p-6 overflow-hidden">
      {/* Decorative background grid and flares */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f0f0f_1px,transparent_1px),linear-gradient(to_bottom,#0f0f0f_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-70" />
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-[#D4AF37]/5 rounded-full blur-[100px] pointer-events-none" />

      {/* 3D Animated Illustration Container */}
      <div className="relative w-full max-w-[400px] h-[280px] bg-black/40 border border-[#D4AF37]/10 rounded-3xl p-6 flex flex-col justify-between overflow-hidden shadow-2xl backdrop-blur-md">
        {/* Ambient lighting inside the stage */}
        <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-[#D4AF37]/5 to-transparent pointer-events-none" />

        {/* The 3D scene stage */}
        <div className="relative flex-1 w-full flex items-end justify-center">
          {/* Table */}
          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.6 }}
            className="absolute bottom-4 left-1/2 -translate-x-1/2 w-48 h-3 bg-gradient-to-r from-amber-900 to-amber-950 rounded-full shadow-lg border border-amber-800/30"
          >
            {/* Table legs */}
            <div className="absolute left-6 top-full w-2 h-10 bg-amber-950 rounded-b-md" />
            <div className="absolute right-6 top-full w-2 h-10 bg-amber-950 rounded-b-md" />
          </motion.div>

          {/* Avatar Character */}
          <motion.div
            initial={{ x: -160, y: 0, opacity: 0 }}
            animate={{ 
              x: [-160, 0, 0], 
              opacity: [0, 1, 1],
              y: [0, -8, 0, -8, 0, 0] // bobbing up and down while walking
            }}
            transition={{ 
              duration: 2.8, 
              times: [0, 0.6, 1],
              ease: "easeOut"
            }}
            className="absolute bottom-6 flex flex-col items-center z-10"
          >
            {/* Avatar Head with friendly waving eyes */}
            <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-[#1a1a1a] to-[#2a2a2a] border border-[#D4AF37]/40 flex items-center justify-center relative shadow-inner overflow-hidden">
              {/* Glowing face shield */}
              <div className="absolute inset-0.5 bg-black/60 rounded-full flex flex-col items-center justify-center gap-1.5 p-2">
                <div className="flex gap-3 mt-1">
                  <motion.div 
                    animate={{ scaleY: [1, 0.1, 1, 1] }}
                    transition={{ repeat: Infinity, duration: 3, repeatDelay: 1.5 }}
                    className="w-2.5 h-2.5 rounded-full bg-gradient-to-b from-[#D4AF37] to-amber-500 shadow-[0_0_8px_#D4AF37]" 
                  />
                  <motion.div 
                    animate={{ scaleY: [1, 0.1, 1, 1] }}
                    transition={{ repeat: Infinity, duration: 3, repeatDelay: 1.5 }}
                    className="w-2.5 h-2.5 rounded-full bg-gradient-to-b from-[#D4AF37] to-amber-500 shadow-[0_0_8px_#D4AF37]" 
                  />
                </div>
                <motion.div 
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ repeat: Infinity, duration: 2 }}
                  className="w-5 h-1.5 rounded-full border-b-2 border-[#D4AF37]/80" 
                />
              </div>
            </div>

            {/* Body */}
            <div className="w-12 h-16 bg-gradient-to-b from-neutral-800 to-neutral-900 border border-neutral-700/50 rounded-t-2xl mt-1 relative flex justify-center">
              {/* Hands holding books initially, then putting down, then waving */}
              
              {/* Left hand holding/putting down books */}
              <motion.div 
                animate={{ 
                  y: [0, 0, 16],
                  rotate: [15, 15, 0]
                }}
                transition={{ duration: 2.5, times: [0, 0.6, 1], ease: "easeInOut" }}
                className="absolute -left-3 top-3 w-4 h-8 bg-neutral-800 border border-neutral-700 rounded-full origin-top"
              />

              {/* Right hand waving AFTER putting books down */}
              <motion.div 
                animate={{ 
                  rotate: [0, 0, -50, -110, -80, -110, -80, -110, 0],
                  y: [0, 0, -2, -10, -12, -10, -12, -10, 0]
                }}
                transition={{ duration: 4, times: [0, 0.6, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 1] }}
                className="absolute -right-3 top-3 w-4 h-8 bg-neutral-800 border border-neutral-700 rounded-full origin-top"
              >
                {/* Micro gold sparkles when waving */}
                <motion.div 
                  animate={{ opacity: [0, 0, 1, 0], scale: [0.5, 1.2, 0.5] }}
                  transition={{ duration: 1.5, delay: 2.8, repeat: 1 }}
                  className="absolute -right-2 -top-2 text-[#D4AF37]"
                >
                  <Sparkles size={10} />
                </motion.div>
              </motion.div>
            </div>
          </motion.div>

          {/* Book Stack in Avatar's hands, then moving onto the table */}
          <motion.div
            initial={{ x: -160, y: -20, opacity: 0 }}
            animate={{
              x: [-160, 0, 0],
              y: [-20, -20, -12], // drops nicely onto table surface
              opacity: [0, 1, 1],
              scale: [1, 1, 0.95]
            }}
            transition={{
              duration: 2.5,
              times: [0, 0.6, 1],
              ease: "easeInOut"
            }}
            className="absolute bottom-6 flex flex-col items-center gap-[1px]"
          >
            {/* 3 stacked books of different colors */}
            <div className="w-10 h-2 bg-gradient-to-r from-[#D4AF37] to-amber-600 rounded shadow-md border-b border-amber-700/50" />
            <div className="w-12 h-2.5 bg-gradient-to-r from-red-600 to-red-800 rounded shadow-md border-b border-red-900/50" />
            <div className="w-14 h-3 bg-gradient-to-r from-blue-600 to-blue-800 rounded shadow-md border-b border-blue-900/50 flex items-center justify-center">
              <BookOpen size={8} className="text-white/40" />
            </div>
          </motion.div>
        </div>

        {/* Legend */}
        <div className="text-center mt-3 z-10">
          <span className="text-[10px] text-neutral-500 font-mono tracking-widest uppercase">Statut : Dépôt du matériel</span>
        </div>
      </div>

      {/* Loading caption */}
      <div className="mt-8 text-center">
        <motion.p
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
          className="text-sm font-semibold tracking-widest uppercase bg-clip-text text-transparent bg-gradient-to-r from-[#D4AF37] to-[#F5D061]"
        >
          CHARGEMENT DE L'ESPACE APPRENANT...
        </motion.p>
        <p className="text-xs text-neutral-400 mt-1">Auralis prépare vos supports et installe la classe virtuelle</p>
      </div>

      {/* Visual Progress Bar */}
      <div className="mt-5 w-72 h-1.5 rounded-full overflow-hidden bg-neutral-900 border border-neutral-800">
        <motion.div
          className="h-full rounded-full bg-gradient-to-r from-[#D4AF37] to-amber-500 shadow-[0_0_8px_rgba(212,175,55,0.6)]"
          style={{ width: `${progress * 100}%` }}
        />
      </div>

      <div className="mt-2 text-[11px] font-mono text-neutral-500">
        {Math.round(progress * 100)}%
      </div>
    </div>
  );
}
