import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { motion } from "framer-motion";
import { Sparkles, GraduationCap } from "lucide-react";

const DURATION = 4000;

export default function LoadingFormateur() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const start = Date.now();
    const frame = () => {
      const elapsed = Date.now() - start;
      const pct = Math.min(elapsed / DURATION, 1);
      setProgress(pct);
      if (pct < 1) requestAnimationFrame(frame);
    };
    requestAnimationFrame(frame);

    const timeout = setTimeout(() => {
      if (user) {
        sessionStorage.setItem(`auralis_loading_seen_${user.id}`, "1");
        // Trigger teacher tutorial state
        sessionStorage.setItem("show_formateur_tutorial", "true");
      }
      navigate("/formateur/dashboard", { replace: true });
    }, DURATION);
    return () => clearTimeout(timeout);
  }, [navigate, user]);

  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center bg-[#060606] text-white p-6 overflow-hidden">
      {/* Decorative background grid and flares */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f0f0f_1px,transparent_1px),linear-gradient(to_bottom,#0f0f0f_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-70" />
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-blue-500/5 rounded-full blur-[100px] pointer-events-none" />

      {/* 3D Animated Illustration Container */}
      <div className="relative w-full max-w-[400px] h-[280px] bg-black/40 border border-blue-500/20 rounded-3xl p-6 flex flex-col justify-between overflow-hidden shadow-2xl backdrop-blur-md">
        {/* Ambient lighting inside the stage */}
        <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-blue-500/5 to-transparent pointer-events-none" />

        {/* The 3D scene stage */}
        <div className="relative flex-1 w-full flex items-end justify-center">
          {/* Blackboard / Screen */}
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="absolute top-2 w-52 h-20 bg-emerald-950 border-4 border-amber-900 rounded-lg shadow-inner flex flex-col items-center justify-center p-1.5"
          >
            <span className="text-[10px] text-emerald-300 font-mono tracking-widest text-center uppercase">1 + 1 = Auralis AI</span>
            <div className="w-16 h-1 bg-emerald-700/50 mt-1.5 rounded-full" />
            <div className="w-24 h-1 bg-emerald-700/30 mt-1 rounded-full" />
          </motion.div>

          {/* Instructor Character */}
          <motion.div
            initial={{ x: -60, y: 0, opacity: 0 }}
            animate={{ x: -50, opacity: 1 }}
            className="absolute bottom-4 flex flex-col items-center z-10"
          >
            {/* Instructor Head with pointer feedback */}
            <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-[#1a1a1a] to-[#2a2a2a] border border-blue-400/40 flex items-center justify-center relative overflow-hidden">
              <div className="absolute inset-0.5 bg-black/60 rounded-full flex flex-col items-center justify-center gap-1 p-1">
                <div className="flex gap-1.5 mt-0.5">
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-400 shadow-[0_0_6px_#60a5fa]" />
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-400 shadow-[0_0_6px_#60a5fa]" />
                </div>
                <div className="w-3 h-1 rounded-full border-b-2 border-blue-400/80" />
              </div>
            </div>

            {/* Teacher body pointing */}
            <div className="w-9 h-12 bg-gradient-to-b from-neutral-800 to-neutral-900 border border-neutral-700/50 rounded-t-xl mt-1 relative">
              {/* Pointer arm sticking out */}
              <motion.div 
                animate={{ rotate: [-20, -50, -20] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -right-3 top-2 w-8 h-2 bg-gradient-to-r from-neutral-800 to-[#D4AF37] rounded-full origin-left"
              />
            </div>
          </motion.div>

          {/* Student Bench 1 with small child avatar */}
          <motion.div
            initial={{ x: 60, y: 15, opacity: 0 }}
            animate={{ x: 30, y: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="absolute bottom-4 flex flex-col items-center z-10"
          >
            {/* Pupil Head */}
            <div className="w-8 h-8 rounded-full bg-[#1e1e1e] border border-neutral-700 flex items-center justify-center relative">
              <div className="absolute inset-0.5 bg-black/70 rounded-full flex gap-1 items-center justify-center">
                <div className="w-1 h-1 rounded-full bg-amber-400" />
                <div className="w-1 h-1 rounded-full bg-amber-400" />
              </div>
              {/* Little raised hand waving */}
              <motion.div 
                animate={{ y: [0, -6, 0] }}
                transition={{ duration: 1.5, repeat: Infinity, delay: 0.5 }}
                className="absolute -right-1.5 top-0 w-2 h-4 bg-amber-500/80 rounded-full origin-bottom"
              />
            </div>
            {/* Small wood Bench */}
            <div className="w-12 h-6 bg-amber-800/80 border border-amber-900/60 rounded-t-sm mt-0.5" />
          </motion.div>

          {/* Student Bench 2 with small child avatar */}
          <motion.div
            initial={{ x: 120, y: 15, opacity: 0 }}
            animate={{ x: 75, y: 0, opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="absolute bottom-4 flex flex-col items-center z-10"
          >
            {/* Pupil Head */}
            <div className="w-8 h-8 rounded-full bg-[#1e1e1e] border border-neutral-700 flex items-center justify-center relative">
              <div className="absolute inset-0.5 bg-black/70 rounded-full flex gap-1 items-center justify-center">
                <div className="w-1 h-1 rounded-full bg-emerald-400" />
                <div className="w-1 h-1 rounded-full bg-emerald-400" />
              </div>
              {/* Nodding effect */}
              <motion.div 
                animate={{ rotate: [0, 8, 0, -8, 0] }}
                transition={{ duration: 2.2, repeat: Infinity }}
                className="absolute inset-0 rounded-full"
              />
            </div>
            {/* Small wood Bench */}
            <div className="w-12 h-6 bg-amber-800/80 border border-amber-900/60 rounded-t-sm mt-0.5" />
          </motion.div>
        </div>

        {/* Legend */}
        <div className="text-center mt-3 z-10">
          <span className="text-[10px] text-neutral-500 font-mono tracking-widest uppercase">Statut : Enseignement en cours</span>
        </div>
      </div>

      {/* Loading caption */}
      <div className="mt-8 text-center">
        <motion.p
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
          className="text-sm font-semibold tracking-widest uppercase bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-cyan-400"
        >
          CHARGEMENT DE L'ESPACE FORMATEUR...
        </motion.p>
        <p className="text-xs text-neutral-400 mt-1">Auralis prépare votre tableau de bord et charge vos promotions</p>
      </div>

      {/* Visual Progress Bar */}
      <div className="mt-5 w-72 h-1.5 rounded-full overflow-hidden bg-neutral-900 border border-neutral-800">
        <motion.div
          className="h-full rounded-full bg-gradient-to-r from-blue-500 to-cyan-400 shadow-[0_0_8px_rgba(59,130,246,0.6)]"
          style={{ width: `${progress * 100}%` }}
        />
      </div>

      <div className="mt-2 text-[11px] font-mono text-neutral-500">
        {Math.round(progress * 100)}%
      </div>
    </div>
  );
}
