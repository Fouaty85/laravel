import { useState, Suspense, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useAuralisAvatar, type AuralisGesture } from "@/hooks/useAuralisAvatar";
import { useAvatarScenario } from "@/hooks/useAvatarScenario";
import DashboardSidebar from "@/components/dashboard/DashboardSidebar";
import FormateurSidebar from "@/components/dashboard/FormateurSidebar";
import { motion, AnimatePresence } from "framer-motion";
import { MessageSquare, Volume2, VolumeX, Sparkles, X, Mic, Home } from "lucide-react";
import { auralisLogo } from "@/lib/assets";
import AuralisAvatar from "@/components/auralis/AuralisAvatar";
import { useLocation } from "react-router-dom";
import ApprenantTutorial from "@/components/auralis/ApprenantTutorial";
import FormateurTutorial from "@/components/auralis/FormateurTutorial";

interface Props {
  children: React.ReactNode;
}

const PAGE_KNOWLEDGE: Record<string, { label: string; text: string; gesture: AuralisGesture }> = {
  "/": {
    label: "Tableau de Bord",
    text: `Bienvenue sur ton Tableau de bord ! Tu peux suivre tes cours en cours, voir ton temps d'étude, ton streak, et tes recommandations personnalisées.`,
    gesture: "wave",
  },
  "/cours": {
    label: "Mes Cours",
    text: `Bienvenue dans ton catalogue de cours ! Découvre de nouveaux sujets passionnants et commence ton apprentissage à ton rythme.`,
    gesture: "point",
  },
  "/classement": {
    label: "Classement",
    text: `Voici le Classement d'Auralis ! Compare tes points avec les autres apprenants et grimpe au sommet pour remporter le trophée !`,
    gesture: "celebrate",
  },
  "/messages": {
    label: "Messagerie",
    text: `Ici, tu peux échanger directement avec tes formateurs et tes pairs pour poser des questions ou collaborer !`,
    gesture: "nod",
  },
  "/notifications": {
    label: "Notifications",
    text: `Voici ton centre de notifications. Reste à jour sur les nouveaux cours publiés, tes retours d'exercices et tes objectifs.`,
    gesture: "idle",
  },
  "/parametres": {
    label: "Paramètres",
    text: `Ici, tu peux personnaliser ton profil public, ajuster tes préférences et sécuriser ton compte Auralis.`,
    gesture: "thinking",
  },
  "/formateur/dashboard": {
    label: "Tableau de bord Formateur",
    text: `Bienvenue sur votre espace de contrôle formateur ! Suivez vos apprenants inscrits, vos statistiques clés et gérez vos formations.`,
    gesture: "wave",
  },
  "/formateur/cours": {
    label: "Mes cours formateur",
    text: `Voici la gestion de vos cours. Créez des leçons structurées, ajoutez des chapitres et proposez des quiz captivants.`,
    gesture: "point",
  },
  "/formateur/cours/nouveau": {
    label: "Création de cours",
    text: `Commençons la création d'un nouveau cours ! Remplissez le titre, définissez la langue et ajoutez du contenu enrichissant.`,
    gesture: "nod",
  },
  "/formateur/apprenants": {
    label: "Suivi apprenants",
    text: `Suivez l'évolution et le taux de réussite de vos apprenants en temps réel. Identifiez ceux qui ont besoin d'aide.`,
    gesture: "point",
  },
};

export default function AppLayout({ children }: Props) {
  const { profile } = useAuth();
  const { isTalking, gesture, expression, speak, playGesture, setExpression } = useAuralisAvatar();
  const { cancelScenario } = useAvatarScenario();
  const location = useLocation();

  const [isExpanded, setIsExpanded] = useState(false);
  const [speechMuted, setSpeechMuted] = useState(false);
  const [inputText, setInputText] = useState("");
  const [balloonText, setBalloonText] = useState("");

  const isFormateur = profile?.role === "formateur";

  // Context-aware speech trigger when route changes
  useEffect(() => {
    const knowledge = PAGE_KNOWLEDGE[location.pathname];
    if (knowledge) {
      setBalloonText(knowledge.text);
      // Subtle cue
      playGesture(knowledge.gesture, 1200);
    } else {
      setBalloonText("");
    }
  }, [location.pathname, playGesture]);

  // Watch for spoken text
  useEffect(() => {
    if (!isTalking) {
      // If we stop speaking, after 10 seconds we clear the custom speech bubble,
      // but let's keep the page description bubble visible so the user can read it.
    }
  }, [isTalking]);

  const handleQuickCommand = (cmd: string) => {
    cancelScenario();
    if (cmd === "bonjour") {
      const phrases = [
        `Bonjour ${profile?.prenom || ""} ! Heureux de vous revoir sur Auralis.`,
        `Ravi de vous voir ${profile?.prenom || ""} ! Prêt pour une nouvelle session ?`,
      ];
      const selected = phrases[Math.floor(Math.random() * phrases.length)];
      setBalloonText(selected);
      speak(selected, "wave");
    } else if (cmd === "joke") {
      const jokes = [
        "Pourquoi les développeurs détestent-ils la nature ? Parce qu'il y a trop de bugs !",
        "Comment appelle-t-on un développeur qui n'aime pas le café ? Un bogue de l'évolution !",
        "Que fait un ordinateur quand il a froid ? Il ferme toutes ses fenêtres !",
      ];
      const selected = jokes[Math.floor(Math.random() * jokes.length)];
      setBalloonText(selected);
      speak(selected, "celebrate");
    } else if (cmd === "encourage") {
      const encouragements = [
        "Vous faites d'excellents progrès ! Continuez ainsi.",
        "Chaque pas compte. Vous êtes sur le point de maîtriser ces notions !",
        "La persévérance est la clé. Je suis extrêmement fier de votre parcours aujourd'hui !",
      ];
      const selected = encouragements[Math.floor(Math.random() * encouragements.length)];
      setBalloonText(selected);
      speak(selected, "point");
    }
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    cancelScenario();

    const text = inputText.trim();
    setInputText("");
    setBalloonText(text);

    // AI/Assistant matching
    const lower = text.toLowerCase();
    if (lower.includes("aide") || lower.includes("comment")) {
      const ans = "Vous pouvez naviguer dans vos cours depuis le menu latéral gauche. Je suis là pour vous aider !";
      setBalloonText(ans);
      speak(ans, "nod");
    } else if (lower.includes("salut") || lower.includes("bonjour") || lower.includes("hello")) {
      const ans = `Salut ${profile?.prenom || ""} ! Que puis-je faire pour toi aujourd'hui ?`;
      setBalloonText(ans);
      speak(ans, "wave");
    } else {
      const ans = `J'adore votre question ! " ${text} " est un excellent sujet. Explorons cela ensemble dans nos cours !`;
      setBalloonText(ans);
      speak(ans, "point");
    }
  };

  return (
    <div className="min-h-screen flex bg-[#0A0A0A] text-white overflow-hidden">
      {/* Interactive Tutorials based on role */}
      {isFormateur ? <FormateurTutorial /> : <ApprenantTutorial />}

      {/* 1. Left Sidebar based on Role */}
      {isFormateur ? <FormateurSidebar /> : <DashboardSidebar />}

      {/* 2. Main Page Content container */}
      <div className="flex-1 ml-[72px] md:ml-[260px] h-screen overflow-y-auto transition-all duration-300 relative">
        {children}
      </div>

      {/* 3. PERSISTENT AURALIS COMPANION WIDGET (Bottom Right) */}
      <div className="fixed bottom-6 right-6 z-[9999] flex flex-col items-end gap-3 pointer-events-none">
        
        {/* Subtitle speech balloon */}
        <AnimatePresence>
          {balloonText && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="pointer-events-auto max-w-[280px] bg-black/90 border border-[#D4AF37]/30 p-3 rounded-2xl shadow-xl text-xs text-[#A0A0A0]"
            >
              <div className="text-[#D4AF37] font-semibold mb-1 flex items-center gap-1.5">
                <Sparkles size={12} />
                Auralis dit :
              </div>
              <p className="leading-relaxed text-white">{balloonText}</p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Console panel when expanded */}
        <AnimatePresence>
          {isExpanded && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="pointer-events-auto w-[320px] bg-[#161616]/98 border border-[#D4AF37]/30 rounded-3xl overflow-hidden shadow-2xl"
              style={{ boxShadow: "0 10px 40px rgba(0,0,0,0.8), 0 0 40px rgba(212,175,55,0.05)" }}
            >
              {/* Header */}
              <div className="px-4 py-3 border-b border-[#D4AF37]/15 flex items-center justify-between bg-black/40">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-[#D4AF37] shadow-[0_0_8px_#D4AF37] animate-pulse" />
                  <span className="text-xs font-bold text-[#D4AF37] tracking-wider">AURALIS IA</span>
                </div>
                <button
                  onClick={() => setIsExpanded(false)}
                  className="p-1 hover:bg-white/5 rounded-full text-gray-400 hover:text-white transition-colors"
                >
                  <X size={16} />
                </button>
              </div>

              {/* 3D Model Close-up frame */}
              <div className="h-[180px] relative bg-gradient-to-b from-black/50 to-transparent overflow-hidden">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_center_bottom,rgba(212,175,55,0.05),transparent)] pointer-events-none" />
                <Suspense fallback={
                  <div className="flex items-center justify-center h-full">
                    <div className="w-8 h-8 rounded-full border border-[#D4AF37]/20 border-t-[#D4AF37] animate-spin" />
                  </div>
                }>
                  <AuralisAvatar size="small" locked={true} className="w-full h-full" />
                </Suspense>
              </div>

              {/* Commands & Chat */}
              <div className="p-4 space-y-3 bg-black/20">
                <div className="grid grid-cols-3 gap-1.5 text-[11px]">
                  <button
                    onClick={() => handleQuickCommand("bonjour")}
                    className="py-1.5 px-2 bg-white/5 hover:bg-[#D4AF37]/10 border border-[#D4AF37]/10 hover:border-[#D4AF37]/30 rounded-xl text-center text-gray-300 hover:text-[#D4AF37] transition-all"
                  >
                    👋 Saluer
                  </button>
                  <button
                    onClick={() => handleQuickCommand("joke")}
                    className="py-1.5 px-2 bg-white/5 hover:bg-[#D4AF37]/10 border border-[#D4AF37]/10 hover:border-[#D4AF37]/30 rounded-xl text-center text-gray-300 hover:text-[#D4AF37] transition-all"
                  >
                    😂 Blague
                  </button>
                  <button
                    onClick={() => handleQuickCommand("encourage")}
                    className="py-1.5 px-2 bg-white/5 hover:bg-[#D4AF37]/10 border border-[#D4AF37]/10 hover:border-[#D4AF37]/30 rounded-xl text-center text-gray-300 hover:text-[#D4AF37] transition-all"
                  >
                    ✨ Boost
                  </button>
                </div>

                {/* Custom speech input */}
                <form onSubmit={handleCustomSubmit} className="flex gap-2">
                  <input
                    type="text"
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder="Discuter avec Auralis..."
                    className="flex-1 bg-[#222] border border-[#D4AF37]/15 focus:border-[#D4AF37]/40 rounded-xl px-3 py-2 text-xs text-white placeholder-gray-500 outline-none transition-all"
                  />
                  <button
                    type="submit"
                    className="p-2 bg-gradient-to-r from-[#D4AF37] to-[#F0C940] hover:scale-105 active:scale-95 text-[#0A0A0A] rounded-xl font-bold transition-all"
                  >
                    <Mic size={14} />
                  </button>
                </form>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Small minimized floating bubble trigger (AI refuge with House icon) */}
        <motion.button
          onClick={() => setIsExpanded(!isExpanded)}
          whileHover={{ scale: 1.08 }}
          whileTap={{ scale: 0.95 }}
          className="pointer-events-auto w-16 h-16 rounded-full flex items-center justify-center bg-[#161616] border border-[#D4AF37]/50 relative overflow-hidden group shadow-2xl"
          style={{ boxShadow: "0 8px 30px rgba(0,0,0,0.5), 0 0 20px rgba(212,175,55,0.25)" }}
        >
          {/* Subtle ring aura */}
          <div className="absolute inset-0 border border-[#D4AF37]/20 rounded-full group-hover:scale-110 transition-transform duration-300 bg-gradient-to-tr from-[#D4AF37]/10 to-transparent" />
          
          <div className="absolute inset-2 pointer-events-none rounded-full overflow-hidden flex items-center justify-center bg-black/60 shadow-inner">
            {/* Real 3D-feeling golden house refuge icon */}
            <Home className="w-6 h-6 text-[#D4AF37] drop-shadow-[0_0_8px_rgba(212,175,55,0.6)] group-hover:scale-115 transition-transform duration-300" />
          </div>

          {/* Sparkle icon indicator on top */}
          <div className="absolute top-1 right-1 bg-gradient-to-r from-[#D4AF37] to-[#F5D061] text-black rounded-full p-0.5 shadow-md animate-pulse">
            <Sparkles size={8} />
          </div>
        </motion.button>
      </div>
    </div>
  );
}
