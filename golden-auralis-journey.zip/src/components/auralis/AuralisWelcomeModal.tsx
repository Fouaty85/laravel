import { useEffect, useState, Suspense, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";
import { useAvatarScenario } from "@/hooks/useAvatarScenario";
import { useAuralisStore } from "@/hooks/useAuralisAvatar";
import AuralisAvatar from "@/components/auralis/AuralisAvatar";

interface Props {
  prenom?: string;
  autoCloseMs?: number; // default 14000ms for safety fallback
}

export default function AuralisWelcomeModal({ prenom, autoCloseMs = 14000 }: Props) {
  const [isOpen, setIsOpen] = useState(true);
  const { scenarioBienvenuePage, cancelScenario } = useAvatarScenario();
  const isTalking = useAuralisStore((s) => s.isTalking);
  const [hasStartedSpeaking, setHasStartedSpeaking] = useState(false);

  const handleClose = useCallback(() => {
    cancelScenario();
    setIsOpen(false);
  }, [cancelScenario]);

  useEffect(() => {
    if (isTalking) {
      setHasStartedSpeaking(true);
    }
  }, [isTalking]);

  useEffect(() => {
    if (!isOpen) return;

    // Slight delay to allow GLB to display smoothly
    const timer = setTimeout(() => {
      scenarioBienvenuePage(prenom);
    }, 400);

    return () => {
      clearTimeout(timer);
    };
  }, [isOpen, prenom, scenarioBienvenuePage]);

  useEffect(() => {
    if (!isOpen) return;

    // Fallback auto-close countdown in case speech synthesis fails
    const closeTimer = setTimeout(() => {
      if (!isTalking) {
        handleClose();
      }
    }, autoCloseMs);

    return () => {
      clearTimeout(closeTimer);
    };
  }, [isOpen, autoCloseMs, isTalking, handleClose]);

  useEffect(() => {
    if (hasStartedSpeaking && !isTalking && isOpen) {
      // Speech has finished! Auto-close after a comfortable 2.5s pause so the user can see/hear everything.
      const finishTimer = setTimeout(() => {
        handleClose();
      }, 2500);
      return () => clearTimeout(finishTimer);
    }
  }, [hasStartedSpeaking, isTalking, isOpen, handleClose]);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop blur overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-[9998]"
            style={{ background: "rgba(0,0,0,0.6)", backdropFilter: "blur(4px)" }}
            onClick={handleClose}
          />

          {/* Modal Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: "-40%", x: "-50%" }}
            animate={{ opacity: 1, scale: 1, y: "-50%", x: "-50%" }}
            exit={{ opacity: 0, scale: 0.9, y: "-45%", x: "-50%" }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
            className="fixed z-[9999] left-1/2 top-1/2"
            style={{ transform: "translate(-50%, -50%)" }}
          >
            <div
              style={{
                width: "min(480px, 92vw)",
                background: "rgba(26,26,26,0.97)",
                border: "1px solid rgba(212,175,55,0.3)",
                borderRadius: 24,
                boxShadow: "0 0 60px rgba(212,175,55,0.2), 0 24px 80px rgba(0,0,0,0.8)",
                overflow: "hidden",
                display: "flex",
                flexDirection: "column",
              }}
            >
              {/* Header */}
              <div
                style={{
                  padding: "20px 24px 0",
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <div
                    style={{
                      width: 8,
                      height: 8,
                      background: "#D4AF37",
                      borderRadius: "50%",
                      boxShadow: "0 0 8px #D4AF37",
                      animation: "pulse 2s infinite",
                    }}
                  />
                  <span
                    style={{
                      color: "#D4AF37",
                      fontSize: 13,
                      fontWeight: 600,
                      letterSpacing: "0.05em",
                    }}
                  >
                    AURALIS
                  </span>
                </div>
                <button
                  onClick={handleClose}
                  style={{
                    background: "rgba(255,255,255,0.05)",
                    border: "none",
                    borderRadius: "50%",
                    width: 32,
                    height: 32,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    cursor: "pointer",
                    color: "#A0A0A0",
                    transition: "all 0.2s",
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(212,175,55,0.1)")}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "rgba(255,255,255,0.05)")}
                >
                  <X size={16} />
                </button>
              </div>

              {/* Avatar section */}
              <div style={{ height: 260, position: "relative" }}>
                {/* Background gradient behind the avatar */}
                <div
                  style={{
                    position: "absolute",
                    inset: 0,
                    background:
                      "radial-gradient(ellipse at center bottom, rgba(212,175,55,0.08) 0%, transparent 70%)",
                  }}
                />
                <Suspense
                  fallback={
                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        height: "100%",
                      }}
                    >
                      <div
                        style={{
                          width: 40,
                          height: 40,
                          borderRadius: "50%",
                          border: "2px solid rgba(212,175,55,0.3)",
                          borderTop: "2px solid #D4AF37",
                          animation: "spin 1s linear infinite",
                        }}
                      />
                    </div>
                  }
                >
                  <AuralisAvatar size="medium" locked={true} className="w-full h-full" />
                </Suspense>
              </div>

              {/* Text and CTAs */}
              <div style={{ padding: "16px 24px 24px", textAlign: "center" }}>
                <h2 style={{ color: "#FFFFFF", fontSize: 22, fontWeight: 700, margin: "0 0 8px" }}>
                  {prenom ? `Bienvenue, ${prenom} ! 👋` : "Bienvenue sur AURALIS ! 👋"}
                </h2>
                <p style={{ color: "#A0A0A0", fontSize: 14, margin: "0 0 20px", lineHeight: 1.6 }}>
                  Je suis <span style={{ color: "#D4AF37", fontWeight: 600 }}>Auralis</span>, votre
                  compagnon d'apprentissage intelligent. Je suis là pour vous guider à chaque étape.
                </p>

                {/* Progress bar countdown */}
                <div
                  style={{
                    background: "rgba(255,255,255,0.05)",
                    borderRadius: 4,
                    height: 3,
                    marginBottom: 16,
                    overflow: "hidden",
                  }}
                >
                  <motion.div
                    initial={{ width: "100%" }}
                    animate={{ width: "0%" }}
                    transition={{ duration: autoCloseMs / 1000, ease: "linear" }}
                    style={{ height: "100%", background: "#D4AF37", borderRadius: 4 }}
                  />
                </div>

                <div style={{ display: "flex", gap: 10 }}>
                  <button
                    onClick={handleClose}
                    style={{
                      flex: 1,
                      padding: "12px",
                      borderRadius: 12,
                      background: "rgba(212,175,55,0.1)",
                      border: "1px solid rgba(212,175,55,0.3)",
                      color: "#A0A0A0",
                      cursor: "pointer",
                      fontSize: 13,
                      transition: "all 0.2s",
                    }}
                  >
                    Fermer
                  </button>
                  <button
                    onClick={handleClose}
                    style={{
                      flex: 2,
                      padding: "12px",
                      borderRadius: 12,
                      background: "linear-gradient(135deg, #D4AF37, #F0C940)",
                      border: "none",
                      color: "#0A0A0A",
                      cursor: "pointer",
                      fontSize: 14,
                      fontWeight: 700,
                      transition: "all 0.2s",
                    }}
                  >
                    C'est parti ! 🚀
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
