import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuralisStore } from "@/hooks/useAuralisAvatar";
import { useAvatarScenario } from "@/hooks/useAvatarScenario";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import {
  Sparkles,
  Search,
  BookOpen,
  CheckCircle,
  Video,
  Phone,
  PhoneOff,
  Volume2,
  Home as HomeIcon,
  HelpCircle,
  Award,
  ChevronRight,
  ChevronLeft,
  X
} from "lucide-react";
import { toast } from "sonner";
import AuralisAvatar from "./AuralisAvatar";

interface Course {
  id: string;
  titre: string;
  description: string;
  niveau: string;
}

const QUESTIONS_MAP: Record<string, { q: string; opts: string[]; ans: number }[]> = {
  React: [
    {
      q: "Qu'est-ce qu'un composant fonctionnel en React ?",
      opts: ["Une fonction qui retourne du JSX", "Une classe CSS", "Une base de données temporaire"],
      ans: 0
    },
    {
      q: "Comment met-on à jour l'état (state) en React ?",
      opts: ["En modifiant directement la variable", "Via le setter fourni par le hook useState", "En rechargeant la page entière"],
      ans: 1
    },
    {
      q: "Quel hook React est dédié à la gestion des effets secondaires ?",
      opts: ["useContext", "useMemo", "useEffect"],
      ans: 2
    }
  ],
  Python: [
    {
      q: "Comment déclare-t-on une fonction en Python ?",
      opts: ["function ma_fonction():", "def ma_fonction():", "void ma_fonction() {}"],
      ans: 1
    },
    {
      q: "Quelle structure de données est immuable en Python ?",
      opts: ["Les listes [1, 2]", "Les tuples (1, 2)", "Les dictionnaires {key: val}"],
      ans: 1
    },
    {
      q: "Quelle fonction permet de lire une entrée utilisateur en console ?",
      opts: ["read()", "input()", "get_line()"],
      ans: 1
    }
  ],
  SQL: [
    {
      q: "Quelle clause permet de filtrer les résultats d'une requête SELECT ?",
      opts: ["WHERE", "GROUP BY", "ORDER BY"],
      ans: 0
    },
    {
      q: "Quel mot-clé supprime les doublons d'un SELECT ?",
      opts: ["UNIQUE", "DISTINCT", "DIVERSE"],
      ans: 1
    },
    {
      q: "Comment ajoute-t-on une nouvelle ligne dans une table ?",
      opts: ["ADD ROW", "INSERT INTO", "UPDATE SET"],
      ans: 1
    }
  ]
};

export default function ApprenantTutorial() {
  const { user, profile } = useAuth();
  const { speak, cancelScenario, playScenario } = useAvatarScenario();
  const isTalking = useAuralisStore((s) => s.isTalking);

  const [isActive, setIsActive] = useState(false);
  const [step, setStep] = useState<"intro" | "spotlight-sidebar" | "spotlight-stats" | "spotlight-recom" | "search" | "test" | "congrats" | "done">("done");
  const [spotlightIndex, setSpotlightIndex] = useState(0);

  // Search state
  const [searchQuery, setSearchQuery] = useState("");
  const [matchingCourse, setMatchingCourse] = useState<Course | null>(null);
  const [noCourseFound, setNoCourseFound] = useState(false);

  // Call test state
  const [selectedSubject, setSelectedSubject] = useState("");
  const [testQuestionIndex, setTestQuestionIndex] = useState(0);
  const [answersCount, setAnswersCount] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);

  // Little House Retreat State
  const [houseOpen, setHouseOpen] = useState(false);
  const [isAvatarAtHome, setIsAvatarAtHome] = useState(false);
  const [houseText, setHouseText] = useState("");

  useEffect(() => {
    const trigger = sessionStorage.getItem("show_apprenant_tutorial");
    if (trigger === "true" && user) {
      sessionStorage.removeItem("show_apprenant_tutorial");
      startTutorial();
    }
  }, [user]);

  const startTutorial = () => {
    setIsActive(true);
    setStep("intro");
    playIntroSpeech();
  };

  const playIntroSpeech = () => {
    playScenario([
      { gesture: "wave", expression: "smile_big", duration: 500 },
      {
        gesture: "talking",
        expression: "smile_medium",
        speech: `Bonjour ${profile?.prenom || ""} ! Je suis Auralis, ton assistant IA d'apprentissage en 3D. Bienvenue dans ton espace ! Laisse-moi te faire visiter l'application pour que tu saches tout maîtriser en un clin d'œil.`,
        waitForSpeech: true
      },
      { gesture: "idle", expression: "smile_light" }
    ]);
  };

  const handleNextSpotlight = () => {
    if (step === "intro") {
      setStep("spotlight-sidebar");
      playScenario([
        { gesture: "point", expression: "neutral", duration: 400 },
        {
          gesture: "talking",
          expression: "smile_light",
          speech: "À gauche se trouve ta barre de navigation. Elle te permet d'accéder instantanément à ton tableau de bord, tes cours, ton classement de promotion, tes messages et tes notifications.",
          waitForSpeech: true
        }
      ]);
    } else if (step === "spotlight-sidebar") {
      setStep("spotlight-stats");
      playScenario([
        { gesture: "nod", expression: "smile_light", duration: 400 },
        {
          gesture: "talking",
          expression: "smile_medium",
          speech: "Juste ici, tu as ton tableau de bord de progression : tes statistiques de cours actifs, tes diplômes ou cours terminés, ton compteur de streak quotidien pour rester motivé, et tes points d'expérience !",
          waitForSpeech: true
        }
      ]);
    } else if (step === "spotlight-stats") {
      setStep("spotlight-recom");
      playScenario([
        { gesture: "celebrate", expression: "smile_big", duration: 400 },
        {
          gesture: "talking",
          expression: "smile_big",
          speech: "Et en bas, tu as les recommandations de cours. Notre IA analyse constamment ton niveau pour te suggérer les cours les plus adaptés à tes objectifs.",
          waitForSpeech: true
        }
      ]);
    } else if (step === "spotlight-recom") {
      setStep("search");
      playScenario([
        { gesture: "thinking", expression: "thinking", duration: 400 },
        {
          gesture: "talking",
          expression: "neutral",
          speech: "Maintenant, c'est à toi ! Quel cours souhaites-tu apprendre aujourd'hui ? Indique-le moi dans la barre de recherche !",
          waitForSpeech: true
        }
      ]);
    }
  };

  const handleSkip = () => {
    cancelScenario();
    setStep("search");
    playScenario([
      { gesture: "nod", expression: "smile_medium", speech: "Pas de soucis ! Allons droit au but. Quel cours t'intéresse aujourd'hui ?" }
    ]);
  };

  const handleSearchCourse = async () => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return;

    // Check availability
    let matchKey = "";
    if (q.includes("react")) matchKey = "React";
    else if (q.includes("python")) matchKey = "Python";
    else if (q.includes("sql") || q.includes("base")) matchKey = "SQL";
    else if (q.includes("html") || q.includes("css") || q.includes("web")) matchKey = "React"; // Fallback to React style for web

    if (matchKey) {
      setSelectedSubject(matchKey);
      setNoCourseFound(false);
      setStep("test");
      setTestQuestionIndex(0);
      setAnswersCount(0);
      setCorrectCount(0);

      playScenario([
        { gesture: "celebrate", expression: "smile_big", duration: 400 },
        {
          gesture: "talking",
          expression: "smile_medium",
          speech: `Excellent choix ! Le cours de ${matchKey} est disponible sur AURALIS. Voyons voir tes compétences actuelles dans ce domaine lors d'un test vocal rapide !`,
          waitForSpeech: true
        },
        {
          gesture: "talking",
          expression: "smile_light",
          speech: "Connexion téléphonique établie avec ton coach Auralis... C'est parti !",
          waitForSpeech: true
        }
      ]);
    } else {
      setNoCourseFound(true);
      playScenario([
        { gesture: "headShake", expression: "concerned", duration: 400 },
        {
          gesture: "talking",
          expression: "concerned",
          speech: `Aïe, le cours de "${searchQuery}" n'est pas encore directement disponible sur AURALIS. Mais j'ai cherché pour toi sur YouTube : voici un excellent tutoriel recommandé pour commencer dès aujourd'hui !`,
          waitForSpeech: true
        }
      ]);
    }
  };

  const handleAnswerTest = (optIndex: number) => {
    const questions = QUESTIONS_MAP[selectedSubject];
    const currentQ = questions[testQuestionIndex];
    const isCorrect = optIndex === currentQ.ans;

    setAnswersCount((prev) => prev + 1);
    if (isCorrect) {
      setCorrectCount((prev) => prev + 1);
      playScenario([
        { gesture: "nod", expression: "smile_big", duration: 300 },
        { gesture: "talking", expression: "smile_big", speech: "Merveilleux ! C'est exactement cela !", waitForSpeech: true }
      ]);
    } else {
      playScenario([
        { gesture: "headShake", expression: "concerned", duration: 300 },
        { gesture: "talking", expression: "concerned", speech: "Presque ! Mais pas tout à fait. Continuons !", waitForSpeech: true }
      ]);
    }

    if (testQuestionIndex < questions.length - 1) {
      setTestQuestionIndex((prev) => prev + 1);
    } else {
      // Test complete
      setStep("congrats");
      saveEnrollmentAndNotify();
    }
  };

  const saveEnrollmentAndNotify = async () => {
    if (!user) return;
    const computedLevel = correctCount >= 2 ? "intermediaire" : correctCount === 3 ? "avance" : "debutant";
    const levelLabelFr = computedLevel === "intermediaire" ? "Intermédiaire" : computedLevel === "avance" ? "Avancé" : "Débutant";

    try {
      // 1. Fetch matching course from database
      const { data: courses } = await supabase
        .from("courses")
        .select("*")
        .ilike("titre", `%${selectedSubject}%`)
        .limit(1);

      let courseId = "";
      if (courses && courses.length > 0) {
        courseId = courses[0].id;
        // Enroll student
        await supabase.from("enrollments").insert([
          {
            profile_id: user.id,
            course_id: courseId,
            progression: 10,
            adjusted_level: computedLevel
          }
        ]);
      }

      // 2. Insert real-time notification for the instructor
      await supabase.from("notifications").insert([
        {
          user_id: user.id, // linked to student activity
          title: "Nouvel Apprenant Inscrit !",
          message: `L'apprenant ${profile?.prenom || "Un étudiant"} vient de passer son test initial de ${selectedSubject} et s'est inscrit à votre cours au niveau ${levelLabelFr} !`,
          is_read: false
        }
      ]);

      playScenario([
        { gesture: "celebrate", expression: "smile_big", duration: 400 },
        {
          gesture: "talking",
          expression: "smile_big",
          speech: `Félicitations ! Tu as validé ${correctCount} réponses sur 3. J'évalue ton niveau actuel comme ${levelLabelFr}. Je viens de t'inscrire au cours officiel de ${selectedSubject} et d'informer ton formateur de ton arrivée ! Bonne chance pour ton apprentissage !`,
          waitForSpeech: true
        },
        {
          gesture: "talking",
          expression: "smile_medium",
          speech: "Maintenant, je me retire dans ma petite maison située en bas à droite de l'écran. Si tu as besoin de conseils, de quiz rapides ou d'un conseil de méthodologie, clique simplement sur ma maison pour m'appeler !",
          waitForSpeech: true
        }
      ]);

      toast.success(`Inscription au cours de ${selectedSubject} au niveau ${levelLabelFr} !`);
    } catch (err) {
      console.error(err);
    }
  };

  const finishTutorial = () => {
    setIsActive(false);
    setIsAvatarAtHome(true);
    setStep("done");
  };

  // House click interactions
  const handleHouseClick = () => {
    setHouseOpen(true);
    const options = [
      "Bonjour ! Que puis-je faire pour toi aujourd'hui ?",
      "Besoin d'aide pour tes cours ? Je suis toujours là !",
      "Prêt pour un petit quiz éclair pour booster ta mémoire ?"
    ];
    const speech = options[Math.floor(Math.random() * options.length)];
    setHouseText(speech);
    playScenario([
      { gesture: "wave", expression: "smile_big", duration: 300 },
      { gesture: "talking", expression: "smile_medium", speech, waitForSpeech: true }
    ]);
  };

  const handleHouseAction = (action: string) => {
    if (action === "quiz") {
      setHouseText("Super ! Quel est le symbole principal pour l'affectation en Python ? Réponse : le symbole '='");
      playScenario([
        { gesture: "nod", expression: "smile_medium", speech: "Super ! Sais-tu quel est le symbole principal pour l'affectation de variable en Python ? Réponse : c'est le signe '=' !", waitForSpeech: true }
      ]);
    } else if (action === "tip") {
      setHouseText("Conseil d'étude : Fais des sessions de 25 minutes suivies de 5 minutes de pause (Technique Pomodoro).");
      playScenario([
        { gesture: "point", expression: "smile_light", speech: "Voici un conseil en or : Fais des sessions d'étude concentrée de 25 minutes suivies de 5 minutes de pause. C'est la technique Pomodoro !", waitForSpeech: true }
      ]);
    } else if (action === "reset") {
      setHouseOpen(false);
      startTutorial();
    }
  };

  return (
    <>
      {/* 1. TUTORIAL ACTIVE OVERLAYS */}
      <AnimatePresence>
        {isActive && (
          <div className="fixed inset-0 z-[9998] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
            <div className="w-full max-w-4xl bg-[#121212]/95 border border-[#D4AF37]/30 rounded-3xl overflow-hidden shadow-2xl flex flex-col md:flex-row h-auto md:h-[540px]">
              {/* Left Column: 3D Avatar Rendering inside the wizard */}
              <div className="w-full md:w-1/2 bg-black/60 relative h-[220px] md:h-full flex items-center justify-center border-b md:border-b-0 md:border-r border-[#D4AF37]/15">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(212,175,55,0.05),transparent)]" />
                <div className="w-full h-full p-4 flex items-center justify-center">
                  <AuralisAvatar size="medium" locked={true} className="w-full h-full" />
                </div>
                {isTalking && (
                  <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-[#D4AF37]/20 border border-[#D4AF37] px-3 py-1 rounded-full text-[10px] text-[#D4AF37] font-mono tracking-widest uppercase animate-pulse">
                    🎤 Auralis parle...
                  </div>
                )}
              </div>

              {/* Right Column: Steps / Wizard details */}
              <div className="w-full md:w-1/2 p-8 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-6">
                    <Sparkles className="text-[#D4AF37] animate-pulse" size={18} />
                    <span className="text-xs uppercase font-mono tracking-widest text-[#D4AF37]">Assistant Intelligent AURALIS</span>
                  </div>

                  {step === "intro" && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                      <h2 className="text-2xl font-bold text-white font-[Space_Grotesk]">Découvre ton compagnon de réussite</h2>
                      <p className="text-gray-300 text-sm leading-relaxed">
                        Bienvenue ! Je suis <strong>Auralis</strong>, ton coach d'apprentissage personnel. Mon but est de t'accompagner à chaque étape, tester tes compétences de manière vivante et interactive, et t'aider à progresser plus vite.
                      </p>
                    </motion.div>
                  )}

                  {step === "spotlight-sidebar" && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                      <h2 className="text-2xl font-bold text-white font-[Space_Grotesk]">1. Ta Navigation Intuitive</h2>
                      <p className="text-gray-300 text-sm leading-relaxed">
                        Le menu latéral gauche est ton centre de commande. Tu y trouveras :
                      </p>
                      <ul className="text-xs text-gray-400 space-y-2 pl-4 list-disc">
                        <li><strong>Tableau de bord</strong> : Vos statistiques et progression globale.</li>
                        <li><strong>Mes cours</strong> : Inscription, filtres de recherche et chapitres actifs.</li>
                        <li><strong>Classement</strong> : Suis ton évolution face aux autres apprenants.</li>
                        <li><strong>Messages</strong> : Communique avec les formateurs et élèves.</li>
                      </ul>
                    </motion.div>
                  )}

                  {step === "spotlight-stats" && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                      <h2 className="text-2xl font-bold text-white font-[Space_Grotesk]">2. Tes Statistiques de Progression</h2>
                      <p className="text-gray-300 text-sm leading-relaxed">
                        Chaque minute passée à réviser est récompensée ! Ton tableau de bord affiche ton temps cumulé, tes badges gagnés et ton <strong>Streak quotidien</strong>. Garde la flamme active chaque jour pour doubler tes récompenses !
                      </p>
                    </motion.div>
                  )}

                  {step === "spotlight-recom" && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                      <h2 className="text-2xl font-bold text-white font-[Space_Grotesk]">3. Recommandations Prédictives IA</h2>
                      <p className="text-gray-300 text-sm leading-relaxed">
                        Pas besoin de chercher quel sujet travailler. Auralis analyse tes forces et tes lacunes après chaque quiz et adapte automatiquement de nouvelles suggestions de cours adaptées sur-mesure pour toi.
                      </p>
                    </motion.div>
                  )}

                  {step === "search" && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                      <h2 className="text-2xl font-bold text-white font-[Space_Grotesk]">Quel cours souhaites-tu apprendre ?</h2>
                      <p className="text-gray-300 text-sm mb-3">
                        Saisis un sujet comme "React", "Python" ou "SQL" pour démarrer ton test initial avec moi !
                      </p>
                      <div className="flex gap-2 bg-[#1a1a1a] border border-white/10 rounded-2xl p-2">
                        <Search className="text-gray-500 m-2" size={18} />
                        <input
                          type="text"
                          placeholder="Rechercher un cours..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          onKeyDown={(e) => e.key === "Enter" && handleSearchCourse()}
                          className="bg-transparent border-0 outline-none text-white text-sm flex-1"
                        />
                        <button
                          onClick={handleSearchCourse}
                          className="bg-[#D4AF37] hover:bg-[#F5D061] text-black px-4 py-1.5 rounded-xl text-xs font-bold transition-all"
                        >
                          Rechercher
                        </button>
                      </div>

                      {/* Popular suggestions */}
                      <div className="flex flex-wrap gap-1.5 mt-2">
                        {["React", "Python", "SQL"].map((subj) => (
                          <button
                            key={subj}
                            onClick={() => { setSearchQuery(subj); setSelectedSubject(subj); }}
                            className="text-[10px] bg-white/5 border border-white/10 hover:border-[#D4AF37]/50 hover:text-[#D4AF37] px-2.5 py-1 rounded-full transition-all text-gray-400"
                          >
                            #{subj}
                          </button>
                        ))}
                      </div>

                      {noCourseFound && (
                        <motion.div initial={{ opacity: 0 }} className="p-4 bg-amber-950/20 border border-amber-900/40 rounded-2xl flex flex-col gap-3 mt-4">
                          <p className="text-xs text-amber-200">
                            Mince ! Le cours de <strong>"{searchQuery}"</strong> n'est pas encore sur AURALIS, mais voici un cours recommandé sur YouTube pour vous aider immédiatement :
                          </p>
                          <a
                            href={`https://www.youtube.com/results?search_query=${encodeURIComponent(searchQuery + " tutoriel complet fr")}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="bg-red-600 hover:bg-red-700 text-white flex items-center justify-center gap-2 py-2 rounded-xl text-xs font-bold transition-all"
                          >
                            <Video size={14} /> Consulter sur YouTube
                          </a>
                        </motion.div>
                      )}
                    </motion.div>
                  )}

                  {step === "test" && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                      {/* Fake Telephone Call screen */}
                      <div className="bg-black/80 border border-[#D4AF37]/20 rounded-2xl p-4 text-center space-y-3 relative overflow-hidden">
                        <div className="absolute top-2 right-2 flex items-center gap-1 bg-[#D4AF37]/10 border border-[#D4AF37]/20 px-2 py-0.5 rounded-full">
                          <div className="w-1.5 h-1.5 bg-[#D4AF37] rounded-full animate-ping" />
                          <span className="text-[9px] text-[#D4AF37] font-mono uppercase">Appel direct</span>
                        </div>

                        <div className="w-10 h-10 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center mx-auto animate-bounce">
                          <Volume2 size={20} />
                        </div>
                        <p className="text-xs font-mono text-gray-500">Test vocal - Niveau actuel</p>
                        <h4 className="font-semibold text-sm text-white px-2 leading-relaxed">
                          "{QUESTIONS_MAP[selectedSubject]?.[testQuestionIndex]?.q}"
                        </h4>
                      </div>

                      {/* Custom multiple choice options */}
                      <div className="space-y-2 mt-4">
                        {QUESTIONS_MAP[selectedSubject]?.[testQuestionIndex]?.opts.map((opt, idx) => (
                          <button
                            key={idx}
                            onClick={() => handleAnswerTest(idx)}
                            className="w-full text-left bg-white/5 hover:bg-[#D4AF37]/10 border border-white/5 hover:border-[#D4AF37]/30 p-3.5 rounded-xl text-xs text-gray-300 hover:text-white transition-all flex items-center gap-3"
                          >
                            <div className="w-5 h-5 rounded-full bg-black/40 border border-white/10 flex items-center justify-center text-[10px] text-gray-400 font-bold font-mono">
                              {String.fromCharCode(65 + idx)}
                            </div>
                            <span>{opt}</span>
                          </button>
                        ))}
                      </div>
                    </motion.div>
                  )}

                  {step === "congrats" && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                      <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto mb-4 animate-bounce">
                        <Award size={36} />
                      </div>
                      <h2 className="text-2xl font-bold text-white text-center font-[Space_Grotesk]">Test Final Terminé !</h2>
                      <p className="text-gray-300 text-sm leading-relaxed text-center">
                        Excellent travail ! Tu as répondu avec succès à nos questions d'évaluation. J'ai configuré ton cours de <strong>{selectedSubject}</strong> avec un niveau personnalisé et envoyé une notification instantanée à ton formateur.
                      </p>
                    </motion.div>
                  )}
                </div>

                {/* Footer buttons */}
                <div className="flex justify-between items-center border-t border-white/5 pt-4 mt-6">
                  {step !== "test" && step !== "congrats" && (
                    <button
                      onClick={handleSkip}
                      className="text-xs text-gray-400 hover:text-white transition-colors"
                    >
                      Sauter tout le tutoriel
                    </button>
                  )}

                  {step !== "search" && step !== "test" && step !== "congrats" && (
                    <button
                      onClick={handleNextSpotlight}
                      className="bg-gradient-to-r from-[#D4AF37] to-amber-500 hover:from-amber-500 hover:to-amber-600 text-black px-6 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all shadow-lg"
                    >
                      Continuer <ChevronRight size={14} />
                    </button>
                  )}

                  {step === "congrats" && (
                    <button
                      onClick={finishTutorial}
                      className="w-full bg-emerald-500 hover:bg-emerald-600 text-white py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-lg"
                    >
                      <CheckCircle size={14} /> Commencer mon apprentissage
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </AnimatePresence>

      {/* 2. MINIMIZED FLOATING HOUSE RETREAT (Bottom Right) */}
      {isAvatarAtHome && (
        <div className="fixed bottom-24 right-6 z-[9999] pointer-events-none flex flex-col items-end gap-3">
          {/* Subtle house dialogue bubble */}
          <AnimatePresence>
            {houseOpen && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="pointer-events-auto w-[280px] bg-black/95 border border-[#D4AF37]/40 rounded-2xl p-4 shadow-2xl space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs text-[#D4AF37] font-bold">
                    <Sparkles size={12} /> Maison d'Auralis
                  </div>
                  <button onClick={() => setHouseOpen(false)} className="text-gray-500 hover:text-white">
                    <X size={14} />
                  </button>
                </div>
                <p className="text-xs text-white leading-relaxed">
                  {houseText || "Salut ! Je me repose dans mon chalet. De quoi as-tu besoin aujourd'hui ?"}
                </p>

                <div className="grid grid-cols-2 gap-1.5 text-[10px]">
                  <button
                    onClick={() => handleHouseAction("quiz")}
                    className="py-1.5 px-2 bg-white/5 hover:bg-[#D4AF37]/10 border border-white/5 hover:border-[#D4AF37]/20 rounded-lg text-gray-300 hover:text-white transition-all text-center"
                  >
                    💡 Quiz éclair
                  </button>
                  <button
                    onClick={() => handleHouseAction("tip")}
                    className="py-1.5 px-2 bg-white/5 hover:bg-[#D4AF37]/10 border border-white/5 hover:border-[#D4AF37]/20 rounded-lg text-gray-300 hover:text-white transition-all text-center"
                  >
                    🧠 Conseil d'étude
                  </button>
                  <button
                    onClick={() => handleHouseAction("reset")}
                    className="col-span-2 py-1.5 bg-[#D4AF37]/10 hover:bg-[#D4AF37]/20 border border-[#D4AF37]/20 text-[#D4AF37] rounded-lg transition-all text-center font-semibold"
                  >
                    🔄 Rejouer le tutoriel
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Glowing House button */}
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            onClick={houseOpen ? () => setHouseOpen(false) : handleHouseClick}
            className="pointer-events-auto w-12 h-12 bg-gradient-to-br from-neutral-900 to-[#121212] border-2 border-[#D4AF37]/40 hover:border-[#D4AF37] rounded-2xl flex items-center justify-center text-[#D4AF37] shadow-xl relative overflow-hidden group transition-all"
            style={{ boxShadow: "0 0 20px rgba(212,175,55,0.15)" }}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-[#D4AF37]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <HomeIcon size={20} className="relative z-10 transition-transform group-hover:rotate-6" />
          </motion.button>
        </div>
      )}
    </>
  );
}
