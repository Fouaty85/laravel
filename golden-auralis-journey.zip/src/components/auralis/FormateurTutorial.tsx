import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuralisStore } from "@/hooks/useAuralisAvatar";
import { useAvatarScenario } from "@/hooks/useAvatarScenario";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import {
  Sparkles,
  BookOpen,
  PlusCircle,
  Users,
  Bell,
  MessageSquare,
  Award,
  ChevronRight,
  HelpCircle,
  FileText,
  AlertTriangle,
  Play,
  GraduationCap
} from "lucide-react";
import { toast } from "sonner";
import AuralisAvatar from "./AuralisAvatar";

export default function FormateurTutorial() {
  const { user, profile } = useAuth();
  const { speak, cancelScenario, playScenario } = useAvatarScenario();
  const isTalking = useAuralisStore((s) => s.isTalking);

  const [isActive, setIsActive] = useState(false);
  const [step, setStep] = useState<"intro" | "spotlight-sidebar" | "add-course" | "alerts" | "forum" | "simulate" | "done">("done");

  // Mock simulation values
  const [simNewCourseTitle, setSimNewCourseTitle] = useState("");
  const [simQuizCount, setSimQuizCount] = useState(2);
  const [hasFinalExam, setHasFinalExam] = useState(true);

  useEffect(() => {
    const trigger = sessionStorage.getItem("show_formateur_tutorial");
    if (trigger === "true" && user) {
      sessionStorage.removeItem("show_formateur_tutorial");
      startTutorial();
    }
  }, [user]);

  const startTutorial = () => {
    setIsActive(true);
    setStep("intro");
    playIntroSpeech();
  };

  const playIntroSpeech = () => {
    playScenario([
      { gesture: "wave", expression: "smile_big", duration: 500 },
      {
        gesture: "talking",
        expression: "smile_medium",
        speech: `Bonjour cher Formateur ${profile?.prenom || ""} ! Je suis Auralis. Bienvenue dans votre tableau de bord d'enseignant augmenté par l'IA. Laissez-moi vous guider à travers vos nouveaux superpouvoirs pédagogiques !`,
        waitForSpeech: true
      }
    ]);
  };

  const handleNextSpotlight = () => {
    if (step === "intro") {
      setStep("spotlight-sidebar");
      playScenario([
        { gesture: "point", expression: "neutral", duration: 400 },
        {
          gesture: "talking",
          expression: "smile_light",
          speech: "Votre interface est optimisée pour la gestion. Vous pouvez suivre vos apprenants actifs, consulter vos cours en ligne et répondre à leurs questions.",
          waitForSpeech: true
        }
      ]);
    } else if (step === "spotlight-sidebar") {
      setStep("add-course");
      playScenario([
        { gesture: "nod", expression: "smile_medium", duration: 400 },
        {
          gesture: "talking",
          expression: "smile_medium",
          speech: "Ici, vous pouvez ajouter vos propres cours. Pour chaque module, vous avez la possibilité d'ajouter des quizz d'évaluation après chaque chapitre et de programmer un examen final pour vos étudiants.",
          waitForSpeech: true
        }
      ]);
    } else if (step === "add-course") {
      setStep("alerts");
      playScenario([
        { gesture: "crossArms", expression: "concerned", duration: 400 },
        {
          gesture: "talking",
          expression: "concerned",
          speech: "Et voici l'avantage unique d'Auralis. Mon algorithme surveille le temps d'étude de chaque élève. Si un cours est délaissé, j'envoie automatiquement une alerte à l'élève pour le motiver ainsi qu'à vous-même pour un suivi de qualité !",
          waitForSpeech: true
        }
      ]);
    } else if (step === "alerts") {
      setStep("forum");
      playScenario([
        { gesture: "celebrate", expression: "smile_big", duration: 400 },
        {
          gesture: "talking",
          expression: "smile_big",
          speech: "De plus, un forum de discussion complet permet aux étudiants et à vous-même de dialoguer en direct pour débloquer toutes les difficultés d'apprentissage. Faisons une simulation rapide de création de cours !",
          waitForSpeech: true
        }
      ]);
    } else if (step === "forum") {
      setStep("simulate");
      playScenario([
        { gesture: "thinking", expression: "smile_light", duration: 400 },
        {
          gesture: "talking",
          expression: "smile_light",
          speech: "Essayez de saisir un titre de cours pour simuler l'enregistrement avec quizz et examen final dans la base d'Auralis !",
          waitForSpeech: true
        }
      ]);
    }
  };

  const handleSkip = () => {
    cancelScenario();
    setStep("simulate");
    playScenario([
      { gesture: "nod", expression: "smile_light", speech: "Parfait ! Faisons l'exercice de simulation de création de cours augmenté." }
    ]);
  };

  const handleSimulateSubmit = async () => {
    if (!simNewCourseTitle.trim()) {
      toast.error("Veuillez entrer un titre de cours pour la simulation");
      return;
    }

    try {
      if (user) {
        // Register course mock in Supabase if desired or trigger success UI
        await supabase.from("courses").insert([
          {
            titre: simNewCourseTitle,
            description: `Cours de niveau professionnel sur ${simNewCourseTitle} incluant ${simQuizCount} quiz et un examen final.`,
            niveau: "intermediaire",
            langue: "Français",
            duree_minutes: 180,
            profile_id: user.id
          }
        ]);
      }

      playScenario([
        { gesture: "celebrate", expression: "smile_big", duration: 400 },
        {
          gesture: "talking",
          expression: "smile_big",
          speech: `Félicitations ! Votre cours "${simNewCourseTitle}" a été créé avec succès, avec ses ${simQuizCount} quiz intermédiaires et son examen final de module. Tout est parfaitement prêt pour vos apprenants !`,
          waitForSpeech: true
        }
      ]);

      toast.success("Cours créé avec succès !");
      setStep("done");
    } catch (err) {
      console.error(err);
      toast.error("Erreur de simulation");
    }
  };

  const handleSimulateAlert = () => {
    playScenario([
      { gesture: "headShake", expression: "concerned", duration: 400 },
      {
        gesture: "talking",
        expression: "concerned",
        speech: "ALERTE IA : L'apprenant Thomas n'a pas ouvert son module de React depuis 5 jours. Un message de relance motivationnel automatique lui a été envoyé !",
        waitForSpeech: true
      }
    ]);
    toast.warning("Notification d'alerte d'abandon envoyée !");
  };

  const finishTutorial = () => {
    setIsActive(false);
    setStep("done");
  };

  return (
    <AnimatePresence>
      {isActive && (
        <div className="fixed inset-0 z-[9998] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
          <div className="w-full max-w-4xl bg-[#121212]/95 border border-blue-500/30 rounded-3xl overflow-hidden shadow-2xl flex flex-col md:flex-row h-auto md:h-[540px]">
            {/* Left Column: 3D Avatar Rendering */}
            <div className="w-full md:w-1/2 bg-black/60 relative h-[220px] md:h-full flex items-center justify-center border-b md:border-b-0 md:border-r border-blue-500/15">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(59,130,246,0.05),transparent)]" />
              <div className="w-full h-full p-4 flex items-center justify-center">
                <AuralisAvatar size="medium" locked={true} className="w-full h-full" />
              </div>
              {isTalking && (
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-blue-500/20 border border-blue-500 px-3 py-1 rounded-full text-[10px] text-blue-400 font-mono tracking-widest uppercase animate-pulse">
                  🎤 Auralis parle...
                </div>
              )}
            </div>

            {/* Right Column: Content panel */}
            <div className="w-full md:w-1/2 p-8 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 mb-6">
                  <Sparkles className="text-blue-400 animate-pulse" size={18} />
                  <span className="text-xs uppercase font-mono tracking-widest text-blue-400">Pédagogie Augmentée AURALIS</span>
                </div>

                {step === "intro" && (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                    <h2 className="text-2xl font-bold text-white font-[Space_Grotesk]">Pilotez vos formations avec l'IA</h2>
                    <p className="text-gray-300 text-sm leading-relaxed">
                      Bonjour et bienvenue ! En tant que formateur sur AURALIS, vous disposez d'un tableau de bord de pointe pour dispenser vos cours, tester vos étudiants avec des quiz et suivre l'implication de chacun en temps réel.
                    </p>
                  </motion.div>
                )}

                {step === "spotlight-sidebar" && (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                    <h2 className="text-2xl font-bold text-white font-[Space_Grotesk]">Gérez vos modules et étudiants</h2>
                    <p className="text-gray-300 text-sm leading-relaxed">
                      Le menu de gauche vous permet de naviguer dans l'espace formateur :
                    </p>
                    <ul className="text-xs text-gray-400 space-y-2 pl-4 list-disc">
                      <li><strong>Tableau de bord</strong> : Vos revenus, promotions actives et taux de complétion.</li>
                      <li><strong>Gérer mes cours</strong> : Publiez, éditez et ajoutez des chapitres en direct.</li>
                      <li><strong>Suivi des apprenants</strong> : Progrès individuels de chaque élève de votre classe.</li>
                    </ul>
                  </motion.div>
                )}

                {step === "add-course" && (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                    <h2 className="text-2xl font-bold text-white font-[Space_Grotesk]">Création enrichie de Quiz & Examens</h2>
                    <p className="text-gray-300 text-sm leading-relaxed">
                      L'application respecte les meilleures structures pédagogiques. Pour chaque cours, vous pouvez insérer des <strong>quizz de validation rapides</strong> après chaque chapitre pour valider la mémoire de travail, ainsi qu'un <strong>examen final</strong> de validation de compétences.
                    </p>
                  </motion.div>
                )}

                {step === "alerts" && (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                    <h2 className="text-2xl font-bold text-white font-[Space_Grotesk]">Système d'Alertes IA Anti-Abandon</h2>
                    <p className="text-gray-300 text-sm leading-relaxed">
                      Auralis surveille l'évolution des étudiants. Si un cours est délaissé par l'apprenant, je lui envoie des alertes de remobilisation adaptées, et je vous notifie immédiatement sur votre interface pour que vous puissiez intervenir.
                    </p>
                  </motion.div>
                )}

                {step === "forum" && (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                    <h2 className="text-2xl font-bold text-white font-[Space_Grotesk]">Forum de Discussion Synchrone</h2>
                    <p className="text-gray-300 text-sm leading-relaxed">
                      Favorisez la collaboration grâce au forum intégré ! Les élèves posent des questions, d'autres y répondent, et l'IA ou vous-même pouvez apporter des éclairages précis à tout moment.
                    </p>
                  </motion.div>
                )}

                {step === "simulate" && (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                    <h2 className="text-2xl font-bold text-white font-[Space_Grotesk]">Simulation de Création de Cours</h2>
                    <p className="text-gray-300 text-xs">
                      Saisissez le titre du cours pour lancer la simulation interactive d'Auralis :
                    </p>

                    <div className="space-y-3">
                      <div className="flex gap-2 bg-[#1a1a1a] border border-white/10 rounded-xl p-2">
                        <PlusCircle className="text-gray-500 m-1.5" size={16} />
                        <input
                          type="text"
                          placeholder="Nom du nouveau cours (ex: Tailwind CSS)..."
                          value={simNewCourseTitle}
                          onChange={(e) => setSimNewCourseTitle(e.target.value)}
                          className="bg-transparent border-0 outline-none text-white text-xs flex-1"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-3 text-xs">
                        <div className="bg-[#1a1a1a] p-2.5 rounded-xl border border-white/5 flex flex-col justify-between">
                          <span className="text-gray-400">Quiz intermédiaires</span>
                          <div className="flex items-center gap-2 mt-1">
                            <button onClick={() => setSimQuizCount(Math.max(1, simQuizCount - 1))} className="bg-white/10 px-2 py-0.5 rounded">-</button>
                            <span>{simQuizCount}</span>
                            <button onClick={() => setSimQuizCount(simQuizCount + 1)} className="bg-white/10 px-2 py-0.5 rounded">+</button>
                          </div>
                        </div>

                        <div className="bg-[#1a1a1a] p-2.5 rounded-xl border border-white/5 flex flex-col justify-between">
                          <span className="text-gray-400">Examen Final de Module</span>
                          <button
                            onClick={() => setHasFinalExam(!hasFinalExam)}
                            className={`mt-1.5 py-1 px-3 rounded-lg text-[10px] font-bold ${hasFinalExam ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30" : "bg-red-500/20 text-red-400 border border-red-500/30"}`}
                          >
                            {hasFinalExam ? "OUI (Inclus)" : "NON"}
                          </button>
                        </div>
                      </div>

                      {/* Run alert button */}
                      <button
                        type="button"
                        onClick={handleSimulateAlert}
                        className="w-full bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-400 py-2 rounded-xl text-xs flex items-center justify-center gap-2 transition-all font-mono"
                      >
                        <AlertTriangle size={14} /> Simuler une alerte d'abandon d'élève
                      </button>
                    </div>
                  </motion.div>
                )}

                {step === "done" && (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center space-y-4">
                    <div className="w-16 h-16 rounded-full bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center mx-auto mb-4 text-emerald-400 animate-pulse">
                      <GraduationCap size={32} />
                    </div>
                    <h3 className="text-xl font-bold text-white">Espace de cours validé !</h3>
                    <p className="text-gray-400 text-sm leading-relaxed px-4">
                      Votre premier cours simulé a été enregistré. Vos futurs apprenants recevront une recommandation personnalisée d'Auralis dès leur inscription !
                    </p>
                  </motion.div>
                )}
              </div>

              {/* Footer buttons */}
              <div className="flex justify-between items-center border-t border-white/5 p-8 pt-4 mt-auto">
                {step !== "simulate" && step !== "done" && (
                  <button
                    onClick={handleSkip}
                    className="text-xs text-gray-400 hover:text-white transition-colors"
                  >
                    Sauter le tutoriel
                  </button>
                )}

                {step !== "simulate" && step !== "done" && (
                  <button
                    onClick={handleNextSpotlight}
                    className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all shadow-lg"
                  >
                    Suivant <ChevronRight size={14} />
                  </button>
                )}

                {step === "simulate" && (
                  <button
                    onClick={handleSimulateSubmit}
                    className="w-full bg-blue-500 hover:bg-blue-600 text-white py-2.5 rounded-xl text-xs font-bold transition-all"
                  >
                    Simuler la création du cours augmenté !
                  </button>
                )}

                {step === "done" && (
                  <button
                    onClick={finishTutorial}
                    className="w-full bg-emerald-500 hover:bg-emerald-600 text-white py-2.5 rounded-xl text-xs font-bold transition-all"
                  >
                    Accéder à mon espace Formateur
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </AnimatePresence>
  );
}
